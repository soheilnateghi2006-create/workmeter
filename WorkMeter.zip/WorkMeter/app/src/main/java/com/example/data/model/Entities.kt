package com.example.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "work_days",
    indices = [Index(value = ["date"], unique = true)]
)
data class WorkDay(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val date: String, // canonical date e.g. "1405/07/10"
    val persianDate: String, // e.g. "۱۰ مهر ۱۴۰۵"
    val gregorianDate: String, // e.g. "2026/10/02"
    val workDayAmount: Double, // 1.0, 0.5, 0.75, 0.0, etc.
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "overtimes",
    indices = [Index(value = ["date"], unique = true)]
)
data class Overtime(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val workDayId: Long = 0,
    val date: String, // canonical date e.g. "1405/07/10"
    val persianDate: String,
    val gregorianDate: String,
    val overtimeHours: Double,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "payments")
data class Payment(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val amountToman: Long,
    val canonicalDate: String = "", // e.g. "1405/07/10"
    val persianDate: String,
    val persianMonthKey: String, // e.g. "مهر ۱۴۰۵"
    val gregorianDate: String,
    val time: String, // e.g. "14:35"
    val amountInWords: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "recovery_records")
data class RecoveryRecord(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val originalRecordType: String, // "WORK_DAY", "OVERTIME", "PAYMENT", "RATE_SETTING"
    val originalRecordId: Long,
    val deletedAt: Long = System.currentTimeMillis(),
    val originalData: String,
    val title: String,
    val summaryText: String
)

@Entity(tableName = "rate_settings")
data class RateSetting(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val effectiveFrom: String, // e.g. "1405/07/10"
    val dailyWage: Long, // تومان
    val overtimeMultiplier: Double = 1.4,
    val dailyHours: Double = 8.0,
    val createdAt: Long = System.currentTimeMillis()
)
