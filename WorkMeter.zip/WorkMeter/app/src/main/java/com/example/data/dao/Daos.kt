package com.example.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.Overtime
import com.example.data.model.Payment
import com.example.data.model.RateSetting
import com.example.data.model.RecoveryRecord
import com.example.data.model.WorkDay
import kotlinx.coroutines.flow.Flow

@Dao
interface WorkDayDao {
    @Query("SELECT * FROM work_days ORDER BY date DESC")
    fun getAllWorkDaysFlow(): Flow<List<WorkDay>>

    @Query("SELECT * FROM work_days ORDER BY date DESC")
    suspend fun getAllWorkDays(): List<WorkDay>

    @Query("SELECT * FROM work_days WHERE date = :date LIMIT 1")
    suspend fun getWorkDayByDate(date: String): WorkDay?

    @Query("SELECT * FROM work_days WHERE id = :id LIMIT 1")
    suspend fun getWorkDayById(id: Long): WorkDay?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWorkDay(workDay: WorkDay): Long

    @Update
    suspend fun updateWorkDay(workDay: WorkDay)

    @Delete
    suspend fun deleteWorkDay(workDay: WorkDay)

    @Query("DELETE FROM work_days WHERE id = :id")
    suspend fun deleteWorkDayById(id: Long)
}

@Dao
interface OvertimeDao {
    @Query("SELECT * FROM overtimes ORDER BY date DESC")
    fun getAllOvertimeFlow(): Flow<List<Overtime>>

    @Query("SELECT * FROM overtimes ORDER BY date DESC")
    suspend fun getAllOvertime(): List<Overtime>

    @Query("SELECT * FROM overtimes WHERE date = :date LIMIT 1")
    suspend fun getOvertimeByDate(date: String): Overtime?

    @Query("SELECT * FROM overtimes WHERE id = :id LIMIT 1")
    suspend fun getOvertimeById(id: Long): Overtime?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOvertime(overtime: Overtime): Long

    @Update
    suspend fun updateOvertime(overtime: Overtime)

    @Delete
    suspend fun deleteOvertime(overtime: Overtime)

    @Query("DELETE FROM overtimes WHERE id = :id")
    suspend fun deleteOvertimeById(id: Long)
}

@Dao
interface PaymentDao {
    @Query("SELECT * FROM payments ORDER BY canonicalDate DESC, time DESC, createdAt DESC")
    fun getAllPaymentsFlow(): Flow<List<Payment>>

    @Query("SELECT * FROM payments ORDER BY canonicalDate DESC, time DESC, createdAt DESC")
    suspend fun getAllPayments(): List<Payment>

    @Query("SELECT * FROM payments WHERE id = :id LIMIT 1")
    suspend fun getPaymentById(id: Long): Payment?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPayment(payment: Payment): Long

    @Delete
    suspend fun deletePayment(payment: Payment)

    @Query("DELETE FROM payments WHERE id = :id")
    suspend fun deletePaymentById(id: Long)
}

@Dao
interface RecoveryDao {
    @Query("SELECT * FROM recovery_records ORDER BY deletedAt DESC")
    fun getAllRecoveryFlow(): Flow<List<RecoveryRecord>>

    @Query("SELECT * FROM recovery_records ORDER BY deletedAt DESC")
    suspend fun getAllRecovery(): List<RecoveryRecord>

    @Query("SELECT * FROM recovery_records WHERE id = :id LIMIT 1")
    suspend fun getRecoveryById(id: Long): RecoveryRecord?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRecovery(record: RecoveryRecord): Long

    @Delete
    suspend fun deleteRecovery(record: RecoveryRecord)

    @Query("DELETE FROM recovery_records WHERE id = :id")
    suspend fun deleteRecoveryById(id: Long)

    @Query("DELETE FROM recovery_records")
    suspend fun clearAll()
}

@Dao
interface RateDao {
    @Query("SELECT * FROM rate_settings ORDER BY effectiveFrom DESC, id DESC")
    fun getAllRatesFlow(): Flow<List<RateSetting>>

    @Query("SELECT * FROM rate_settings ORDER BY effectiveFrom DESC, id DESC")
    suspend fun getAllRates(): List<RateSetting>

    @Query("SELECT * FROM rate_settings WHERE id = :id LIMIT 1")
    suspend fun getRateById(id: Long): RateSetting?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRate(rate: RateSetting): Long

    @Update
    suspend fun updateRate(rate: RateSetting)

    @Delete
    suspend fun deleteRate(rate: RateSetting)

    @Query("DELETE FROM rate_settings WHERE id = :id")
    suspend fun deleteRateById(id: Long)
}
