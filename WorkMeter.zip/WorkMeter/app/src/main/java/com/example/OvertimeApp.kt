package com.example

import android.app.Application
import com.example.data.AppDatabase
import com.example.data.repository.OvertimeRepository
import com.example.reminder.MidnightReminderScheduler

class OvertimeApp : Application() {

    val database: AppDatabase by lazy {
        AppDatabase.getDatabase(this)
    }

    val repository: OvertimeRepository by lazy {
        OvertimeRepository(database)
    }

    override fun onCreate() {
        super.onCreate()
        MidnightReminderScheduler.createNotificationChannel(this)
        MidnightReminderScheduler.scheduleMidnightReminder(this)
    }
}
