package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.util.PersianCalendarHelper
import java.util.Calendar

@Composable
fun PersianDatePickerDialog(
    initialDate: PersianCalendarHelper.PersianDate = PersianCalendarHelper.getTodayPersianDate(),
    onDateSelected: (PersianCalendarHelper.PersianDate, String) -> Unit, // returns persianDate and gregorianDate
    onDismissRequest: () -> Unit
) {
    var selectedYear by remember { mutableIntStateOf(initialDate.year) }
    var selectedMonth by remember { mutableIntStateOf(initialDate.month) }
    var selectedDay by remember { mutableIntStateOf(initialDate.day) }

    val daysInMonth = when {
        selectedMonth <= 6 -> 31
        selectedMonth <= 11 -> 30
        else -> 29
    }

    if (selectedDay > daysInMonth) {
        selectedDay = daysInMonth
    }

    CenteredSmoothDialog(
        onDismissRequest = onDismissRequest,
        modifier = Modifier.testTag("persian_date_picker_dialog"),
        icon = {
            Icon(
                Icons.Default.CalendarMonth,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary
            )
        },
        title = {
            Text(
                text = "انتخاب تاریخ خورشیدی",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
        },
        content = {
            Column(modifier = Modifier.fillMaxWidth()) {
                // Quick date selection chips
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    val today = remember { PersianCalendarHelper.getTodayPersianDate() }
                    AssistChip(
                        onClick = {
                            selectedYear = today.year
                            selectedMonth = today.month
                            selectedDay = today.day
                        },
                        label = { Text("امروز") },
                        colors = AssistChipDefaults.assistChipColors(
                            containerColor = if (selectedYear == today.year && selectedMonth == today.month && selectedDay == today.day)
                                MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface
                        )
                    )

                    // Yesterday
                    AssistChip(
                        onClick = {
                            val cal = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -1) }
                            val yDate = PersianCalendarHelper.gregorianToPersian(
                                cal.get(Calendar.YEAR),
                                cal.get(Calendar.MONTH) + 1,
                                cal.get(Calendar.DAY_OF_MONTH)
                            )
                            selectedYear = yDate.year
                            selectedMonth = yDate.month
                            selectedDay = yDate.day
                        },
                        label = { Text("دیروز") }
                    )

                    // Day before yesterday
                    AssistChip(
                        onClick = {
                            val cal = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -2) }
                            val pDate = PersianCalendarHelper.gregorianToPersian(
                                cal.get(Calendar.YEAR),
                                cal.get(Calendar.MONTH) + 1,
                                cal.get(Calendar.DAY_OF_MONTH)
                            )
                            selectedYear = pDate.year
                            selectedMonth = pDate.month
                            selectedDay = pDate.day
                        },
                        label = { Text("پریروز") }
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Year Stepper
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { selectedYear-- }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "سال قبل")
                    }
                    Text(
                        text = "سال ${PersianCalendarHelper.toPersianDigits(selectedYear)}",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    IconButton(onClick = { selectedYear++ }) {
                        Icon(Icons.Default.ArrowForward, contentDescription = "سال بعد")
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Month Selector
                Text(
                    text = "ماه: ${PersianCalendarHelper.getPersianMonthName(selectedMonth)}",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(modifier = Modifier.height(4.dp))
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items((1..12).toList()) { month ->
                        val isSelected = month == selectedMonth
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(
                                    if (isSelected) MaterialTheme.colorScheme.primary
                                    else MaterialTheme.colorScheme.surfaceVariant
                                )
                                .clickable { selectedMonth = month }
                                .padding(horizontal = 10.dp, vertical = 6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = PersianCalendarHelper.getPersianMonthName(month),
                                color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface,
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Day Selector
                Text(
                    text = "روز: ${PersianCalendarHelper.toPersianDigits(selectedDay)}",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(modifier = Modifier.height(4.dp))
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items((1..daysInMonth).toList()) { day ->
                        val isSelected = day == selectedDay
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(
                                    if (isSelected) MaterialTheme.colorScheme.primary
                                    else MaterialTheme.colorScheme.surfaceVariant
                                )
                                .clickable { selectedDay = day }
                                .padding(horizontal = 10.dp, vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = PersianCalendarHelper.toPersianDigits(day),
                                color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Preview Box
                val (gYear, gMonth, gDay) = PersianCalendarHelper.persianToGregorian(selectedYear, selectedMonth, selectedDay)
                val gregorianFormatted = "$gYear/${gMonth.toString().padStart(2, '0')}/${gDay.toString().padStart(2, '0')}"
                val selectedPersianDate = PersianCalendarHelper.PersianDate(selectedYear, selectedMonth, selectedDay)

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f))
                        .padding(10.dp)
                ) {
                    Column {
                        Text(
                            text = "تاریخ انتخاب شده: ${selectedPersianDate.toLongFormat()}",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Text(
                            text = "معادل میلادی: $gregorianFormatted",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val pDate = PersianCalendarHelper.PersianDate(selectedYear, selectedMonth, selectedDay)
                    val (gy, gm, gd) = PersianCalendarHelper.persianToGregorian(selectedYear, selectedMonth, selectedDay)
                    val gDate = "$gy/${gm.toString().padStart(2, '0')}/${gd.toString().padStart(2, '0')}"
                    onDateSelected(pDate, gDate)
                },
                modifier = Modifier.testTag("confirm_date_button")
            ) {
                Text("تأیید تاریخ")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismissRequest) {
                Text("انصراف")
            }
        }
    )
}
