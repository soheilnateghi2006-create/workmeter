package com.example.ui.screens

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FilterAlt
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.RestoreFromTrash
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedFilterChip
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.Overtime
import com.example.data.model.Payment
import com.example.data.model.WorkDay
import com.example.ui.components.CenteredSmoothDialog
import com.example.ui.components.PersianDatePickerDialog
import com.example.ui.viewmodel.DateFilterType
import com.example.ui.viewmodel.OvertimeViewModel
import com.example.util.PersianCalendarHelper

data class UnifiedHistoryItem(
    val dateKey: String, // canonical date e.g. "1405/07/10"
    val persianDate: String,
    val gregorianDate: String,
    val workDay: WorkDay?,
    val overtime: Overtime?,
    val payments: List<Payment>
)

@Composable
fun HistoryScreen(
    viewModel: OvertimeViewModel,
    onOpenRecovery: () -> Unit,
    onEditDate: (String) -> Unit
) {
    val context = LocalContext.current
    val workDays by viewModel.workDays.collectAsStateWithLifecycle()
    val overtimes by viewModel.overtimes.collectAsStateWithLifecycle()
    val payments by viewModel.payments.collectAsStateWithLifecycle()
    val recoveryList by viewModel.recoveryRecords.collectAsStateWithLifecycle()

    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val selectedFilterType by viewModel.selectedFilterType.collectAsStateWithLifecycle()
    val customStartDate by viewModel.customStartDate.collectAsStateWithLifecycle()
    val customEndDate by viewModel.customEndDate.collectAsStateWithLifecycle()

    var showCustomRangeDialog by remember { mutableStateOf(false) }
    var tempStartDate by remember { mutableStateOf(customStartDate ?: PersianCalendarHelper.getTodayPersianDate()) }
    var tempEndDate by remember { mutableStateOf(customEndDate ?: PersianCalendarHelper.getTodayPersianDate()) }
    var pickingForStart by remember { mutableStateOf<Boolean?>(null) }

    // Date range picker for Custom Filter
    if (showCustomRangeDialog) {
        CenteredSmoothDialog(
            onDismissRequest = { showCustomRangeDialog = false },
            icon = {
                Icon(Icons.Default.DateRange, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(32.dp))
            },
            title = {
                Text("تعیین بازه دلخواه", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            },
            content = {
                Column {
                    Text("بازه زمانی مورد نظر خود را مشخص کنید:", style = MaterialTheme.typography.bodyMedium)
                    Spacer(modifier = Modifier.height(14.dp))

                    // Start date selector
                    OutlinedButton(
                        onClick = { pickingForStart = true },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("از تاریخ: ${tempStartDate.toLongFormat()}")
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // End date selector
                    OutlinedButton(
                        onClick = { pickingForStart = false },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("تا تاریخ: ${tempEndDate.toLongFormat()}")
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    viewModel.setDateFilter(DateFilterType.CUSTOM, tempStartDate, tempEndDate)
                    showCustomRangeDialog = false
                }) {
                    Text("اعمال فیلتر")
                }
            },
            dismissButton = {
                TextButton(onClick = { showCustomRangeDialog = false }) {
                    Text("انصراف")
                }
            }
        )
    }

    if (pickingForStart != null) {
        val forStart = pickingForStart == true
        PersianDatePickerDialog(
            initialDate = if (forStart) tempStartDate else tempEndDate,
            onDateSelected = { pDate, _ ->
                if (forStart) tempStartDate = pDate else tempEndDate = pDate
                pickingForStart = null
            },
            onDismissRequest = { pickingForStart = null }
        )
    }

    // Unified history items aggregation
    val unifiedHistoryList = remember(workDays, overtimes, payments, searchQuery, selectedFilterType, customStartDate, customEndDate) {
        val (filterStart, filterEnd) = viewModel.getActiveFilterRange()

        val allDates = (workDays.map { it.date } + overtimes.map { it.date } + payments.map {
            PersianCalendarHelper.extractCanonicalDate(it.persianDate)
        }).distinct().sortedDescending()

        val wdMap = workDays.associateBy { it.date }
        val otMap = overtimes.associateBy { it.date }

        allDates.mapNotNull { key ->
            val wd = wdMap[key]
            val ot = otMap[key]
            val pmts = payments.filter {
                it.persianDate == key ||
                        it.persianDate.contains(key) ||
                        it.gregorianDate == key ||
                        PersianCalendarHelper.extractCanonicalDate(it.persianDate) == key
            }

            // Apply Date Range Filter if active
            if (filterStart != null && filterEnd != null) {
                if (key < filterStart || key > filterEnd) {
                    return@mapNotNull null
                }
            }

            val pDate = wd?.persianDate ?: ot?.persianDate ?: if (pmts.isNotEmpty()) pmts.first().persianDate else key
            val gDate = wd?.gregorianDate ?: ot?.gregorianDate ?: if (pmts.isNotEmpty()) pmts.first().gregorianDate else "-"

            // Apply Search Query if not blank
            if (searchQuery.isNotBlank()) {
                val q = searchQuery.trim().lowercase()
                val qEnglish = PersianCalendarHelper.toEnglishDigits(q)
                val matchesDate = pDate.lowercase().contains(q) || key.contains(qEnglish)
                val matchesGreg = gDate.lowercase().contains(q)
                val matchesWork = wd != null && (wd.workDayAmount.toString().contains(qEnglish) || "روز کاری".contains(q))
                val matchesOt = ot != null && (ot.overtimeHours.toString().contains(qEnglish) || "اضافه کاری".contains(q))
                val matchesPayment = pmts.any { p ->
                    p.amountToman.toString().contains(qEnglish) ||
                            p.amountInWords.contains(q) ||
                            PersianCalendarHelper.formatAmountToman(p.amountToman).contains(q)
                }

                if (!matchesDate && !matchesGreg && !matchesWork && !matchesOt && !matchesPayment) {
                    return@mapNotNull null
                }
            }

            UnifiedHistoryItem(
                dateKey = key,
                persianDate = pDate,
                gregorianDate = gDate,
                workDay = wd,
                overtime = ot,
                payments = pmts
            )
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 6.dp)
    ) {
        // Top Action Bar: خروجی PDF and بازیابی
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // PDF Export button
            Button(
                onClick = { viewModel.exportPdf(context) },
                modifier = Modifier.testTag("export_pdf_button")
            ) {
                Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("خروجی PDF")
            }

            // Recovery button
            FilledTonalButton(
                onClick = onOpenRecovery,
                modifier = Modifier.testTag("history_recovery_button")
            ) {
                BadgedBox(
                    badge = {
                        if (recoveryList.isNotEmpty()) {
                            Badge {
                                Text(PersianCalendarHelper.toPersianDigits(recoveryList.size))
                            }
                        }
                    }
                ) {
                    Icon(
                        Icons.Default.RestoreFromTrash,
                        contentDescription = "سطل زباله",
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text("سطل زباله (بازیابی)")
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Search Text Field
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { viewModel.setSearchQuery(it) },
            placeholder = { Text("جستجو بر اساس تاریخ، ماه، مبلغ یا ساعت...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = "جستجو") },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { viewModel.setSearchQuery("") }) {
                        Icon(Icons.Default.Close, contentDescription = "پاک کردن جستجو")
                    }
                }
            },
            singleLine = true,
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("history_search_input")
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Filter Chips Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            DateFilterType.values().forEach { filterType ->
                ElevatedFilterChip(
                    selected = selectedFilterType == filterType,
                    onClick = {
                        if (filterType == DateFilterType.CUSTOM) {
                            showCustomRangeDialog = true
                        } else {
                            viewModel.setDateFilter(filterType)
                        }
                    },
                    label = { Text(filterType.title, fontWeight = if (selectedFilterType == filterType) FontWeight.Bold else FontWeight.Normal) },
                    colors = FilterChipDefaults.elevatedFilterChipColors()
                )
            }
        }

        // Active Filter Banner if not ALL
        val filterLabel = viewModel.getActiveFilterLabel()
        if (filterLabel != null || searchQuery.isNotBlank()) {
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f))
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.FilterAlt, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (filterLabel != null) "فیلتر فعال: $filterLabel" else "جستجو: $searchQuery",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        fontWeight = FontWeight.SemiBold
                    )
                }
                TextButton(onClick = { viewModel.clearFilter() }) {
                    Text("پاک کردن فیلتر", style = MaterialTheme.typography.labelSmall)
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Results List / Empty States
        if (unifiedHistoryList.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        Icons.Default.History,
                        contentDescription = null,
                        modifier = Modifier.size(64.dp),
                        tint = MaterialTheme.colorScheme.outlineVariant
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = if (searchQuery.isNotBlank() || selectedFilterType != DateFilterType.ALL)
                            "موردی پیدا نشد."
                        else
                            "هنوز سابقه‌ای ثبت نشده است",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = if (searchQuery.isNotBlank() || selectedFilterType != DateFilterType.ALL)
                            "با پاک کردن فیلتر یا عبارت جستجو می‌توانید تمام سوابق را مشاهده کنید."
                        else
                            "با ثبت روز کاری یا دریافتی، سوابق کامل شما اینجا نمایش داده می‌شود.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.outline
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                items(unifiedHistoryList, key = { it.dateKey }) { item ->
                    HistoryCard(
                        item = item,
                        onDeleteWorkDay = { item.workDay?.let { viewModel.deleteWorkDay(it) } },
                        onDeleteOvertime = { item.overtime?.let { viewModel.deleteOvertime(it) } },
                        onDeletePayment = { pmt -> viewModel.deletePayment(pmt) },
                        onEdit = { onEditDate(item.dateKey) }
                    )
                }
            }
        }
    }
}

@Composable
private fun HistoryCard(
    item: UnifiedHistoryItem,
    onDeleteWorkDay: () -> Unit,
    onDeleteOvertime: () -> Unit,
    onDeletePayment: (Payment) -> Unit,
    onEdit: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onEdit() } // Quick edit on card tap
            .testTag("history_card_${item.dateKey}")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Card Header: Dates & Edit Button
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = item.persianDate,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = item.gregorianDate,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.outline
                    )
                }

                IconButton(onClick = onEdit) {
                    Icon(
                        Icons.Default.Edit,
                        contentDescription = "ویرایش سریع",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            HorizontalDivider(
                color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f),
                thickness = 0.8.dp,
                modifier = Modifier.padding(vertical = 10.dp)
            )

            // Content Fields
            // 1. Work Day
            if (item.workDay != null) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "روز کاری",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = PersianCalendarHelper.formatWorkDays(item.workDay.workDayAmount),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }

                    IconButton(onClick = onDeleteWorkDay) {
                        Icon(
                            Icons.Default.Delete,
                            contentDescription = "حذف روز کاری",
                            tint = MaterialTheme.colorScheme.error.copy(alpha = 0.7f),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(6.dp))
            }

            // 2. Overtime
            if (item.overtime != null && item.overtime.overtimeHours > 0) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "اضافه کاری",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "${PersianCalendarHelper.formatHours(item.overtime.overtimeHours)} اضافه کاری",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.tertiary
                        )
                    }

                    IconButton(onClick = onDeleteOvertime) {
                        Icon(
                            Icons.Default.Delete,
                            contentDescription = "حذف اضافه کاری",
                            tint = MaterialTheme.colorScheme.error.copy(alpha = 0.7f),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(6.dp))
            }

            // 3. Payments
            item.payments.forEach { payment ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "دریافتی (ساعت ${PersianCalendarHelper.toPersianDigits(payment.time)})",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = PersianCalendarHelper.formatAmountToman(payment.amountToman),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.secondary
                        )
                        if (payment.amountInWords.isNotBlank()) {
                            Text(
                                text = payment.amountInWords,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.secondary
                            )
                        }
                    }

                    IconButton(onClick = { onDeletePayment(payment) }) {
                        Icon(
                            Icons.Default.Delete,
                            contentDescription = "حذف دریافتی",
                            tint = MaterialTheme.colorScheme.error.copy(alpha = 0.7f),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
            }
        }
    }
}
