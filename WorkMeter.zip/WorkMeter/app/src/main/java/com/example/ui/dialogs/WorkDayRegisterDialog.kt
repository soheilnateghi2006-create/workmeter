package com.example.ui.dialogs

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.EditCalendar
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.CenteredSmoothDialog
import com.example.ui.components.PersianDatePickerDialog
import com.example.ui.viewmodel.OvertimeViewModel
import com.example.util.PersianCalendarHelper
import kotlinx.coroutines.launch

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun WorkDayRegisterDialog(
    viewModel: OvertimeViewModel,
    initialDate: PersianCalendarHelper.PersianDate = PersianCalendarHelper.getTodayPersianDate(),
    initialGregorianDate: String = PersianCalendarHelper.getTodayGregorianDate(),
    onDismissRequest: () -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    var currentPersianDate by remember { mutableStateOf(initialDate) }
    var currentGregorianDate by remember { mutableStateOf(initialGregorianDate) }
    var showDatePicker by remember { mutableStateOf(false) }

    var workDayAmount by remember { mutableDoubleStateOf(1.0) }
    var overtimeHours by remember { mutableDoubleStateOf(0.0) }
    var isExistingRecord by remember { mutableStateOf(false) }
    var isLoadingExisting by remember { mutableStateOf(true) }

    // When date changes, query existing record for that canonical date
    val canonicalDate = currentPersianDate.toStandardString()

    LaunchedEffect(canonicalDate) {
        isLoadingExisting = true
        val existingWorkDay = viewModel.getExistingWorkDay(canonicalDate)
        val existingOvertime = viewModel.getExistingOvertime(canonicalDate)

        if (existingWorkDay != null || existingOvertime != null) {
            isExistingRecord = true
            workDayAmount = existingWorkDay?.workDayAmount ?: 1.0
            overtimeHours = existingOvertime?.overtimeHours ?: 0.0
        } else {
            isExistingRecord = false
            workDayAmount = 1.0
            overtimeHours = 0.0
        }
        isLoadingExisting = false
    }

    if (showDatePicker) {
        PersianDatePickerDialog(
            initialDate = currentPersianDate,
            onDateSelected = { pDate, gDate ->
                currentPersianDate = pDate
                currentGregorianDate = gDate
                showDatePicker = false
            },
            onDismissRequest = { showDatePicker = false }
        )
    }

    CenteredSmoothDialog(
        onDismissRequest = onDismissRequest,
        modifier = Modifier.testTag("work_day_dialog"),
        icon = {
            Icon(
                Icons.Default.EditCalendar,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(32.dp)
            )
        },
        title = {
            Text(
                text = if (isExistingRecord) "ویرایش روز کاری و اضافه کاری" else "ثبت روز کاری و اضافه کاری",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
        },
        content = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                // Date selection card
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = currentPersianDate.toLongFormat(),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "میلادی: $currentGregorianDate",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        OutlinedButton(
                            onClick = { showDatePicker = true },
                            modifier = Modifier.testTag("change_date_button")
                        ) {
                            Icon(Icons.Default.CalendarMonth, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("تغییر تاریخ")
                        }
                    }
                }

                // Existing record alert banner
                if (isExistingRecord) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f))
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.Info,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "برای این تاریخ قبلاً ثبت شده بود. تغییرات شما ویرایش خواهد شد.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Section 1: Work Day (روز کاری)
                Text(
                    text = "روز کاری (میزان کارکرد)",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(6.dp))

                val workDayPresets = listOf(
                    1.0 to "۱ روز (کامل)",
                    0.75 to "۰.۷۵ روز",
                    0.5 to "۰.۵ روز (نصف)",
                    0.0 to "۰ روز (تعطیل/عدم حضور)"
                )

                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    workDayPresets.forEach { (value, label) ->
                        FilterChip(
                            selected = workDayAmount == value,
                            onClick = { workDayAmount = value },
                            label = { Text(label) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Section 2: Overtime (اضافه کاری)
                Text(
                    text = "ساعت اضافه کاری (کاملاً مستقل از روز کاری)",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.tertiary
                )
                Spacer(modifier = Modifier.height(6.dp))

                // Overtime Stepper & Quick chips
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = { if (overtimeHours >= 0.5) overtimeHours -= 0.5 },
                        enabled = overtimeHours > 0
                    ) {
                        Icon(Icons.Default.Remove, contentDescription = "کاهش اضافه کاری")
                    }

                    Text(
                        text = PersianCalendarHelper.formatHours(overtimeHours),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    IconButton(
                        onClick = { overtimeHours += 0.5 }
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "افزایش اضافه کاری")
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Quick Overtime Presets: 0, 1, 2, 3, 5, 8
                val overtimePresets = listOf(0.0, 1.0, 2.0, 3.0, 5.0, 8.0, 10.0)
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    overtimePresets.forEach { hrs ->
                        FilterChip(
                            selected = overtimeHours == hrs,
                            onClick = { overtimeHours = hrs },
                            label = { Text("${PersianCalendarHelper.toPersianDigits(hrs.toInt())} س") }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Summary Note
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
                        .padding(10.dp)
                ) {
                    Text(
                        text = "ثبت نهایی: ${PersianCalendarHelper.formatWorkDays(workDayAmount)} و ${PersianCalendarHelper.formatHours(overtimeHours)} برای تاریخ ${currentPersianDate.toFormattedString()}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    viewModel.saveWorkDayAndOvertime(
                        canonicalDate = canonicalDate,
                        persianDate = currentPersianDate.toLongFormat(),
                        gregorianDate = currentGregorianDate,
                        workDayAmount = workDayAmount,
                        overtimeHours = overtimeHours,
                        onSuccess = onDismissRequest
                    )
                },
                modifier = Modifier.testTag("save_work_day_button")
            ) {
                Text(if (isExistingRecord) "ویرایش و ذخیره" else "ثبت اطلاعات")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismissRequest) {
                Text("انصراف")
            }
        }
    )
}
