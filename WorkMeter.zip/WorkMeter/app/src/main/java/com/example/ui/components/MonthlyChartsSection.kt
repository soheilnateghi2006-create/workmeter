package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.MonthlyOvertimeStat
import com.example.data.repository.MonthlyStat
import com.example.util.PersianCalendarHelper

/**
 * Modern, clean, minimal monthly charts for Payments and Overtime.
 * Strictly uses real database data and handles empty states gracefully.
 */
@Composable
fun MonthlyChartsSection(
    monthlyPayments: List<MonthlyStat>,
    monthlyOvertimes: List<MonthlyOvertimeStat>,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableIntStateOf(0) }

    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.45f)),
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .testTag("monthly_charts_section")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(
                text = "نمودار تحلیلی ماهانه",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(10.dp))

            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                divider = {},
                modifier = Modifier.clip(RoundedCornerShape(10.dp))
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("دریافتی ماهانه", fontWeight = FontWeight.SemiBold) }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("اضافه کاری ماهانه", fontWeight = FontWeight.SemiBold) }
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            if (selectedTab == 0) {
                // Monthly Payments Chart
                if (monthlyPayments.isEmpty() || monthlyPayments.all { it.totalAmountToman <= 0 }) {
                    EmptyChartNotice()
                } else {
                    PaymentBarChart(monthlyPayments)
                }
            } else {
                // Monthly Overtime Chart
                if (monthlyOvertimes.isEmpty() || monthlyOvertimes.all { it.totalHours <= 0 }) {
                    EmptyChartNotice()
                } else {
                    OvertimeBarChart(monthlyOvertimes)
                }
            }
        }
    }
}

@Composable
private fun EmptyChartNotice() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(140.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = "اطلاعات کافی برای نمایش نمودار وجود ندارد.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun PaymentBarChart(data: List<MonthlyStat>) {
    val maxVal = remember(data) { data.maxOfOrNull { it.totalAmountToman }?.coerceAtLeast(1L) ?: 1L }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(180.dp)
            .clip(RoundedCornerShape(12.dp))
            .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(16.dp),
        verticalAlignment = Alignment.Bottom
    ) {
        data.forEach { item ->
            val fraction = (item.totalAmountToman.toFloat() / maxVal.toFloat()).coerceIn(0.08f, 1f)
            val animatedHeight by animateFloatAsState(
                targetValue = fraction,
                animationSpec = tween(durationMillis = 300),
                label = "barHeight"
            )

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Bottom,
                modifier = Modifier.width(68.dp)
            ) {
                // Value text on top
                Text(
                    text = formatShortToman(item.totalAmountToman),
                    style = MaterialTheme.typography.labelSmall,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.secondary,
                    maxLines = 1,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(4.dp))

                // The bar
                Box(
                    modifier = Modifier
                        .width(28.dp)
                        .height((110 * animatedHeight).dp)
                        .clip(RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp))
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    MaterialTheme.colorScheme.secondary,
                                    MaterialTheme.colorScheme.secondaryContainer
                                )
                            )
                        )
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Month Label
                Text(
                    text = item.monthKey.split(" ").firstOrNull() ?: item.monthKey,
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

@Composable
private fun OvertimeBarChart(data: List<MonthlyOvertimeStat>) {
    val maxVal = remember(data) { data.maxOfOrNull { it.totalHours }?.coerceAtLeast(1.0) ?: 1.0 }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(180.dp)
            .clip(RoundedCornerShape(12.dp))
            .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(16.dp),
        verticalAlignment = Alignment.Bottom
    ) {
        data.forEach { item ->
            val fraction = (item.totalHours.toFloat() / maxVal.toFloat()).coerceIn(0.08f, 1f)
            val animatedHeight by animateFloatAsState(
                targetValue = fraction,
                animationSpec = tween(durationMillis = 300),
                label = "otBarHeight"
            )

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Bottom,
                modifier = Modifier.width(68.dp)
            ) {
                // Value text on top
                Text(
                    text = "${PersianCalendarHelper.toPersianDigits(item.totalHours.toInt())} س",
                    style = MaterialTheme.typography.labelSmall,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.tertiary,
                    maxLines = 1,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(4.dp))

                // The bar
                Box(
                    modifier = Modifier
                        .width(28.dp)
                        .height((110 * animatedHeight).dp)
                        .clip(RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp))
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    MaterialTheme.colorScheme.tertiary,
                                    MaterialTheme.colorScheme.tertiaryContainer
                                )
                            )
                        )
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Month Label
                Text(
                    text = item.monthKey.split(" ").firstOrNull() ?: item.monthKey,
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

private fun formatShortToman(amount: Long): String {
    return when {
        amount >= 1_000_000_000L -> "${PersianCalendarHelper.toPersianDigits(amount / 1_000_000_000L)} م.م"
        amount >= 1_000_000L -> "${PersianCalendarHelper.toPersianDigits(amount / 1_000_000L)} م"
        amount >= 1_000L -> "${PersianCalendarHelper.toPersianDigits(amount / 1_000L)} ه"
        else -> PersianCalendarHelper.toPersianDigits(amount)
    }
}
