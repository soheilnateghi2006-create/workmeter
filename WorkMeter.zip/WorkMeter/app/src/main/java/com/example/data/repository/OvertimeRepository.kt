package com.example.data.repository

import com.example.data.AppDatabase
import com.example.data.model.Overtime
import com.example.data.model.Payment
import com.example.data.model.RateSetting
import com.example.data.model.RecoveryRecord
import com.example.data.model.WorkDay
import com.example.util.FinancialBalanceSummary
import com.example.util.FinancialCalculator
import com.example.util.PersianCalendarHelper
import kotlinx.coroutines.flow.Flow
import org.json.JSONObject

data class MonthlyStat(
    val monthKey: String, // e.g. "مهر ۱۴۰۵"
    val totalAmountToman: Long
)

data class MonthlyOvertimeStat(
    val monthKey: String, // e.g. "مهر ۱۴۰۵"
    val totalHours: Double
)

data class RestoreSummary(
    val workDaysCount: Int,
    val overtimesCount: Int,
    val paymentsCount: Int,
    val skippedWorkDaysCount: Int = 0,
    val skippedOvertimesCount: Int = 0,
    val skippedPaymentsCount: Int = 0,
    val skippedTotalCount: Int = 0
)

data class StatisticsResult(
    val totalWorkDays: Double,
    val totalOvertimeHours: Double,
    val totalPaymentAmount: Long,
    val monthlyPayments: List<MonthlyStat>,
    val monthlyOvertimes: List<MonthlyOvertimeStat> = emptyList(),
    val dateRangeLabel: String? = null,
    val financialSummary: FinancialBalanceSummary? = null
)

class OvertimeRepository(private val database: AppDatabase) {

    private val workDayDao = database.workDayDao()
    private val overtimeDao = database.overtimeDao()
    private val paymentDao = database.paymentDao()
    private val recoveryDao = database.recoveryDao()
    private val rateDao = database.rateDao()

    val allWorkDaysFlow: Flow<List<WorkDay>> = workDayDao.getAllWorkDaysFlow()
    val allOvertimeFlow: Flow<List<Overtime>> = overtimeDao.getAllOvertimeFlow()
    val allPaymentsFlow: Flow<List<Payment>> = paymentDao.getAllPaymentsFlow()
    val allRecoveryFlow: Flow<List<RecoveryRecord>> = recoveryDao.getAllRecoveryFlow()
    val allRatesFlow: Flow<List<RateSetting>> = rateDao.getAllRatesFlow()

    // WorkDay Operations
    suspend fun getWorkDayByDate(date: String): WorkDay? {
        return workDayDao.getWorkDayByDate(date)
    }

    suspend fun saveWorkDay(
        date: String,
        persianDate: String,
        gregorianDate: String,
        amount: Double
    ): Long {
        val existing = workDayDao.getWorkDayByDate(date)
        return if (existing != null) {
            val updated = existing.copy(
                workDayAmount = amount,
                persianDate = persianDate,
                gregorianDate = gregorianDate,
                updatedAt = System.currentTimeMillis()
            )
            workDayDao.updateWorkDay(updated)
            existing.id
        } else {
            val newRecord = WorkDay(
                date = date,
                persianDate = persianDate,
                gregorianDate = gregorianDate,
                workDayAmount = amount
            )
            workDayDao.insertWorkDay(newRecord)
        }
    }

    suspend fun deleteWorkDayToRecovery(workDay: WorkDay) {
        val json = JSONObject().apply {
            put("id", workDay.id)
            put("date", workDay.date)
            put("persianDate", workDay.persianDate)
            put("gregorianDate", workDay.gregorianDate)
            put("workDayAmount", workDay.workDayAmount)
            put("createdAt", workDay.createdAt)
            put("updatedAt", workDay.updatedAt)
        }.toString()

        val recovery = RecoveryRecord(
            originalRecordType = "WORK_DAY",
            originalRecordId = workDay.id,
            originalData = json,
            title = "روز کاری: ${workDay.persianDate}",
            summaryText = "${PersianCalendarHelper.formatWorkDays(workDay.workDayAmount)} - ${workDay.gregorianDate}"
        )
        recoveryDao.insertRecovery(recovery)
        workDayDao.deleteWorkDay(workDay)
    }

    // Overtime Operations
    suspend fun getOvertimeByDate(date: String): Overtime? {
        return overtimeDao.getOvertimeByDate(date)
    }

    suspend fun saveOvertime(
        date: String,
        persianDate: String,
        gregorianDate: String,
        hours: Double,
        workDayId: Long = 0
    ): Long {
        val existing = overtimeDao.getOvertimeByDate(date)
        return if (existing != null) {
            val updated = existing.copy(
                overtimeHours = hours,
                persianDate = persianDate,
                gregorianDate = gregorianDate
            )
            overtimeDao.updateOvertime(updated)
            existing.id
        } else {
            val newRecord = Overtime(
                workDayId = workDayId,
                date = date,
                persianDate = persianDate,
                gregorianDate = gregorianDate,
                overtimeHours = hours
            )
            overtimeDao.insertOvertime(newRecord)
        }
    }

    suspend fun deleteOvertimeDirectly(date: String) {
        val existing = overtimeDao.getOvertimeByDate(date)
        if (existing != null) {
            overtimeDao.deleteOvertime(existing)
        }
    }

    suspend fun deleteOvertimeToRecovery(overtime: Overtime) {
        val json = JSONObject().apply {
            put("id", overtime.id)
            put("workDayId", overtime.workDayId)
            put("date", overtime.date)
            put("persianDate", overtime.persianDate)
            put("gregorianDate", overtime.gregorianDate)
            put("overtimeHours", overtime.overtimeHours)
            put("createdAt", overtime.createdAt)
        }.toString()

        val recovery = RecoveryRecord(
            originalRecordType = "OVERTIME",
            originalRecordId = overtime.id,
            originalData = json,
            title = "اضافه کاری: ${overtime.persianDate}",
            summaryText = "${PersianCalendarHelper.formatHours(overtime.overtimeHours)} - ${overtime.gregorianDate}"
        )
        recoveryDao.insertRecovery(recovery)
        overtimeDao.deleteOvertime(overtime)
    }

    // Payment Operations
    suspend fun savePayment(
        amountToman: Long,
        canonicalDate: String = "",
        persianDate: String,
        persianMonthKey: String,
        gregorianDate: String,
        time: String,
        amountInWords: String
    ): Long {
        val finalCanonical = canonicalDate.ifBlank {
            PersianCalendarHelper.extractCanonicalDate(persianDate)
        }
        val payment = Payment(
            amountToman = amountToman,
            canonicalDate = finalCanonical,
            persianDate = persianDate,
            persianMonthKey = persianMonthKey,
            gregorianDate = gregorianDate,
            time = time,
            amountInWords = amountInWords
        )
        return paymentDao.insertPayment(payment)
    }

    suspend fun deletePaymentToRecovery(payment: Payment) {
        val json = JSONObject().apply {
            put("id", payment.id)
            put("amountToman", payment.amountToman)
            put("persianDate", payment.persianDate)
            put("persianMonthKey", payment.persianMonthKey)
            put("gregorianDate", payment.gregorianDate)
            put("time", payment.time)
            put("amountInWords", payment.amountInWords)
            put("createdAt", payment.createdAt)
        }.toString()

        val recovery = RecoveryRecord(
            originalRecordType = "PAYMENT",
            originalRecordId = payment.id,
            originalData = json,
            title = "دریافتی: ${PersianCalendarHelper.formatAmountToman(payment.amountToman)}",
            summaryText = "${payment.persianDate} ساعت ${payment.time} (${payment.amountInWords})"
        )
        recoveryDao.insertRecovery(recovery)
        paymentDao.deletePayment(payment)
    }

    // Rate Setting Operations
    suspend fun getAllRates(): List<RateSetting> = rateDao.getAllRates()

    suspend fun getRateById(id: Long): RateSetting? = rateDao.getRateById(id)

    suspend fun saveRate(
        id: Long = 0,
        effectiveFrom: String,
        dailyWage: Long,
        overtimeMultiplier: Double = 1.4,
        dailyHours: Double = 8.0
    ): Long {
        val rate = RateSetting(
            id = id,
            effectiveFrom = effectiveFrom,
            dailyWage = dailyWage,
            overtimeMultiplier = overtimeMultiplier,
            dailyHours = dailyHours
        )
        return if (id == 0L) {
            rateDao.insertRate(rate)
        } else {
            rateDao.updateRate(rate)
            id
        }
    }

    suspend fun deleteRateToRecovery(rate: RateSetting) {
        val json = JSONObject().apply {
            put("id", rate.id)
            put("effectiveFrom", rate.effectiveFrom)
            put("dailyWage", rate.dailyWage)
            put("overtimeMultiplier", rate.overtimeMultiplier)
            put("dailyHours", rate.dailyHours)
            put("createdAt", rate.createdAt)
        }.toString()

        val recovery = RecoveryRecord(
            originalRecordType = "RATE_SETTING",
            originalRecordId = rate.id,
            originalData = json,
            title = "تنظیم نرخ: ${PersianCalendarHelper.formatAmountToman(rate.dailyWage)}",
            summaryText = "از تاریخ ${rate.effectiveFrom} (ساعت کاری: ${rate.dailyHours}، ضریب: ${rate.overtimeMultiplier})"
        )
        recoveryDao.insertRecovery(recovery)
        rateDao.deleteRate(rate)
    }

    // Recovery Operations
    suspend fun restoreRecord(record: RecoveryRecord): Boolean {
        return try {
            val json = JSONObject(record.originalData)
            when (record.originalRecordType) {
                "WORK_DAY" -> {
                    val workDay = WorkDay(
                        id = 0, // insert as fresh or let DB assign ID to avoid conflict
                        date = json.getString("date"),
                        persianDate = json.getString("persianDate"),
                        gregorianDate = json.getString("gregorianDate"),
                        workDayAmount = json.getDouble("workDayAmount"),
                        createdAt = json.optLong("createdAt", System.currentTimeMillis()),
                        updatedAt = System.currentTimeMillis()
                    )
                    workDayDao.insertWorkDay(workDay)
                }
                "OVERTIME" -> {
                    val overtime = Overtime(
                        id = 0,
                        workDayId = json.optLong("workDayId", 0),
                        date = json.getString("date"),
                        persianDate = json.getString("persianDate"),
                        gregorianDate = json.getString("gregorianDate"),
                        overtimeHours = json.getDouble("overtimeHours"),
                        createdAt = json.optLong("createdAt", System.currentTimeMillis())
                    )
                    overtimeDao.insertOvertime(overtime)
                }
                "PAYMENT" -> {
                    val payment = Payment(
                        id = 0,
                        amountToman = json.getLong("amountToman"),
                        canonicalDate = json.optString("canonicalDate", ""),
                        persianDate = json.getString("persianDate"),
                        persianMonthKey = json.getString("persianMonthKey"),
                        gregorianDate = json.getString("gregorianDate"),
                        time = json.getString("time"),
                        amountInWords = json.getString("amountInWords"),
                        createdAt = json.optLong("createdAt", System.currentTimeMillis())
                    )
                    paymentDao.insertPayment(payment)
                }
                "RATE_SETTING" -> {
                    val rate = RateSetting(
                        id = 0,
                        effectiveFrom = json.getString("effectiveFrom"),
                        dailyWage = json.getLong("dailyWage"),
                        overtimeMultiplier = json.optDouble("overtimeMultiplier", 1.4),
                        dailyHours = json.optDouble("dailyHours", 8.0),
                        createdAt = json.optLong("createdAt", System.currentTimeMillis())
                    )
                    rateDao.insertRate(rate)
                }
                else -> return false
            }
            recoveryDao.deleteRecovery(record)
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    suspend fun permanentlyDeleteRecovery(record: RecoveryRecord) {
        recoveryDao.deleteRecovery(record)
    }

    suspend fun clearAllRecovery() {
        recoveryDao.clearAll()
    }

    /**
     * Statistics Calculation Algorithm directly queried from the database:
     * 1. Query ALL Work Day records.
     * 2. Query ALL Overtime records.
     * 3. Query ALL Payment records.
     * 4. Sum actual Work Day values.
     * 5. Sum actual Overtime values.
     * 6. Sum all payment amounts.
     * 7. Group payment records by month.
     * 8. Calculate each month's total.
     */
    suspend fun calculateRealStatistics(
        filterStart: String? = null,
        filterEnd: String? = null,
        label: String? = null
    ): StatisticsResult {
        var workDays = workDayDao.getAllWorkDays()
        var overtimes = overtimeDao.getAllOvertime()
        var payments = paymentDao.getAllPayments()

        if (!filterStart.isNullOrBlank() && !filterEnd.isNullOrBlank()) {
            workDays = workDays.filter { it.date in filterStart..filterEnd }
            overtimes = overtimes.filter { it.date in filterStart..filterEnd }
            payments = payments.filter { p ->
                val pCanonical = p.canonicalDate.ifBlank {
                    PersianCalendarHelper.extractCanonicalDate(p.persianDate)
                }
                pCanonical in filterStart..filterEnd
            }
        }

        val totalDays = workDays.sumOf { it.workDayAmount }
        val totalHours = overtimes.sumOf { it.overtimeHours }
        var totalAmount = 0L
        for (p in payments) {
            totalAmount = try {
                Math.addExact(totalAmount, p.amountToman)
            } catch (e: ArithmeticException) {
                Long.MAX_VALUE
            }
        }

        // Group payments by month key (e.g. "مهر ۱۴۰۵")
        val monthlyMap = LinkedHashMap<String, Long>()
        for (p in payments) {
            val key = p.persianMonthKey.ifBlank {
                val pCanonical = p.canonicalDate.ifBlank {
                    PersianCalendarHelper.extractCanonicalDate(p.persianDate)
                }
                val parsed = PersianCalendarHelper.parseCanonicalDate(pCanonical)
                parsed?.toMonthYearKey() ?: "نامشخص"
            }
            val current = monthlyMap[key] ?: 0L
            monthlyMap[key] = try {
                Math.addExact(current, p.amountToman)
            } catch (e: ArithmeticException) {
                Long.MAX_VALUE
            }
        }

        val monthlyList = monthlyMap.map { (key, sum) ->
            MonthlyStat(monthKey = key, totalAmountToman = sum)
        }

        // Group overtimes by month key
        val otMonthlyMap = LinkedHashMap<String, Double>()
        for (ot in overtimes) {
            val parsed = PersianCalendarHelper.parseCanonicalDate(ot.date)
            val key = parsed?.toMonthYearKey() ?: "نامشخص"
            otMonthlyMap[key] = (otMonthlyMap[key] ?: 0.0) + ot.overtimeHours
        }
        val otMonthlyList = otMonthlyMap.map { (key, sum) ->
            MonthlyOvertimeStat(monthKey = key, totalHours = sum)
        }

        val rates = rateDao.getAllRates()
        val financialSummary = FinancialCalculator.calculateFinancialBalances(
            workDays = workDays,
            overtimes = overtimes,
            payments = payments,
            rates = rates
        )

        return StatisticsResult(
            totalWorkDays = totalDays,
            totalOvertimeHours = totalHours,
            totalPaymentAmount = totalAmount,
            monthlyPayments = monthlyList,
            monthlyOvertimes = otMonthlyList,
            dateRangeLabel = label,
            financialSummary = financialSummary
        )
    }

    suspend fun getAllHistoryData(): Triple<List<WorkDay>, List<Overtime>, List<Payment>> {
        return Triple(
            workDayDao.getAllWorkDays(),
            overtimeDao.getAllOvertime(),
            paymentDao.getAllPayments()
        )
    }

    suspend fun exportBackupJson(): String {
        val workDays = workDayDao.getAllWorkDays()
        val overtimes = overtimeDao.getAllOvertime()
        val payments = paymentDao.getAllPayments()
        val recovery = recoveryDao.getAllRecovery()

        val root = JSONObject()
        root.put("version", 1)
        root.put("appName", "اضافه کاری من")
        root.put("exportedAt", System.currentTimeMillis())
        root.put("exportedDate", PersianCalendarHelper.getTodayPersianDate().toLongFormat())

        val wdArray = org.json.JSONArray()
        for (wd in workDays) {
            val obj = JSONObject()
            obj.put("date", wd.date)
            obj.put("persianDate", wd.persianDate)
            obj.put("gregorianDate", wd.gregorianDate)
            obj.put("workDayAmount", wd.workDayAmount)
            obj.put("createdAt", wd.createdAt)
            obj.put("updatedAt", wd.updatedAt)
            wdArray.put(obj)
        }
        root.put("workDays", wdArray)

        val otArray = org.json.JSONArray()
        for (ot in overtimes) {
            val obj = JSONObject()
            obj.put("date", ot.date)
            obj.put("persianDate", ot.persianDate)
            obj.put("gregorianDate", ot.gregorianDate)
            obj.put("overtimeHours", ot.overtimeHours)
            obj.put("createdAt", ot.createdAt)
            otArray.put(obj)
        }
        root.put("overtimes", otArray)

        val pmtArray = org.json.JSONArray()
        for (p in payments) {
            val obj = JSONObject()
            obj.put("amountToman", p.amountToman)
            obj.put("canonicalDate", p.canonicalDate.ifBlank { PersianCalendarHelper.extractCanonicalDate(p.persianDate) })
            obj.put("persianDate", p.persianDate)
            obj.put("persianMonthKey", p.persianMonthKey)
            obj.put("gregorianDate", p.gregorianDate)
            obj.put("time", p.time)
            obj.put("amountInWords", p.amountInWords)
            obj.put("createdAt", p.createdAt)
            pmtArray.put(obj)
        }
        root.put("payments", pmtArray)

        val recArray = org.json.JSONArray()
        for (r in recovery) {
            val obj = JSONObject()
            obj.put("originalRecordType", r.originalRecordType)
            obj.put("originalRecordId", r.originalRecordId)
            obj.put("deletedAt", r.deletedAt)
            obj.put("originalData", r.originalData)
            obj.put("title", r.title)
            obj.put("summaryText", r.summaryText)
            recArray.put(obj)
        }
        root.put("recoveryRecords", recArray)

        val rates = rateDao.getAllRates()
        val ratesArray = org.json.JSONArray()
        for (r in rates) {
            val obj = JSONObject()
            obj.put("effectiveFrom", r.effectiveFrom)
            obj.put("dailyWage", r.dailyWage)
            obj.put("overtimeMultiplier", r.overtimeMultiplier)
            obj.put("dailyHours", r.dailyHours)
            obj.put("createdAt", r.createdAt)
            ratesArray.put(obj)
        }
        root.put("rateSettings", ratesArray)

        return root.toString(2)
    }

    suspend fun restoreBackupJson(jsonString: String): Result<RestoreSummary> {
        return try {
            val root = JSONObject(jsonString)
            val version = root.optInt("version", -1)
            if (version < 1) {
                return Result.failure(IllegalArgumentException("فایل پشتیبان معتبر نیست."))
            }

            var wdCount = 0
            var otCount = 0
            var pmtCount = 0
            var skippedWd = 0
            var skippedOt = 0
            var skippedPmt = 0

            val wdArray = root.optJSONArray("workDays")
            if (wdArray != null) {
                for (i in 0 until wdArray.length()) {
                    val obj = wdArray.getJSONObject(i)
                    val date = obj.getString("date")
                    val persianDate = obj.optString("persianDate", date)
                    val gregorianDate = obj.optString("gregorianDate", "-")
                    val amount = obj.getDouble("workDayAmount")

                    val existing = workDayDao.getWorkDayByDate(date)
                    if (existing != null) {
                        skippedWd++
                    } else {
                        val newRecord = WorkDay(
                            date = date,
                            persianDate = persianDate,
                            gregorianDate = gregorianDate,
                            workDayAmount = amount
                        )
                        workDayDao.insertWorkDay(newRecord)
                        wdCount++
                    }
                }
            }

            val otArray = root.optJSONArray("overtimes")
            if (otArray != null) {
                for (i in 0 until otArray.length()) {
                    val obj = otArray.getJSONObject(i)
                    val date = obj.getString("date")
                    val persianDate = obj.optString("persianDate", date)
                    val gregorianDate = obj.optString("gregorianDate", "-")
                    val hours = obj.getDouble("overtimeHours")

                    val existing = overtimeDao.getOvertimeByDate(date)
                    if (existing != null) {
                        skippedOt++
                    } else {
                        if (hours > 0.0) {
                            val newRecord = Overtime(
                                workDayId = 0,
                                date = date,
                                persianDate = persianDate,
                                gregorianDate = gregorianDate,
                                overtimeHours = hours
                            )
                            overtimeDao.insertOvertime(newRecord)
                            otCount++
                        }
                    }
                }
            }

            val pmtArray = root.optJSONArray("payments")
            if (pmtArray != null) {
                val existingPayments = paymentDao.getAllPayments()
                for (i in 0 until pmtArray.length()) {
                    val obj = pmtArray.getJSONObject(i)
                    val amountToman = obj.getLong("amountToman")
                    val persianDate = obj.getString("persianDate")
                    val canonicalDate = obj.optString("canonicalDate").ifBlank {
                        PersianCalendarHelper.extractCanonicalDate(persianDate)
                    }
                    val persianMonthKey = obj.optString("persianMonthKey", "")
                    val gregorianDate = obj.optString("gregorianDate", "-")
                    val time = obj.optString("time", "12:00")
                    val words = obj.optString("amountInWords", "")

                    val isDuplicate = existingPayments.any {
                        val existingCanonical = it.canonicalDate.ifBlank {
                            PersianCalendarHelper.extractCanonicalDate(it.persianDate)
                        }
                        existingCanonical == canonicalDate && it.amountToman == amountToman && it.time == time
                    }
                    if (isDuplicate) {
                        skippedPmt++
                    } else {
                        savePayment(
                            amountToman = amountToman,
                            canonicalDate = canonicalDate,
                            persianDate = persianDate,
                            persianMonthKey = persianMonthKey,
                            gregorianDate = gregorianDate,
                            time = time,
                            amountInWords = words
                        )
                        pmtCount++
                    }
                }
            }

            val rateArray = root.optJSONArray("rateSettings")
            if (rateArray != null) {
                val existingRates = rateDao.getAllRates()
                for (i in 0 until rateArray.length()) {
                    val obj = rateArray.getJSONObject(i)
                    val effectiveFrom = obj.getString("effectiveFrom")
                    val dailyWage = obj.getLong("dailyWage")
                    val otMult = obj.optDouble("overtimeMultiplier", 1.4)
                    val dailyHours = obj.optDouble("dailyHours", 8.0)

                    val exists = existingRates.any {
                        it.effectiveFrom == effectiveFrom && it.dailyWage == dailyWage
                    }
                    if (!exists) {
                        saveRate(
                            id = 0,
                            effectiveFrom = effectiveFrom,
                            dailyWage = dailyWage,
                            overtimeMultiplier = otMult,
                            dailyHours = dailyHours
                        )
                    }
                }
            }

            val totalSkipped = skippedWd + skippedOt + skippedPmt
            Result.success(
                RestoreSummary(
                    workDaysCount = wdCount,
                    overtimesCount = otCount,
                    paymentsCount = pmtCount,
                    skippedWorkDaysCount = skippedWd,
                    skippedOvertimesCount = skippedOt,
                    skippedPaymentsCount = skippedPmt,
                    skippedTotalCount = totalSkipped
                )
            )
        } catch (e: Exception) {
            e.printStackTrace()
            Result.failure(IllegalArgumentException("فایل پشتیبان معتبر نیست: ${e.message}"))
        }
    }
}
