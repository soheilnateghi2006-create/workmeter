package com.example.util

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import android.os.Build
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import androidx.core.content.FileProvider
import com.example.data.model.Overtime
import com.example.data.model.Payment
import com.example.data.model.WorkDay
import com.example.data.repository.StatisticsResult
import java.io.File
import java.io.FileOutputStream

object PdfExporter {

    fun generateAndSharePdf(
        context: Context,
        workDays: List<WorkDay>,
        overtimes: List<Overtime>,
        payments: List<Payment>,
        stats: StatisticsResult
    ): File? {
        val pdfDoc = PdfDocument()
        val pageWidth = 595 // Standard A4 width in pt
        val pageHeight = 842 // Standard A4 height in pt

        var pageNumber = 1
        var pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
        var page = pdfDoc.startPage(pageInfo)
        var canvas = page.canvas

        val paint = Paint().apply {
            isAntiAlias = true
        }

        val textPaint = TextPaint().apply {
            isAntiAlias = true
            color = Color.DKGRAY
            textSize = 12f
        }

        var currentY = 40f
        val margin = 36f
        val contentWidth = pageWidth - (margin * 2)

        fun drawRtlText(
            text: String,
            x: Float,
            y: Float,
            size: Float,
            color: Int = Color.BLACK,
            isBold: Boolean = false,
            align: Paint.Align = Paint.Align.RIGHT
        ) {
            paint.color = color
            paint.textSize = size
            paint.isFakeBoldText = isBold
            paint.textAlign = align
            canvas.drawText(text, x, y, paint)
        }

        fun drawDivider(y: Float) {
            paint.color = Color.LTGRAY
            paint.strokeWidth = 1f
            canvas.drawLine(margin, y, pageWidth - margin, y, paint)
        }

        // Header Background
        paint.color = Color.rgb(30, 41, 59) // Deep slate blue
        canvas.drawRoundRect(RectF(margin, currentY, pageWidth - margin, currentY + 70f), 8f, 8f, paint)

        drawRtlText("گزارش جامع کارکرد، اضافه کاری و مبالغ دریافتی", pageWidth - margin - 16f, currentY + 30f, 15f, Color.WHITE, true)
        val todayPersian = PersianCalendarHelper.getTodayPersianDate().toLongFormat()
        drawRtlText("تاریخ گزارش: $todayPersian  |  برنامه «اضافه کاری من»", pageWidth - margin - 16f, currentY + 54f, 10f, Color.rgb(203, 213, 225), false)

        currentY += 86f

        // Summary Box
        paint.color = Color.rgb(241, 245, 249)
        canvas.drawRoundRect(RectF(margin, currentY, pageWidth - margin, currentY + 110f), 8f, 8f, paint)

        drawRtlText("خلاصه کل محاسبات", pageWidth - margin - 16f, currentY + 24f, 13f, Color.rgb(15, 23, 42), true)
        drawDivider(currentY + 32f)

        val col1X = pageWidth - margin - 16f
        val col2X = margin + (contentWidth / 2f)

        drawRtlText("مجموع روزهای کامل:", col1X, currentY + 54f, 11f, Color.rgb(71, 85, 105), false)
        drawRtlText(PersianCalendarHelper.formatWorkDays(stats.totalWorkDays), col1X - 110f, currentY + 54f, 12f, Color.rgb(15, 23, 42), true)

        drawRtlText("مجموع اضافه کاری:", col2X, currentY + 54f, 11f, Color.rgb(71, 85, 105), false)
        drawRtlText(PersianCalendarHelper.formatHours(stats.totalOvertimeHours), col2X - 100f, currentY + 54f, 12f, Color.rgb(15, 23, 42), true)

        drawRtlText("مجموع مبالغ دریافتی:", col1X, currentY + 80f, 11f, Color.rgb(71, 85, 105), false)
        drawRtlText(PersianCalendarHelper.formatAmountToman(stats.totalPaymentAmount), col1X - 110f, currentY + 80f, 12f, Color.rgb(14, 116, 144), true)

        val paymentWords = PersianCalendarHelper.amountToPersianWordsWithToman(stats.totalPaymentAmount)
        drawRtlText("به حروف: $paymentWords", col1X, currentY + 98f, 9.5f, Color.rgb(100, 116, 139), false)

        currentY += 126f

        // Monthly Payments Section
        if (stats.monthlyPayments.isNotEmpty()) {
            drawRtlText("مبالغ دریافتی ماهانه:", pageWidth - margin, currentY, 13f, Color.rgb(15, 23, 42), true)
            currentY += 16f

            for (monthStat in stats.monthlyPayments) {
                paint.color = Color.rgb(248, 250, 252)
                canvas.drawRect(RectF(margin, currentY, pageWidth - margin, currentY + 24f), paint)
                drawRtlText(monthStat.monthKey, pageWidth - margin - 10f, currentY + 16f, 11f, Color.rgb(30, 41, 59), true)
                drawRtlText(PersianCalendarHelper.formatAmountToman(monthStat.totalAmountToman), margin + 10f, currentY + 16f, 11f, Color.rgb(14, 116, 144), true, Paint.Align.LEFT)
                currentY += 28f
            }
            currentY += 10f
        }

        // Financial Balance Section
        val finSummary = stats.financialSummary
        if (finSummary != null && finSummary.monthlyBalances.isNotEmpty()) {
            if (currentY > pageHeight - 140f) {
                pdfDoc.finishPage(page)
                pageNumber++
                pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
                page = pdfDoc.startPage(pageInfo)
                canvas = page.canvas
                currentY = 40f
            }

            drawRtlText("تراز مالی و تسویه‌حساب ماهانه:", pageWidth - margin, currentY, 13f, Color.rgb(15, 23, 42), true)
            currentY += 16f

            if (finSummary.hasAnyMissingRate) {
                drawRtlText("هشدار: برای بخشی از روزهای این بازه نرخی تعریف نشده است.", pageWidth - margin, currentY, 9.5f, Color.rgb(185, 28, 28), true)
                currentY += 16f
            }

            // Table Header
            paint.color = Color.rgb(226, 232, 240)
            canvas.drawRect(RectF(margin, currentY, pageWidth - margin, currentY + 22f), paint)

            val colFinMonth = pageWidth - margin - 10f
            val colFinEntitled = pageWidth - margin - 100f
            val colFinPayment = pageWidth - margin - 200f
            val colFinBalance = pageWidth - margin - 310f
            val colFinCumul = margin + 10f

            drawRtlText("ماه", colFinMonth, currentY + 15f, 9f, Color.BLACK, true)
            drawRtlText("استحقاقی", colFinEntitled, currentY + 15f, 9f, Color.BLACK, true)
            drawRtlText("دریافتی", colFinPayment, currentY + 15f, 9f, Color.BLACK, true)
            drawRtlText("مانده ماه", colFinBalance, currentY + 15f, 9f, Color.BLACK, true)
            drawRtlText("مانده تجمعی", colFinCumul, currentY + 15f, 9f, Color.BLACK, true, Paint.Align.LEFT)

            currentY += 26f

            for (m in finSummary.monthlyBalances) {
                if (currentY > pageHeight - 60f) {
                    pdfDoc.finishPage(page)
                    pageNumber++
                    pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
                    page = pdfDoc.startPage(pageInfo)
                    canvas = page.canvas
                    currentY = 40f
                }

                val balanceStr = when {
                    m.balance < 0 -> "${PersianCalendarHelper.formatAmountToman(-m.balance)} (طلب)"
                    m.balance > 0 -> "${PersianCalendarHelper.formatAmountToman(m.balance)} (پیش‌دریافت)"
                    else -> "تسویه"
                }

                val cumulStr = when {
                    m.cumulativeBalance < 0 -> "${PersianCalendarHelper.formatAmountToman(-m.cumulativeBalance)} (طلب)"
                    m.cumulativeBalance > 0 -> "${PersianCalendarHelper.formatAmountToman(m.cumulativeBalance)} (پیش‌دریافت)"
                    else -> "تسویه"
                }

                val balanceColor = when {
                    m.balance < 0 -> Color.rgb(185, 28, 28)
                    m.balance > 0 -> Color.rgb(22, 101, 52)
                    else -> Color.DKGRAY
                }

                val cumulColor = when {
                    m.cumulativeBalance < 0 -> Color.rgb(185, 28, 28)
                    m.cumulativeBalance > 0 -> Color.rgb(22, 101, 52)
                    else -> Color.DKGRAY
                }

                drawRtlText(m.monthKey, colFinMonth, currentY + 14f, 9f, Color.DKGRAY, false)
                drawRtlText(PersianCalendarHelper.formatAmountToman(m.entitledAmount), colFinEntitled, currentY + 14f, 9f, Color.DKGRAY, false)
                drawRtlText(PersianCalendarHelper.formatAmountToman(m.paymentAmount), colFinPayment, currentY + 14f, 9f, Color.rgb(14, 116, 144), false)
                drawRtlText(balanceStr, colFinBalance, currentY + 14f, 9f, balanceColor, true)
                drawRtlText(cumulStr, colFinCumul, currentY + 14f, 9f, cumulColor, true, Paint.Align.LEFT)

                drawDivider(currentY + 20f)
                currentY += 24f
            }
            currentY += 12f
        }

        // Details Table Header
        drawRtlText("ریز جزئیات کارکرد، اضافه کاری و دریافتی‌ها:", pageWidth - margin, currentY, 13f, Color.rgb(15, 23, 42), true)
        currentY += 16f

        // Table Header row
        paint.color = Color.rgb(226, 232, 240)
        canvas.drawRect(RectF(margin, currentY, pageWidth - margin, currentY + 24f), paint)

        val colPersianDate = pageWidth - margin - 10f
        val colGregDate = pageWidth - margin - 120f
        val colWorkDay = pageWidth - margin - 230f
        val colOvertime = pageWidth - margin - 320f
        val colPayment = margin + 10f

        drawRtlText("تاریخ شمسی", colPersianDate, currentY + 16f, 10f, Color.BLACK, true)
        drawRtlText("تاریخ میلادی", colGregDate, currentY + 16f, 10f, Color.BLACK, true)
        drawRtlText("روز کاری", colWorkDay, currentY + 16f, 10f, Color.BLACK, true)
        drawRtlText("اضافه کاری", colOvertime, currentY + 16f, 10f, Color.BLACK, true)
        drawRtlText("دریافتی", colPayment, currentY + 16f, 10f, Color.BLACK, true, Paint.Align.LEFT)

        currentY += 28f

        // Combine date records for a clean tabular layout
        val allDates = (workDays.map { it.date } + overtimes.map { it.date } + payments.map {
            it.canonicalDate.ifBlank { PersianCalendarHelper.extractCanonicalDate(it.persianDate) }
        }).filter { it.isNotBlank() }.distinct().sortedDescending()

        val workDayMap = workDays.associateBy { it.date }
        val overtimeMap = overtimes.associateBy { it.date }

        for (d in allDates) {
            val wd = workDayMap[d]
            val ot = overtimeMap[d]
            val pmts = payments.filter {
                val pCanonical = it.canonicalDate.ifBlank { PersianCalendarHelper.extractCanonicalDate(it.persianDate) }
                pCanonical == d
            }

            val pDate = wd?.persianDate ?: ot?.persianDate ?: d
            val gDate = wd?.gregorianDate ?: ot?.gregorianDate ?: "-"
            val wdVal = if (wd != null) PersianCalendarHelper.formatWorkDays(wd.workDayAmount) else "-"
            val otVal = if (ot != null) PersianCalendarHelper.formatHours(ot.overtimeHours) else "-"
            val pmtVal = if (pmts.isNotEmpty()) {
                PersianCalendarHelper.formatAmountToman(pmts.sumOf { it.amountToman })
            } else {
                "-"
            }

            // Check if page overflow
            if (currentY > pageHeight - 60f) {
                pdfDoc.finishPage(page)
                pageNumber++
                pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
                page = pdfDoc.startPage(pageInfo)
                canvas = page.canvas
                currentY = 40f
            }

            drawRtlText(pDate, colPersianDate, currentY + 14f, 9.5f, Color.DKGRAY, false)
            drawRtlText(gDate, colGregDate, currentY + 14f, 9f, Color.GRAY, false)
            drawRtlText(wdVal, colWorkDay, currentY + 14f, 9.5f, Color.DKGRAY, false)
            drawRtlText(otVal, colOvertime, currentY + 14f, 9.5f, Color.DKGRAY, false)
            drawRtlText(pmtVal, colPayment, currentY + 14f, 9.5f, if (pmtVal != "-") Color.rgb(14, 116, 144) else Color.GRAY, pmtVal != "-", Paint.Align.LEFT)

            drawDivider(currentY + 20f)
            currentY += 24f
        }

        // Footer on last page
        drawRtlText("قوانین: هر ۱۰ ساعت کارکرد = ۱ روز کاری  |  هر ۸ ساعت اضافه کار = ۱ روز کاری", pageWidth / 2f, pageHeight - 30f, 9f, Color.GRAY, false, Paint.Align.CENTER)

        pdfDoc.finishPage(page)

        return try {
            val cacheDir = File(context.cacheDir, "pdf_reports")
            if (!cacheDir.exists()) cacheDir.mkdirs()
            val pdfFile = File(cacheDir, "overtime_report_${System.currentTimeMillis()}.pdf")
            val outputStream = FileOutputStream(pdfFile)
            pdfDoc.writeTo(outputStream)
            outputStream.flush()
            outputStream.close()
            pdfDoc.close()

            // Trigger Share Intent
            val uri = FileProvider.getUriForFile(
                context,
                context.packageName + ".fileprovider",
                pdfFile
            )

            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, "گزارش اضافه کاری من")
                putExtra(Intent.EXTRA_TEXT, "گزارش کامل کارکرد و اضافه کاری من")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(Intent.createChooser(shareIntent, "اشتراک گذاری یا ذخیره PDF").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            })

            pdfFile
        } catch (e: Exception) {
            e.printStackTrace()
            pdfDoc.close()
            null
        }
    }
}
