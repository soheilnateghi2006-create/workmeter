package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Indigo / Sky
val PrimaryBlue = Color(0xFF0284C7)
val PrimaryBlueDark = Color(0xFF38BDF8)

// Secondary Teal / Emerald
val SecondaryTeal = Color(0xFF0D9488)
val SecondaryTealDark = Color(0xFF2DD4BF)

// Overtime / Accent Amber
val AccentAmber = Color(0xFFD97706)
val AccentAmberDark = Color(0xFFFBBF24)

// Neutral Light
val BackgroundLight = Color(0xFFF8FAFC)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFF1F5F9)
val OnSurfaceLight = Color(0xFF0F172A)
val OnSurfaceVariantLight = Color(0xFF475569)

// Neutral Dark
val BackgroundDark = Color(0xFF0B0F19)
val SurfaceDark = Color(0xFF131B2E)
val SurfaceVariantDark = Color(0xFF1E293B)
val OnSurfaceDark = Color(0xFFF8FAFC)
val OnSurfaceVariantDark = Color(0xFF94A3B8)
