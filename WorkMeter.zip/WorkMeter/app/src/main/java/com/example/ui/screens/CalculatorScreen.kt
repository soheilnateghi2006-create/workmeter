package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.util.PersianCalendarHelper
import java.text.DecimalFormat

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CalculatorScreen(
    onNavigateBack: () -> Unit
) {
    var displayValue by remember { mutableStateOf("0") }
    var operand1 by remember { mutableDoubleStateOf(0.0) }
    var pendingOperator by remember { mutableStateOf<String?>(null) }
    var shouldResetDisplayOnNextDigit by remember { mutableStateOf(false) }

    fun formatResult(value: Double): String {
        return if (value % 1.0 == 0.0 && kotlin.math.abs(value) < 1e12) {
            value.toLong().toString()
        } else {
            val df = DecimalFormat("#.########", java.text.DecimalFormatSymbols(java.util.Locale.US))
            df.format(value)
        }
    }

    fun showDivideByZeroError() {
        displayValue = "تقسیم بر صفر"
        operand1 = 0.0
        pendingOperator = null
        shouldResetDisplayOnNextDigit = true
    }

    fun onDigit(d: String) {
        if (shouldResetDisplayOnNextDigit || displayValue == "0") {
            displayValue = d
            shouldResetDisplayOnNextDigit = false
        } else {
            if (displayValue.length < 12) {
                displayValue += d
            }
        }
    }

    fun onDecimal() {
        if (shouldResetDisplayOnNextDigit) {
            displayValue = "0."
            shouldResetDisplayOnNextDigit = false
        } else if (!displayValue.contains(".")) {
            displayValue += "."
        }
    }

    fun onClear() {
        displayValue = "0"
        operand1 = 0.0
        pendingOperator = null
        shouldResetDisplayOnNextDigit = false
    }

    fun onNegate() {
        val current = displayValue.toDoubleOrNull() ?: 0.0
        if (current != 0.0) {
            displayValue = formatResult(-current)
        }
    }

    fun onPercent() {
        val current = displayValue.toDoubleOrNull() ?: 0.0
        displayValue = formatResult(current / 100.0)
    }

    fun onOperator(op: String) {
        val current = displayValue.toDoubleOrNull() ?: 0.0
        if (pendingOperator == "÷" && !shouldResetDisplayOnNextDigit && current == 0.0) {
            showDivideByZeroError()
            return
        }
        if (pendingOperator != null && !shouldResetDisplayOnNextDigit) {
            // Compute intermediate
            val res = when (pendingOperator) {
                "+" -> operand1 + current
                "−" -> operand1 - current
                "×" -> operand1 * current
                "÷" -> if (current != 0.0) operand1 / current else 0.0
                else -> current
            }
            operand1 = res
            displayValue = formatResult(res)
        } else {
            operand1 = current
        }
        pendingOperator = op
        shouldResetDisplayOnNextDigit = true
    }

    fun onEquals() {
        val current = displayValue.toDoubleOrNull() ?: 0.0
        if (pendingOperator == "÷" && current == 0.0) {
            showDivideByZeroError()
            return
        }
        if (pendingOperator != null) {
            val res = when (pendingOperator) {
                "+" -> operand1 + current
                "−" -> operand1 - current
                "×" -> operand1 * current
                "÷" -> if (current != 0.0) operand1 / current else 0.0
                else -> current
            }
            displayValue = formatResult(res)
            pendingOperator = null
            shouldResetDisplayOnNextDigit = true
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "ماشین حساب",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "بازگشت"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 20.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.Bottom
        ) {
            // Large Display (iPhone calculator inspired)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.BottomEnd
            ) {
                Column(horizontalAlignment = Alignment.End) {
                    if (pendingOperator != null) {
                        Text(
                            text = "${formatResult(operand1)} $pendingOperator",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Text(
                        text = PersianCalendarHelper.toPersianDigits(displayValue),
                        fontSize = when {
                            displayValue.length > 9 -> 38.sp
                            displayValue.length > 6 -> 48.sp
                            else -> 56.sp
                        },
                        fontWeight = FontWeight.Light,
                        color = MaterialTheme.colorScheme.onSurface,
                        textAlign = TextAlign.End,
                        maxLines = 1,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("calculator_display")
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Buttons Grid
            val topRowColor = Color(0xFFA5A5A5) // Light grey
            val numColor = Color(0xFF333333) // Dark grey
            val opColor = Color(0xFFFF9F0A) // Vibrant Orange
            val lightTheme = MaterialTheme.colorScheme.background.red > 0.5f

            val buttonBgTop = if (lightTheme) Color(0xFFD4D4D2) else Color(0xFFA5A5A5)
            val buttonBgNum = if (lightTheme) Color(0xFFE5E5EA) else Color(0xFF333333)
            val textColorNum = if (lightTheme) Color.Black else Color.White
            val textColorTop = Color.Black

            // Row 1: AC, +/-, %, ÷
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                CalcButton(text = "AC", bgColor = buttonBgTop, textColor = textColorTop, modifier = Modifier.weight(1f)) { onClear() }
                CalcButton(text = "+/−", bgColor = buttonBgTop, textColor = textColorTop, modifier = Modifier.weight(1f)) { onNegate() }
                CalcButton(text = "%", bgColor = buttonBgTop, textColor = textColorTop, modifier = Modifier.weight(1f)) { onPercent() }
                CalcButton(text = "÷", bgColor = opColor, textColor = Color.White, modifier = Modifier.weight(1f)) { onOperator("÷") }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Row 2: 7, 8, 9, ×
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                CalcButton(text = "۷", tag = "7", bgColor = buttonBgNum, textColor = textColorNum, modifier = Modifier.weight(1f)) { onDigit("7") }
                CalcButton(text = "۸", tag = "8", bgColor = buttonBgNum, textColor = textColorNum, modifier = Modifier.weight(1f)) { onDigit("8") }
                CalcButton(text = "۹", tag = "9", bgColor = buttonBgNum, textColor = textColorNum, modifier = Modifier.weight(1f)) { onDigit("9") }
                CalcButton(text = "×", bgColor = opColor, textColor = Color.White, modifier = Modifier.weight(1f)) { onOperator("×") }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Row 3: 4, 5, 6, −
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                CalcButton(text = "۴", tag = "4", bgColor = buttonBgNum, textColor = textColorNum, modifier = Modifier.weight(1f)) { onDigit("4") }
                CalcButton(text = "۵", tag = "5", bgColor = buttonBgNum, textColor = textColorNum, modifier = Modifier.weight(1f)) { onDigit("5") }
                CalcButton(text = "۶", tag = "6", bgColor = buttonBgNum, textColor = textColorNum, modifier = Modifier.weight(1f)) { onDigit("6") }
                CalcButton(text = "−", bgColor = opColor, textColor = Color.White, modifier = Modifier.weight(1f)) { onOperator("−") }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Row 4: 1, 2, 3, +
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                CalcButton(text = "۱", tag = "1", bgColor = buttonBgNum, textColor = textColorNum, modifier = Modifier.weight(1f)) { onDigit("1") }
                CalcButton(text = "۲", tag = "2", bgColor = buttonBgNum, textColor = textColorNum, modifier = Modifier.weight(1f)) { onDigit("2") }
                CalcButton(text = "۳", tag = "3", bgColor = buttonBgNum, textColor = textColorNum, modifier = Modifier.weight(1f)) { onDigit("3") }
                CalcButton(text = "+", bgColor = opColor, textColor = Color.White, modifier = Modifier.weight(1f)) { onOperator("+") }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Row 5: 0 (wide), ., =
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                CalcButton(text = "۰", tag = "0", bgColor = buttonBgNum, textColor = textColorNum, modifier = Modifier.weight(2f), isWide = true) { onDigit("0") }
                CalcButton(text = ".", bgColor = buttonBgNum, textColor = textColorNum, modifier = Modifier.weight(1f)) { onDecimal() }
                CalcButton(text = "=", bgColor = opColor, textColor = Color.White, modifier = Modifier.weight(1f)) { onEquals() }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
private fun CalcButton(
    text: String,
    bgColor: Color,
    textColor: Color,
    modifier: Modifier = Modifier,
    tag: String = text,
    isWide: Boolean = false,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .aspectRatio(if (isWide) 2.1f else 1f)
            .clip(CircleShape)
            .background(bgColor)
            .clickable(onClick = onClick)
            .testTag("calc_btn_$tag"),
        contentAlignment = if (isWide) Alignment.CenterStart else Alignment.Center
    ) {
        Text(
            text = text,
            color = textColor,
            fontSize = 26.sp,
            fontWeight = FontWeight.Medium,
            modifier = if (isWide) Modifier.padding(start = 28.dp) else Modifier
        )
    }
}
