package com.example.ui.dialogs

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.PriceChange
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.RateSetting
import com.example.ui.components.CenteredSmoothDialog
import com.example.ui.components.PersianDatePickerDialog
import com.example.util.PersianCalendarHelper

@Composable
fun RateRegisterDialog(
    initialRate: RateSetting? = null,
    onSave: (effectiveFrom: String, dailyWage: Long, overtimeMultiplier: Double, dailyHours: Double) -> Unit,
    onDismissRequest: () -> Unit
) {
    var rawAmountInput by remember {
        mutableStateOf(if (initialRate != null && initialRate.dailyWage > 0) initialRate.dailyWage.toString() else "")
    }

    var selectedPersianDate by remember {
        mutableStateOf(
            if (initialRate != null && initialRate.effectiveFrom.isNotBlank()) {
                PersianCalendarHelper.parseCanonicalDate(initialRate.effectiveFrom)
                    ?: PersianCalendarHelper.getTodayPersianDate()
            } else {
                PersianCalendarHelper.getTodayPersianDate()
            }
        )
    }

    var multiplierInput by remember {
        mutableStateOf(if (initialRate != null) initialRate.overtimeMultiplier.toString() else "1.4")
    }

    var dailyHoursInput by remember {
        mutableStateOf(if (initialRate != null) {
            if (initialRate.dailyHours % 1.0 == 0.0) initialRate.dailyHours.toInt().toString()
            else initialRate.dailyHours.toString()
        } else "8")
    }

    var showDatePicker by remember { mutableStateOf(false) }
    var validationError by remember { mutableStateOf<String?>(null) }

    val numericAmount = remember(rawAmountInput) {
        val digits = PersianCalendarHelper.toEnglishDigits(rawAmountInput).filter { it.isDigit() }
        digits.toLongOrNull() ?: 0L
    }

    val wordsText = remember(numericAmount) {
        if (numericAmount > 0) PersianCalendarHelper.amountToPersianWordsWithToman(numericAmount)
        else "صفر تومان"
    }

    if (showDatePicker) {
        PersianDatePickerDialog(
            initialDate = selectedPersianDate,
            onDateSelected = { pDate, _ ->
                selectedPersianDate = pDate
                showDatePicker = false
            },
            onDismissRequest = { showDatePicker = false }
        )
    }

    CenteredSmoothDialog(
        onDismissRequest = onDismissRequest,
        modifier = Modifier.testTag("rate_register_dialog"),
        icon = {
            Icon(
                Icons.Default.PriceChange,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(32.dp)
            )
        },
        title = {
            Text(
                text = if (initialRate == null) "تعریف نرخ جدید" else "ویرایش نرخ",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
        },
        content = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                // 1. Effective From Date Picker
                Text(
                    text = "تاریخ شروع اعتبار نرخ:",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(6.dp))

                OutlinedButton(
                    onClick = { showDatePicker = true },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("rate_effective_date_button"),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.CalendarToday,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "از تاریخ: ${selectedPersianDate.toLongFormat()} (${selectedPersianDate.toStandardString()})",
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // 2. Daily Wage Input (مبلغ به تومان)
                OutlinedTextField(
                    value = rawAmountInput,
                    onValueChange = { input ->
                        val digits = PersianCalendarHelper.toEnglishDigits(input).filter { it.isDigit() }
                        if (digits.length <= 15) {
                            rawAmountInput = digits
                            validationError = null
                        }
                    },
                    label = { Text("مبلغ دستمزد روزانه (تومان)") },
                    placeholder = { Text("مثلاً ۵۰۰۰۰۰ یا ۱۲۰۰۰۰۰") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("rate_daily_wage_input"),
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                // 3. Live Formatted Amount and Words Display (مبلغ به حروف فارسی زنده)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(
                            if (numericAmount > 0) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
                            else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
                        )
                        .padding(12.dp)
                ) {
                    Column {
                        Text(
                            text = if (numericAmount > 0)
                                PersianCalendarHelper.formatAmountToman(numericAmount)
                            else
                                "۰ تومان",
                            fontSize = when {
                                rawAmountInput.length > 11 -> 16.sp
                                rawAmountInput.length > 8 -> 18.sp
                                else -> 20.sp
                            },
                            fontWeight = FontWeight.Bold,
                            color = if (numericAmount > 0) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = wordsText,
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (numericAmount > 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                            fontWeight = if (numericAmount > 0) FontWeight.SemiBold else FontWeight.Normal
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // 4. Daily Hours & Overtime Multiplier Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Daily Hours
                    OutlinedTextField(
                        value = dailyHoursInput,
                        onValueChange = { input ->
                            dailyHoursInput = PersianCalendarHelper.toEnglishDigits(input)
                            validationError = null
                        },
                        label = { Text("ساعت کار روزانه") },
                        placeholder = { Text("8") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("rate_daily_hours_input"),
                        shape = RoundedCornerShape(12.dp)
                    )

                    Spacer(modifier = Modifier.width(10.dp))

                    // Overtime Multiplier
                    OutlinedTextField(
                        value = multiplierInput,
                        onValueChange = { input ->
                            multiplierInput = PersianCalendarHelper.toEnglishDigits(input)
                            validationError = null
                        },
                        label = { Text("ضریب اضافه‌کاری") },
                        placeholder = { Text("1.4") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("rate_multiplier_input"),
                        shape = RoundedCornerShape(12.dp)
                    )
                }

                // Equivalent hourly wage preview if valid
                val parsedHours = dailyHoursInput.toDoubleOrNull()
                val parsedMultiplier = multiplierInput.toDoubleOrNull()
                if (numericAmount > 0 && parsedHours != null && parsedHours > 0) {
                    val hourly = (numericAmount / parsedHours).toLong()
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "معادل ساعتی: ${PersianCalendarHelper.formatAmountToman(hourly)}" +
                                if (parsedMultiplier != null && parsedMultiplier > 0)
                                    "  |  اضافه‌کار: ${PersianCalendarHelper.formatAmountToman((hourly * parsedMultiplier).toLong())}"
                                else "",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.outline
                    )
                }

                if (validationError != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = validationError!!,
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (numericAmount <= 0) {
                        validationError = "لطفاً مبلغ دستمزد روزانه را وارد کنید."
                        return@Button
                    }
                    val hours = dailyHoursInput.toDoubleOrNull()
                    if (hours == null || hours <= 0) {
                        validationError = "ساعت کار روزانه باید بزرگتر از صفر باشد."
                        return@Button
                    }
                    val mult = multiplierInput.toDoubleOrNull()
                    if (mult == null || mult <= 0) {
                        validationError = "ضریب اضافه کاری باید عددی مثبت باشد (پیش‌فرض ۱.۴)."
                        return@Button
                    }

                    val canonicalDate = selectedPersianDate.toStandardString()
                    onSave(canonicalDate, numericAmount, mult, hours)
                },
                modifier = Modifier.testTag("save_rate_confirm_button"),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(if (initialRate == null) "ثبت نرخ" else "ذخیره تغییرات")
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismissRequest,
                modifier = Modifier.testTag("cancel_rate_button")
            ) {
                Text("انصراف")
            }
        }
    )
}
