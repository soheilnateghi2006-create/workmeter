package com.example.ui.screens

import android.app.Activity
import android.content.Context
import android.hardware.biometrics.BiometricPrompt
import android.os.Build
import android.os.CancellationSignal
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.CenteredSmoothDialog
import com.example.util.AppLockManager
import com.example.util.PersianCalendarHelper
import com.example.util.findActivity

@Composable
fun AppLockScreen(
    lockManager: AppLockManager,
    onUnlockSuccess: () -> Unit
) {
    val context = LocalContext.current
    var enteredPin by remember { mutableStateOf("") }
    var isError by remember { mutableStateOf(false) }
    var showResetDialog by remember { mutableStateOf(false) }
    var isBiometricPromptActive by remember { mutableStateOf(false) }
    var activeCancellationSignal by remember { mutableStateOf<CancellationSignal?>(null) }

    // Intercept Back press on lock screen to safely minimize app instead of terminating
    BackHandler {
        context.findActivity()?.moveTaskToBack(true)
    }

    fun triggerBiometric() {
        if (isBiometricPromptActive) return

        val activity = context.findActivity() ?: return
        if (activity.isFinishing || activity.isDestroyed) return

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P &&
            lockManager.isBiometricEnabled &&
            lockManager.isBiometricHardwareAvailable(context)
        ) {
            try {
                try {
                    activeCancellationSignal?.cancel()
                } catch (_: Throwable) {}

                val signal = CancellationSignal()
                activeCancellationSignal = signal
                isBiometricPromptActive = true

                val prompt = BiometricPrompt.Builder(activity)
                    .setTitle("ورود به اضافه کاری من")
                    .setSubtitle("احراز هویت با اثر انگشت یا چهره")
                    .setNegativeButton("استفاده از رمز عبور", activity.mainExecutor) { _, _ ->
                        isBiometricPromptActive = false
                    }
                    .build()

                prompt.authenticate(
                    signal,
                    activity.mainExecutor,
                    object : BiometricPrompt.AuthenticationCallback() {
                        override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult?) {
                            super.onAuthenticationSucceeded(result)
                            isBiometricPromptActive = false
                            activeCancellationSignal = null
                            onUnlockSuccess()
                        }

                        override fun onAuthenticationError(errorCode: Int, errString: CharSequence?) {
                            super.onAuthenticationError(errorCode, errString)
                            isBiometricPromptActive = false
                            activeCancellationSignal = null
                        }

                        override fun onAuthenticationFailed() {
                            super.onAuthenticationFailed()
                            // Non-fatal: fingerprint/face didn't match, user can retry or use PIN
                        }
                    }
                )
            } catch (_: Throwable) {
                isBiometricPromptActive = false
                activeCancellationSignal = null
            }
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            try {
                activeCancellationSignal?.cancel()
            } catch (_: Throwable) {}
            activeCancellationSignal = null
            isBiometricPromptActive = false
        }
    }

    LaunchedEffect(Unit) {
        triggerBiometric()
    }

    // Reset confirmation dialog
    if (showResetDialog) {
        CenteredSmoothDialog(
            onDismissRequest = { showResetDialog = false },
            icon = {
                Icon(Icons.Default.Lock, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(32.dp))
            },
            title = {
                Text("بازیابی و حذف قفل", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            },
            content = {
                Text(
                    text = "آیا می‌خواهید قفل برنامه حذف شود؟ تمام سوابق و اطلاعات کاری شما حفظ خواهد شد و فقط قفل امنیتی غیرفعال می‌شود.",
                    style = MaterialTheme.typography.bodyMedium
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        lockManager.resetLock()
                        showResetDialog = false
                        onUnlockSuccess()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("حذف قفل و ورود")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showResetDialog = false }) {
                    Text("انصراف")
                }
            }
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // App Lock Icon & Title
        Box(
            modifier = Modifier
                .size(72.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.primaryContainer),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                Icons.Default.Lock,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(36.dp)
            )
        }

        Spacer(modifier = Modifier.height(18.dp))

        Text(
            text = "اضافه کاری من",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground
        )

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = if (isError) "رمز عبور اشتباه است، دوباره تلاش کنید" else "رمز عبور ۴ رقمی خود را وارد کنید",
            style = MaterialTheme.typography.bodyMedium,
            color = if (isError) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(24.dp))

        // 4 PIN Dots
        Row(
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            for (i in 0 until 4) {
                val isFilled = i < enteredPin.length
                Box(
                    modifier = Modifier
                        .size(18.dp)
                        .clip(CircleShape)
                        .background(
                            if (isFilled) {
                                if (isError) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                            } else Color.Transparent
                        )
                        .border(
                            2.dp,
                            if (isError) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.outline,
                            CircleShape
                        )
                )
            }
        }

        Spacer(modifier = Modifier.height(36.dp))

        // Numeric Keypad
        val keys = listOf(
            listOf("1", "2", "3"),
            listOf("4", "5", "6"),
            listOf("7", "8", "9"),
            listOf("biometric", "0", "backspace")
        )

        Column(
            verticalArrangement = Arrangement.spacedBy(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            keys.forEach { rowKeys ->
                Row(
                    horizontalArrangement = Arrangement.spacedBy(20.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    rowKeys.forEach { key ->
                        when (key) {
                            "biometric" -> {
                                if (lockManager.isBiometricEnabled && lockManager.isBiometricHardwareAvailable(context)) {
                                    Box(
                                        modifier = Modifier
                                            .size(68.dp)
                                            .clip(CircleShape)
                                            .clickable { triggerBiometric() },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            Icons.Default.Fingerprint,
                                            contentDescription = "اثر انگشت",
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(32.dp)
                                        )
                                    }
                                } else {
                                    Spacer(modifier = Modifier.size(68.dp))
                                }
                            }
                            "backspace" -> {
                                Box(
                                    modifier = Modifier
                                        .size(68.dp)
                                        .clip(CircleShape)
                                        .clickable {
                                            if (enteredPin.isNotEmpty()) {
                                                enteredPin = enteredPin.dropLast(1)
                                                isError = false
                                            }
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        Icons.AutoMirrored.Filled.Backspace,
                                        contentDescription = "پاک کردن",
                                        tint = MaterialTheme.colorScheme.onSurface,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                            }
                            else -> {
                                Box(
                                    modifier = Modifier
                                        .size(68.dp)
                                        .clip(CircleShape)
                                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                                        .clickable {
                                            if (enteredPin.length < 4) {
                                                val newPin = enteredPin + key
                                                enteredPin = newPin
                                                isError = false

                                                if (newPin.length == 4) {
                                                    if (lockManager.verifyPin(newPin)) {
                                                        onUnlockSuccess()
                                                    } else {
                                                        isError = true
                                                        enteredPin = ""
                                                    }
                                                }
                                            }
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = PersianCalendarHelper.toPersianDigits(key),
                                        style = MaterialTheme.typography.titleLarge,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 24.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Reset flow button
        TextButton(onClick = { showResetDialog = true }) {
            Text("فراموشی رمز عبور؟", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
