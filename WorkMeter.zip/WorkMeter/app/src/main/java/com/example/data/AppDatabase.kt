package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.dao.OvertimeDao
import com.example.data.dao.PaymentDao
import com.example.data.dao.RateDao
import com.example.data.dao.RecoveryDao
import com.example.data.dao.WorkDayDao
import com.example.data.model.Overtime
import com.example.data.model.Payment
import com.example.data.model.RateSetting
import com.example.data.model.RecoveryRecord
import com.example.data.model.WorkDay
import com.example.util.PersianCalendarHelper

@Database(
    entities = [
        WorkDay::class,
        Overtime::class,
        Payment::class,
        RecoveryRecord::class,
        RateSetting::class
    ],
    version = 3,
    exportSchema = true
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun workDayDao(): WorkDayDao
    abstract fun overtimeDao(): OvertimeDao
    abstract fun paymentDao(): PaymentDao
    abstract fun recoveryDao(): RecoveryDao
    abstract fun rateDao(): RateDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                // 1. Add column canonicalDate with default empty string
                db.execSQL("ALTER TABLE payments ADD COLUMN canonicalDate TEXT NOT NULL DEFAULT ''")

                // 2. Populate canonicalDate for existing records from persianDate
                val cursor = db.query("SELECT id, persianDate FROM payments")
                cursor.use { c ->
                    val idIndex = c.getColumnIndexOrThrow("id")
                    val persianDateIndex = c.getColumnIndexOrThrow("persianDate")
                    while (c.moveToNext()) {
                        val id = c.getLong(idIndex)
                        val persianDate = c.getString(persianDateIndex) ?: ""
                        val canonical = PersianCalendarHelper.extractCanonicalDate(persianDate)
                        db.execSQL(
                            "UPDATE payments SET canonicalDate = ? WHERE id = ?",
                            arrayOf<Any>(canonical, id)
                        )
                    }
                }
            }
        }

        val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `rate_settings` (
                        `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        `effectiveFrom` TEXT NOT NULL,
                        `dailyWage` INTEGER NOT NULL,
                        `overtimeMultiplier` REAL NOT NULL,
                        `dailyHours` REAL NOT NULL,
                        `createdAt` INTEGER NOT NULL
                    )
                    """.trimIndent()
                )
            }
        }

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "ezfe_kari_man.db"
                ).addMigrations(MIGRATION_1_2, MIGRATION_2_3).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
