package com.example.util

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * High-precision Solar Hijri (Jalali / Persian) calendar conversion and formatting utilities.
 */
object PersianCalendarHelper {

    data class PersianDate(
        val year: Int,
        val month: Int,
        val day: Int
    ) {
        val monthName: String
            get() = getPersianMonthName(month)

        fun toFormattedString(): String {
            return "${toPersianDigits(year)}/${toPersianDigits(month.toString().padStart(2, '0'))}/${toPersianDigits(day.toString().padStart(2, '0'))}"
        }

        fun toStandardString(): String {
            return "$year/${month.toString().padStart(2, '0')}/${day.toString().padStart(2, '0')}"
        }

        fun toCanonicalDate(): String {
            return toStandardString()
        }

        fun toLongFormat(): String {
            return "${toPersianDigits(day)} $monthName ${toPersianDigits(year)}"
        }

        fun toMonthYearKey(): String {
            return "$monthName ${toPersianDigits(year)}"
        }
    }

    private val PERSIAN_MONTH_NAMES = arrayOf(
        "فروردین", "اردیبهشت", "خرداد",
        "تیر", "مرداد", "شهریور",
        "مهر", "آبان", "آذر",
        "دی", "بهمن", "اسفند"
    )

    fun getPersianMonthName(month: Int): String {
        return if (month in 1..12) {
            PERSIAN_MONTH_NAMES[month - 1]
        } else {
            ""
        }
    }

    /**
     * Set of year % 33 remainders that correspond to leap years in the standard 33-year Persian cycle.
     */
    val LEAP_YEAR_REMAINDERS = setOf(1, 5, 9, 13, 17, 22, 26, 30)

    // Precomputed cumulative leap years in years 1..i of a 33-year cycle (index 0..33)
    private val LEAP_COUNT_IN_CYCLE = intArrayOf(
        0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 5, 6, 6, 6, 6, 7, 7, 7, 7, 8, 8, 8, 8
    )

    /**
     * Checks if a Persian year is a leap year (Esfand has 30 days) using the standard 33-year rule:
     * (year % 33) in [1, 5, 9, 13, 17, 22, 26, 30]
     */
    fun isPersianLeapYear(year: Int): Boolean {
        val rem = ((year % 33) + 33) % 33
        return rem in LEAP_YEAR_REMAINDERS
    }

    /**
     * Returns days in a given Persian month (31 for months 1..6, 30 for 7..11, 30 for Esfand in leap year, 29 in non-leap).
     */
    fun getDaysInPersianMonth(year: Int, month: Int): Int {
        return when {
            month in 1..6 -> 31
            month in 7..11 -> 30
            month == 12 -> if (isPersianLeapYear(year)) 30 else 29
            else -> 30
        }
    }

    /**
     * Converts a Persian date to Julian Day Number (JDN) using the exact 33-year cycle.
     */
    fun persianToJdn(year: Int, month: Int, day: Int): Long {
        val y = year
        val cycles = if (y > 0) (y - 1) / 33 else (y - 33) / 33
        val rem = if (y > 0) (y - 1) % 33 else ((y - 1) % 33 + 33) % 33
        val leapCount = LEAP_COUNT_IN_CYCLE[rem]
        val daysBeforeYear = cycles.toLong() * 12053L + rem.toLong() * 365L + leapCount.toLong()
        val daysBeforeMonth = if (month <= 7) (month - 1) * 31 else 186 + (month - 7) * 30
        return 1948320L + daysBeforeYear + daysBeforeMonth + (day - 1)
    }

    /**
     * Converts a Julian Day Number (JDN) back to PersianDate using the exact 33-year cycle.
     */
    fun jdnToPersian(jdn: Long): PersianDate {
        val days = jdn - 1948320L
        var cycles = (days / 12053L).toInt()
        var remDays = (days % 12053L).toInt()
        if (remDays < 0) {
            cycles--
            remDays += 12053
        }
        var rem = 0
        while (rem < 33) {
            val isLeap = (rem + 1) in LEAP_YEAR_REMAINDERS
            val yearLen = if (isLeap) 366 else 365
            if (remDays < yearLen) break
            remDays -= yearLen
            rem++
        }
        val year = cycles * 33 + rem + 1
        val month: Int
        val day: Int
        if (remDays < 186) {
            month = (remDays / 31) + 1
            day = (remDays % 31) + 1
        } else {
            val rest = remDays - 186
            month = 7 + (rest / 30)
            day = (rest % 30) + 1
        }
        return PersianDate(year, month, day)
    }

    /**
     * Converts a Gregorian date to Julian Day Number (JDN).
     */
    fun gregorianToJdn(year: Int, month: Int, day: Int): Long {
        val a = (14 - month) / 12
        val y = year + 4800 - a
        val m = month + 12 * a - 3
        return day + (153 * m + 2) / 5 + 365L * y + y / 4 - y / 100 + y / 400 - 32045
    }

    /**
     * Converts a Julian Day Number (JDN) to Gregorian date (Triple of year, month, day).
     */
    fun jdnToGregorian(jdn: Long): Triple<Int, Int, Int> {
        val l = jdn + 68569
        val n = 4 * l / 146097
        val l1 = l - (146097 * n + 3) / 4
        val i = 4000 * (l1 + 1) / 1461001
        val l2 = l1 - 1461 * i / 4 + 31
        val j = 80 * l2 / 2447
        val day = (l2 - 2447 * j / 80).toInt()
        val l3 = j / 11
        val month = (j + 2 - 12 * l3).toInt()
        val year = (100 * (n - 49) + i + l3).toInt()
        return Triple(year, month, day)
    }

    /**
     * Converts Gregorian date to Jalali (Solar Hijri) date.
     */
    fun gregorianToPersian(gYear: Int, gMonth: Int, gDay: Int): PersianDate {
        val jdn = gregorianToJdn(gYear, gMonth, gDay)
        return jdnToPersian(jdn)
    }

    /**
     * Converts Jalali date to Gregorian date (Triple of year, month, day).
     */
    fun persianToGregorian(jYear: Int, jMonth: Int, jDay: Int): Triple<Int, Int, Int> {
        val jdn = persianToJdn(jYear, jMonth, jDay)
        return jdnToGregorian(jdn)
    }

    /**
     * Gets day of week for a Persian date:
     * 0 = شنبه, 1 = یکشنبه, 2 = دوشنبه, 3 = سه‌شنبه, 4 = چهارشنبه, 5 = پنج‌شنبه, 6 = جمعه
     */
    fun getPersianDayOfWeek(year: Int, month: Int, day: Int): Int {
        val jdn = persianToJdn(year, month, day)
        return (((jdn + 2) % 7 + 7) % 7).toInt()
    }

    /**
     * Calculates the full week date range (Saturday to Friday) for any given Persian date.
     * Converts to Gregorian, finds Saturday and Friday of that week, and converts back to Persian.
     * Accurately crosses month and year boundaries.
     */
    fun getWeekRangeForDate(persianDate: PersianDate): Pair<PersianDate, PersianDate> {
        val (gY, gM, gD) = persianToGregorian(persianDate.year, persianDate.month, persianDate.day)
        val cal = Calendar.getInstance().apply {
            set(Calendar.YEAR, gY)
            set(Calendar.MONTH, gM - 1)
            set(Calendar.DAY_OF_MONTH, gD)
            set(Calendar.HOUR_OF_DAY, 12)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val calDow = cal.get(Calendar.DAY_OF_WEEK) // Calendar.SUNDAY=1, MONDAY=2, ... SATURDAY=7
        val daysSinceSaturday = when (calDow) {
            Calendar.SATURDAY -> 0
            Calendar.SUNDAY -> 1
            Calendar.MONDAY -> 2
            Calendar.TUESDAY -> 3
            Calendar.WEDNESDAY -> 4
            Calendar.THURSDAY -> 5
            Calendar.FRIDAY -> 6
            else -> 0
        }
        val satCal = (cal.clone() as Calendar).apply {
            add(Calendar.DAY_OF_YEAR, -daysSinceSaturday)
        }
        val friCal = (cal.clone() as Calendar).apply {
            add(Calendar.DAY_OF_YEAR, 6 - daysSinceSaturday)
        }
        val satPersian = gregorianToPersian(
            satCal.get(Calendar.YEAR),
            satCal.get(Calendar.MONTH) + 1,
            satCal.get(Calendar.DAY_OF_MONTH)
        )
        val friPersian = gregorianToPersian(
            friCal.get(Calendar.YEAR),
            friCal.get(Calendar.MONTH) + 1,
            friCal.get(Calendar.DAY_OF_MONTH)
        )
        return Pair(satPersian, friPersian)
    }

    fun parseCanonicalDate(str: String): PersianDate? {
        val english = toEnglishDigits(str).trim()
        val parts = english.split('/', '-')
        if (parts.size == 3) {
            val y = parts[0].toIntOrNull() ?: return null
            val m = parts[1].toIntOrNull() ?: return null
            val d = parts[2].toIntOrNull() ?: return null
            return PersianDate(y, m, d)
        }
        return null
    }

    fun extractCanonicalDate(text: String): String {
        val parsed = parseCanonicalDate(text)
        if (parsed != null) return parsed.toStandardString()

        val english = toEnglishDigits(text)
        val tokens = english.split(" ")
        for (i in tokens.indices) {
            val d = tokens[i].toIntOrNull()
            if (d != null && i + 2 < tokens.size) {
                val mName = tokens[i + 1]
                val y = tokens[i + 2].toIntOrNull()
                val mIndex = PERSIAN_MONTH_NAMES.indexOf(mName)
                if (y != null && mIndex != -1) {
                    return PersianDate(y, mIndex + 1, d).toStandardString()
                }
            }
        }
        return text
    }

    /**
     * Gets today's Persian date.
     */
    fun getTodayPersianDate(): PersianDate {
        val calendar = Calendar.getInstance()
        return gregorianToPersian(
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH) + 1,
            calendar.get(Calendar.DAY_OF_MONTH)
        )
    }

    /**
     * Gets today's Gregorian formatted date (e.g. 2026/10/03).
     */
    fun getTodayGregorianDate(): String {
        val sdf = SimpleDateFormat("yyyy/MM/dd", Locale.US)
        return sdf.format(Date())
    }

    /**
     * Gets current time formatted as HH:mm.
     */
    fun getCurrentTime(): String {
        val sdf = SimpleDateFormat("HH:mm", Locale.getDefault())
        return sdf.format(Date())
    }

    /**
     * Converts English digits in a string to Persian digits (0..9 -> ۰..۹).
     */
    fun toPersianDigits(input: Any): String {
        val str = input.toString()
        val persianDigits = charArrayOf('۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹')
        val sb = StringBuilder()
        for (ch in str) {
            if (ch in '0'..'9') {
                sb.append(persianDigits[ch - '0'])
            } else {
                sb.append(ch)
            }
        }
        return sb.toString()
    }

    /**
     * Converts Persian digits to English digits.
     */
    fun toEnglishDigits(input: String): String {
        val persianDigits = "۰۱۲۳۴۵۶۷۸۹"
        val sb = StringBuilder()
        for (ch in input) {
            val idx = persianDigits.indexOf(ch)
            if (idx != -1) {
                sb.append(idx)
            } else {
                sb.append(ch)
            }
        }
        return sb.toString()
    }

    /**
     * Formats an amount with thousands separators and Persian digits.
     * Safely handles large amounts without throwing exceptions or overflow.
     */
    fun formatAmountToman(amount: Long): String {
        return formatAmountToman(java.math.BigInteger.valueOf(amount))
    }

    /**
     * Formats a BigInteger amount with thousands separators and Persian digits.
     */
    fun formatAmountToman(amount: java.math.BigInteger): String {
        val str = amount.toString()
        val sb = StringBuilder()
        val len = str.length
        for (i in 0 until len) {
            if (i > 0 && (len - i) % 3 == 0) {
                sb.append('٬')
            }
            sb.append(str[i])
        }
        return "${toPersianDigits(sb.toString())} تومان"
    }

    /**
     * Formats hours for display.
     */
    fun formatHours(hours: Double): String {
        val clean = if (hours % 1.0 == 0.0) {
            hours.toInt().toString()
        } else {
            String.format(Locale.US, "%.2f", hours).trimEnd('0').trimEnd('.')
        }
        return "${toPersianDigits(clean)} ساعت"
    }

    /**
     * Formats work days for display.
     */
    fun formatWorkDays(days: Double): String {
        val clean = if (days % 1.0 == 0.0) {
            days.toInt().toString()
        } else {
            String.format(Locale.US, "%.2f", days).trimEnd('0').trimEnd('.')
        }
        return "${toPersianDigits(clean)} روز"
    }

    /**
     * Persian Number-to-Words converter.
     * Converts numbers like 5000000 -> "پنج میلیون"
     * 100000000000 -> "یکصد میلیارد"
     * 1000000000000 -> "یک تریلیون"
     */
    fun numberToPersianWords(number: Long): String {
        return numberToPersianWords(java.math.BigInteger.valueOf(number))
    }

    /**
     * Persian Number-to-Words converter using BigInteger for safe large numbers.
     */
    fun numberToPersianWords(number: java.math.BigInteger): String {
        if (number == java.math.BigInteger.ZERO) return "صفر"
        if (number < java.math.BigInteger.ZERO) return "منفی " + numberToPersianWords(number.negate())

        val units = arrayOf(
            "", "یک", "دو", "سه", "چهار", "پنج", "شش", "هفت", "هشت", "نه"
        )
        val teens = arrayOf(
            "ده", "یازده", "دوازده", "سیزده", "چهارده", "پانزده", "شانزده", "هفده", "هجده", "نوزده"
        )
        val tens = arrayOf(
            "", "", "بیست", "سی", "چهل", "پنجاه", "شصت", "هفتاد", "هشتاد", "نود"
        )
        val hundreds = arrayOf(
            "", "یکصد", "دویست", "سیصد", "چهارصد", "پانصد", "ششصد", "هفتصد", "هشتصد", "نهصد"
        )
        val scales = arrayOf(
            "", "هزار", "میلیون", "میلیارد", "تریلیون", "کوادریلیون", "کوینتیلیون", "سکستیلیون", "سپتیلیون", "اکتیلیون"
        )

        fun convertThreeDigits(n: Int): String {
            val parts = mutableListOf<String>()
            val h = n / 100
            val rem = n % 100
            val t = rem / 10
            val u = rem % 10

            if (h > 0) parts.add(hundreds[h])

            if (rem in 10..19) {
                parts.add(teens[rem - 10])
            } else {
                if (t > 0) parts.add(tens[t])
                if (u > 0) parts.add(units[u])
            }

            return parts.joinToString(" و ")
        }

        var temp = number
        val thousand = java.math.BigInteger.valueOf(1000)
        val chunks = mutableListOf<Int>()
        while (temp > java.math.BigInteger.ZERO) {
            val rem = temp.remainder(thousand).toInt()
            chunks.add(rem)
            temp = temp.divide(thousand)
        }

        val resultParts = mutableListOf<String>()
        for (i in chunks.indices.reversed()) {
            val chunkVal = chunks[i]
            if (chunkVal > 0) {
                val words = convertThreeDigits(chunkVal)
                val scale = if (i < scales.size) scales[i] else ""
                if (scale.isNotEmpty()) {
                    resultParts.add("$words $scale")
                } else {
                    resultParts.add(words)
                }
            }
        }

        return if (resultParts.isEmpty()) "صفر" else resultParts.joinToString(" و ")
    }

    /**
     * Formats amount to Persian words with Toman suffix.
     * e.g. 5000000 -> "پنج میلیون تومان"
     */
    fun amountToPersianWordsWithToman(amount: Long): String {
        return amountToPersianWordsWithToman(java.math.BigInteger.valueOf(amount))
    }

    fun amountToPersianWordsWithToman(amount: java.math.BigInteger): String {
        if (amount == java.math.BigInteger.ZERO) return "صفر تومان"
        val words = numberToPersianWords(amount)
        return "$words تومان"
    }
}
