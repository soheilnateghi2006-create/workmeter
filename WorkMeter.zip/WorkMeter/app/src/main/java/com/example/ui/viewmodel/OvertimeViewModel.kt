package com.example.ui.viewmodel

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.Overtime
import com.example.data.model.Payment
import com.example.data.model.RateSetting
import com.example.data.model.RecoveryRecord
import com.example.data.model.WorkDay
import com.example.data.repository.OvertimeRepository
import com.example.data.repository.RecordRestoreResult
import com.example.data.repository.RestoreSummary
import com.example.data.repository.StatisticsResult
import com.example.util.PdfExporter
import com.example.util.PersianCalendarHelper
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class DateFilterType(val title: String) {
    ALL("همه"),
    THIS_WEEK("این هفته"),
    THIS_MONTH("این ماه"),
    LAST_MONTH("ماه قبل"),
    CUSTOM("بازه دلخواه")
}

class OvertimeViewModel(private val repository: OvertimeRepository) : ViewModel() {

    val workDays: StateFlow<List<WorkDay>> = repository.allWorkDaysFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val overtimes: StateFlow<List<Overtime>> = repository.allOvertimeFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val payments: StateFlow<List<Payment>> = repository.allPaymentsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val recoveryRecords: StateFlow<List<RecoveryRecord>> = repository.allRecoveryFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val rateSettings: StateFlow<List<RateSetting>> = repository.allRatesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        viewModelScope.launch {
            val (activeStart, activeEnd) = getActiveFilterRange()
            val result = repository.calculateRealStatistics(
                filterStart = activeStart,
                filterEnd = activeEnd,
                label = getActiveFilterLabel()
            )
            _statisticsResult.value = result
        }
    }

    // Search & Filter State
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedFilterType = MutableStateFlow(DateFilterType.ALL)
    val selectedFilterType: StateFlow<DateFilterType> = _selectedFilterType.asStateFlow()

    private val _customStartDate = MutableStateFlow<PersianCalendarHelper.PersianDate?>(null)
    val customStartDate: StateFlow<PersianCalendarHelper.PersianDate?> = _customStartDate.asStateFlow()

    private val _customEndDate = MutableStateFlow<PersianCalendarHelper.PersianDate?>(null)
    val customEndDate: StateFlow<PersianCalendarHelper.PersianDate?> = _customEndDate.asStateFlow()

    // Statistics Calculation State
    private val _statisticsResult = MutableStateFlow<StatisticsResult?>(null)
    val statisticsResult: StateFlow<StatisticsResult?> = _statisticsResult.asStateFlow()

    private val _isCalculatingStats = MutableStateFlow(false)
    val isCalculatingStats: StateFlow<Boolean> = _isCalculatingStats.asStateFlow()

    private val _showStatsDialog = MutableStateFlow(false)
    val showStatsDialog: StateFlow<Boolean> = _showStatsDialog.asStateFlow()

    // UI Feedback Message
    private val _toastMessage = MutableSharedFlow<String>()
    val toastMessage: SharedFlow<String> = _toastMessage.asSharedFlow()

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setDateFilter(
        type: DateFilterType,
        startDate: PersianCalendarHelper.PersianDate? = null,
        endDate: PersianCalendarHelper.PersianDate? = null
    ) {
        _selectedFilterType.value = type
        _customStartDate.value = startDate
        _customEndDate.value = endDate
    }

    fun clearFilter() {
        _selectedFilterType.value = DateFilterType.ALL
        _customStartDate.value = null
        _customEndDate.value = null
        _searchQuery.value = ""
    }

    /**
     * Calculates the canonical start and end dates based on the active filter type.
     */
    fun getActiveFilterRange(): Pair<String?, String?> {
        val today = PersianCalendarHelper.getTodayPersianDate()
        return when (_selectedFilterType.value) {
            DateFilterType.ALL -> Pair(null, null)
            DateFilterType.THIS_MONTH -> {
                val start = PersianCalendarHelper.PersianDate(today.year, today.month, 1).toStandardString()
                val daysInMonth = PersianCalendarHelper.getDaysInPersianMonth(today.year, today.month)
                val end = PersianCalendarHelper.PersianDate(today.year, today.month, daysInMonth).toStandardString()
                Pair(start, end)
            }
            DateFilterType.LAST_MONTH -> {
                val lastMonth = if (today.month == 1) 12 else today.month - 1
                val lastYear = if (today.month == 1) today.year - 1 else today.year
                val start = PersianCalendarHelper.PersianDate(lastYear, lastMonth, 1).toStandardString()
                val daysInMonth = PersianCalendarHelper.getDaysInPersianMonth(lastYear, lastMonth)
                val end = PersianCalendarHelper.PersianDate(lastYear, lastMonth, daysInMonth).toStandardString()
                Pair(start, end)
            }
            DateFilterType.THIS_WEEK -> {
                val (sat, fri) = PersianCalendarHelper.getWeekRangeForDate(today)
                Pair(sat.toStandardString(), fri.toStandardString())
            }
            DateFilterType.CUSTOM -> {
                val s = _customStartDate.value?.toStandardString()
                val e = _customEndDate.value?.toStandardString()
                Pair(s, e)
            }
        }
    }

    fun getActiveFilterLabel(): String? {
        return when (_selectedFilterType.value) {
            DateFilterType.ALL -> null
            DateFilterType.THIS_WEEK -> "این هفته"
            DateFilterType.THIS_MONTH -> "این ماه (${PersianCalendarHelper.getPersianMonthName(PersianCalendarHelper.getTodayPersianDate().month)})"
            DateFilterType.LAST_MONTH -> "ماه قبل"
            DateFilterType.CUSTOM -> {
                val s = _customStartDate.value
                val e = _customEndDate.value
                if (s != null && e != null) {
                    "${s.toLongFormat()} تا ${e.toLongFormat()}"
                } else null
            }
        }
    }

    /**
     * Executes real database query for Statistics calculation.
     * If filter is active, calculates for that specific range only.
     */
    fun calculateStatistics(
        filterStart: String? = null,
        filterEnd: String? = null,
        label: String? = null
    ) {
        viewModelScope.launch {
            _isCalculatingStats.value = true
            val (activeStart, activeEnd) = getActiveFilterRange()
            val start = filterStart ?: activeStart
            val end = filterEnd ?: activeEnd
            val filterLabel = label ?: getActiveFilterLabel()

            val result = repository.calculateRealStatistics(
                filterStart = start,
                filterEnd = end,
                label = filterLabel
            )
            _statisticsResult.value = result
            _isCalculatingStats.value = false
            _showStatsDialog.value = true
        }
    }

    fun dismissStatsDialog() {
        _showStatsDialog.value = false
    }

    /**
     * Checks if a Work Day or Overtime record already exists for a date.
     */
    suspend fun getExistingWorkDay(date: String): WorkDay? {
        return repository.getWorkDayByDate(date)
    }

    suspend fun getExistingOvertime(date: String): Overtime? {
        return repository.getOvertimeByDate(date)
    }

    /**
     * Saves or edits Work Day and Overtime for a selected date.
     * Prevents duplicate entries for the same date by updating.
     * Does NOT alter other dates.
     */
    fun saveWorkDayAndOvertime(
        canonicalDate: String,
        persianDate: String,
        gregorianDate: String,
        workDayAmount: Double,
        overtimeHours: Double,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            repository.saveWorkDay(
                date = canonicalDate,
                persianDate = persianDate,
                gregorianDate = gregorianDate,
                amount = workDayAmount
            )

            if (overtimeHours > 0.0) {
                repository.saveOvertime(
                    date = canonicalDate,
                    persianDate = persianDate,
                    gregorianDate = gregorianDate,
                    hours = overtimeHours
                )
            } else {
                repository.deleteOvertimeDirectly(canonicalDate)
            }

            _toastMessage.emit("اطلاعات روز کاری با موفقیت ثبت شد.")
            onSuccess()
        }
    }

    /**
     * Saves a payment record.
     */
    fun savePayment(
        amountToman: Long,
        canonicalDate: String = "",
        persianDate: String,
        persianMonthKey: String,
        gregorianDate: String,
        amountInWords: String,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            val time = PersianCalendarHelper.getCurrentTime()
            val finalCanonical = canonicalDate.ifBlank {
                PersianCalendarHelper.extractCanonicalDate(persianDate)
            }
            repository.savePayment(
                amountToman = amountToman,
                canonicalDate = finalCanonical,
                persianDate = persianDate,
                persianMonthKey = persianMonthKey,
                gregorianDate = gregorianDate,
                time = time,
                amountInWords = amountInWords
            )
            _toastMessage.emit("دریافتی با موفقیت ذخیره شد.")
            onSuccess()
        }
    }

    // Delete Operations to Recovery
    fun deleteWorkDay(workDay: WorkDay) {
        viewModelScope.launch {
            repository.deleteWorkDayToRecovery(workDay)
            _toastMessage.emit("روز کاری به بازیابی منتقل شد.")
        }
    }

    fun deleteOvertime(overtime: Overtime) {
        viewModelScope.launch {
            repository.deleteOvertimeToRecovery(overtime)
            _toastMessage.emit("اضافه کاری به بازیابی منتقل شد.")
        }
    }

    fun deletePayment(payment: Payment) {
        viewModelScope.launch {
            repository.deletePaymentToRecovery(payment)
            _toastMessage.emit("دریافتی به بازیابی منتقل شد.")
        }
    }

    // Recovery Operations
    fun restoreRecord(record: RecoveryRecord) {
        viewModelScope.launch {
            when (repository.restoreRecord(record)) {
                RecordRestoreResult.SUCCESS ->
                    _toastMessage.emit("مورد با موفقیت بازیابی شد.")
                RecordRestoreResult.DATE_EXISTS ->
                    _toastMessage.emit("برای این تاریخ قبلاً رکورد ثبت شده است.")
                RecordRestoreResult.ERROR ->
                    _toastMessage.emit("خطا در بازیابی اطلاعات.")
            }
        }
    }

    fun saveRate(
        id: Long = 0,
        effectiveFrom: String,
        dailyWage: Long,
        overtimeMultiplier: Double = 1.4,
        dailyHours: Double = 8.0
    ) {
        viewModelScope.launch {
            repository.saveRate(
                id = id,
                effectiveFrom = effectiveFrom,
                dailyWage = dailyWage,
                overtimeMultiplier = overtimeMultiplier,
                dailyHours = dailyHours
            )
            _toastMessage.emit("تنظیم نرخ با موفقیت ذخیره شد.")
            val (activeStart, activeEnd) = getActiveFilterRange()
            val result = repository.calculateRealStatistics(
                filterStart = activeStart,
                filterEnd = activeEnd,
                label = getActiveFilterLabel()
            )
            _statisticsResult.value = result
        }
    }

    fun deleteRate(rate: RateSetting) {
        viewModelScope.launch {
            repository.deleteRateToRecovery(rate)
            _toastMessage.emit("تنظیم نرخ به سطل زباله منتقل شد.")
            val (activeStart, activeEnd) = getActiveFilterRange()
            val result = repository.calculateRealStatistics(
                filterStart = activeStart,
                filterEnd = activeEnd,
                label = getActiveFilterLabel()
            )
            _statisticsResult.value = result
        }
    }

    fun permanentlyDeleteRecovery(record: RecoveryRecord) {
        viewModelScope.launch {
            repository.permanentlyDeleteRecovery(record)
            _toastMessage.emit("مورد برای همیشه حذف شد.")
        }
    }

    fun clearAllRecovery() {
        viewModelScope.launch {
            repository.clearAllRecovery()
            _toastMessage.emit("سطل زباله پاکسازی شد.")
        }
    }

    suspend fun getBackupJson(): String {
        return repository.exportBackupJson()
    }

    fun restoreBackup(
        jsonString: String,
        onSuccess: (RestoreSummary) -> Unit,
        onError: (String) -> Unit
    ) {
        viewModelScope.launch {
            val result = repository.restoreBackupJson(jsonString)
            result.onSuccess { summary ->
                _toastMessage.emit("اطلاعات پشتیبان با موفقیت بازیابی شد.")
                onSuccess(summary)
            }.onFailure { ex ->
                val msg = ex.message ?: "فایل پشتیبان معتبر نیست."
                _toastMessage.emit(msg)
                onError(msg)
            }
        }
    }

    fun exportPdf(context: Context) {
        viewModelScope.launch {
            val (workDaysList, overtimesList, paymentsList) = repository.getAllHistoryData()
            val stats = repository.calculateRealStatistics()
            val file = PdfExporter.generateAndSharePdf(
                context = context,
                workDays = workDaysList,
                overtimes = overtimesList,
                payments = paymentsList,
                stats = stats
            )
            if (file != null) {
                _toastMessage.emit("فایل PDF با موفقیت آماده و باز شد.")
            } else {
                _toastMessage.emit("خطا در ساخت فایل PDF.")
            }
        }
    }
}

class OvertimeViewModelFactory(private val repository: OvertimeRepository) :
    ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(OvertimeViewModel::class.java)) {
            return OvertimeViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
