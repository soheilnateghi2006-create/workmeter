package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.PriceChange
import androidx.compose.material.icons.filled.RestoreFromTrash
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.dialogs.PaymentRegisterDialog
import com.example.ui.dialogs.StatisticsResultDialog
import com.example.ui.dialogs.WorkDayRegisterDialog
import com.example.ui.screens.AppLockScreen
import com.example.ui.screens.AppLockSettingsScreen
import com.example.ui.screens.BackupRestoreScreen
import com.example.ui.screens.CalculationsScreen
import com.example.ui.screens.CalculatorScreen
import com.example.ui.screens.ExplanationScreen
import com.example.ui.screens.HistoryScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.RecoveryScreen
import com.example.ui.screens.WorkCalendarScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.OvertimeViewModel
import com.example.ui.viewmodel.OvertimeViewModelFactory
import com.example.util.AppLockManager
import com.example.util.PersianCalendarHelper
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

enum class MainDestination(val title: String) {
    HOME("خانه"),
    CALCULATIONS("محاسبات"),
    HISTORY("کل")
}

enum class SubScreen {
    NONE,
    CALENDAR,
    BACKUP_RESTORE,
    APP_LOCK,
    EXPLANATION,
    CALCULATOR,
    RECOVERY
}

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val app = application as OvertimeApp
        val viewModelFactory = OvertimeViewModelFactory(app.repository)

        setContent {
            MyApplicationTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    val viewModel: OvertimeViewModel = viewModel(factory = viewModelFactory)
                    MainAppContent(viewModel = viewModel)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppContent(viewModel: OvertimeViewModel) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }
    val lockManager = remember { AppLockManager(context) }

    var isAppUnlocked by rememberSaveable { mutableStateOf(!lockManager.isLockEnabled) }

    // Request POST_NOTIFICATIONS permission on Android 13+
    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
        onResult = { /* granted / denied */ }
    )

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val permissionCheck = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            )
            if (permissionCheck != PackageManager.PERMISSION_GRANTED) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    // App Lock Gate
    if (lockManager.isLockEnabled && !isAppUnlocked) {
        AppLockScreen(
            lockManager = lockManager,
            onUnlockSuccess = { isAppUnlocked = true }
        )
        return
    }

    // Listen to ViewModel toast messages
    LaunchedEffect(Unit) {
        viewModel.toastMessage.collectLatest { msg ->
            snackbarHostState.showSnackbar(msg)
        }
    }

    // Navigation and state
    var currentTab by remember { mutableStateOf(MainDestination.HOME) }
    var currentSubScreen by remember { mutableStateOf(SubScreen.NONE) }

    // Dialogs & initial date targets
    var showWorkDayDialog by remember { mutableStateOf(false) }
    var showPaymentDialog by remember { mutableStateOf(false) }
    var targetWorkDayDate by remember { mutableStateOf(PersianCalendarHelper.getTodayPersianDate()) }
    var targetPaymentDate by remember { mutableStateOf(PersianCalendarHelper.getTodayPersianDate()) }

    val showStatsDialog by viewModel.showStatsDialog.collectAsStateWithLifecycle()
    val statsResult by viewModel.statisticsResult.collectAsStateWithLifecycle()
    val isCalculatingStats by viewModel.isCalculatingStats.collectAsStateWithLifecycle()
    val recoveryList by viewModel.recoveryRecords.collectAsStateWithLifecycle()

    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)

    // Back handling
    BackHandler(enabled = drawerState.isOpen || currentSubScreen != SubScreen.NONE) {
        if (drawerState.isOpen) {
            coroutineScope.launch { drawerState.close() }
        } else if (currentSubScreen != SubScreen.NONE) {
            currentSubScreen = SubScreen.NONE
        }
    }

    // Dialog handlers
    if (showWorkDayDialog) {
        WorkDayRegisterDialog(
            viewModel = viewModel,
            initialDate = targetWorkDayDate,
            onDismissRequest = {
                showWorkDayDialog = false
                targetWorkDayDate = PersianCalendarHelper.getTodayPersianDate()
            }
        )
    }

    if (showPaymentDialog) {
        PaymentRegisterDialog(
            viewModel = viewModel,
            initialDate = targetPaymentDate,
            onDismissRequest = {
                showPaymentDialog = false
                targetPaymentDate = PersianCalendarHelper.getTodayPersianDate()
            }
        )
    }

    if (showStatsDialog) {
        StatisticsResultDialog(
            statsResult = statsResult,
            isLoading = isCalculatingStats,
            onDismissRequest = { viewModel.dismissStatsDialog() }
        )
    }

    // Sub-screens display
    when (currentSubScreen) {
        SubScreen.CALENDAR -> {
            WorkCalendarScreen(
                viewModel = viewModel,
                onNavigateBack = { currentSubScreen = SubScreen.NONE },
                onRegisterWorkDayForDate = { pDate ->
                    targetWorkDayDate = pDate
                    showWorkDayDialog = true
                },
                onRegisterPaymentForDate = { pDate ->
                    targetPaymentDate = pDate
                    showPaymentDialog = true
                }
            )
            return
        }
        SubScreen.BACKUP_RESTORE -> {
            BackupRestoreScreen(
                viewModel = viewModel,
                onNavigateBack = { currentSubScreen = SubScreen.NONE }
            )
            return
        }
        SubScreen.APP_LOCK -> {
            AppLockSettingsScreen(
                lockManager = lockManager,
                onNavigateBack = { currentSubScreen = SubScreen.NONE }
            )
            return
        }
        SubScreen.CALCULATOR -> {
            CalculatorScreen(onNavigateBack = { currentSubScreen = SubScreen.NONE })
            return
        }
        SubScreen.EXPLANATION -> {
            ExplanationScreen(onNavigateBack = { currentSubScreen = SubScreen.NONE })
            return
        }
        SubScreen.RECOVERY -> {
            RecoveryScreen(
                viewModel = viewModel,
                onNavigateBack = { currentSubScreen = SubScreen.NONE }
            )
            return
        }
        SubScreen.NONE -> {
            // Main app screen with drawer and bottom nav
        }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                modifier = Modifier
                    .width(300.dp)
                    .fillMaxSize()
            ) {
                Spacer(modifier = Modifier.height(24.dp))
                // Drawer Header
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 12.dp)
                ) {
                    Text(
                        text = "اضافه کاری من",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "مدیریت کارکرد، اضافه کاری و دریافتی‌ها",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                HorizontalDivider(
                    modifier = Modifier.padding(vertical = 10.dp),
                    color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
                )

                // Item 1: تقویم کاری
                NavigationDrawerItem(
                    icon = { Icon(Icons.Default.CalendarMonth, contentDescription = null) },
                    label = { Text("تقویم کاری", fontWeight = FontWeight.SemiBold) },
                    selected = false,
                    onClick = {
                        coroutineScope.launch { try { drawerState.close() } catch (_: Throwable) {} }
                        currentSubScreen = SubScreen.CALENDAR
                    },
                    modifier = Modifier
                        .padding(NavigationDrawerItemDefaults.ItemPadding)
                        .testTag("drawer_item_calendar")
                )

                // Item 2: پشتیبان‌گیری و بازیابی
                NavigationDrawerItem(
                    icon = { Icon(Icons.Default.Backup, contentDescription = null) },
                    label = { Text("پشتیبان‌گیری", fontWeight = FontWeight.SemiBold) },
                    selected = false,
                    onClick = {
                        coroutineScope.launch { try { drawerState.close() } catch (_: Throwable) {} }
                        currentSubScreen = SubScreen.BACKUP_RESTORE
                    },
                    modifier = Modifier
                        .padding(NavigationDrawerItemDefaults.ItemPadding)
                        .testTag("drawer_item_backup")
                )

                // Item 3: قفل برنامه
                NavigationDrawerItem(
                    icon = { Icon(Icons.Default.Lock, contentDescription = null) },
                    label = { Text("قفل برنامه", fontWeight = FontWeight.SemiBold) },
                    selected = false,
                    onClick = {
                        coroutineScope.launch { try { drawerState.close() } catch (_: Throwable) {} }
                        currentSubScreen = SubScreen.APP_LOCK
                    },
                    modifier = Modifier
                        .padding(NavigationDrawerItemDefaults.ItemPadding)
                        .testTag("drawer_item_lock")
                )

                // Item 4: توضیحات
                NavigationDrawerItem(
                    icon = { Icon(Icons.Default.Info, contentDescription = null) },
                    label = { Text("توضیحات", fontWeight = FontWeight.SemiBold) },
                    selected = false,
                    onClick = {
                        coroutineScope.launch { try { drawerState.close() } catch (_: Throwable) {} }
                        currentSubScreen = SubScreen.EXPLANATION
                    },
                    modifier = Modifier
                        .padding(NavigationDrawerItemDefaults.ItemPadding)
                        .testTag("drawer_item_explanation")
                )

                // Item 5: ماشین حساب
                NavigationDrawerItem(
                    icon = { Icon(Icons.Default.Calculate, contentDescription = null) },
                    label = { Text("ماشین حساب", fontWeight = FontWeight.SemiBold) },
                    selected = false,
                    onClick = {
                        coroutineScope.launch { try { drawerState.close() } catch (_: Throwable) {} }
                        currentSubScreen = SubScreen.CALCULATOR
                    },
                    modifier = Modifier
                        .padding(NavigationDrawerItemDefaults.ItemPadding)
                        .testTag("drawer_item_calculator")
                )

                // Item 6: بازیابی (سطل زباله)
                NavigationDrawerItem(
                    icon = {
                        BadgedBox(
                            badge = {
                                if (recoveryList.isNotEmpty()) {
                                    Badge {
                                        Text(PersianCalendarHelper.toPersianDigits(recoveryList.size))
                                    }
                                }
                            }
                        ) {
                            Icon(Icons.Default.RestoreFromTrash, contentDescription = null)
                        }
                    },
                    label = { Text("بازیابی (سطل زباله)", fontWeight = FontWeight.SemiBold) },
                    selected = false,
                    onClick = {
                        coroutineScope.launch { try { drawerState.close() } catch (_: Throwable) {} }
                        currentSubScreen = SubScreen.RECOVERY
                    },
                    modifier = Modifier
                        .padding(NavigationDrawerItemDefaults.ItemPadding)
                        .testTag("drawer_item_recovery")
                )
            }
        }
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Text(
                            text = "اضافه کاری من",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                    },
                    navigationIcon = {
                        IconButton(
                            onClick = { coroutineScope.launch { drawerState.open() } },
                            modifier = Modifier.testTag("hamburger_menu_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Menu,
                                contentDescription = "منوی برنامه"
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.background
                    )
                )
            },
            bottomBar = {
                NavigationBar(
                    modifier = Modifier.testTag("bottom_navigation_bar"),
                    containerColor = MaterialTheme.colorScheme.surface
                ) {
                    // 1. خانه
                    NavigationBarItem(
                        icon = { Icon(Icons.Default.Home, contentDescription = "خانه") },
                        label = { Text("خانه") },
                        selected = currentTab == MainDestination.HOME,
                        onClick = { currentTab = MainDestination.HOME },
                        modifier = Modifier.testTag("nav_item_home")
                    )

                    // 2. محاسبات
                    NavigationBarItem(
                        icon = { Icon(Icons.Default.Assessment, contentDescription = "محاسبات") },
                        label = { Text("محاسبات") },
                        selected = currentTab == MainDestination.CALCULATIONS,
                        onClick = { currentTab = MainDestination.CALCULATIONS },
                        modifier = Modifier.testTag("nav_item_calculations")
                    )

                    // 3. کل
                    NavigationBarItem(
                        icon = { Icon(Icons.Default.History, contentDescription = "کل") },
                        label = { Text("کل") },
                        selected = currentTab == MainDestination.HISTORY,
                        onClick = { currentTab = MainDestination.HISTORY },
                        modifier = Modifier.testTag("nav_item_history")
                    )
                }
            },
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                when (currentTab) {
                    MainDestination.HOME -> {
                        HomeScreen(
                            viewModel = viewModel,
                            onOpenWorkDayRegister = {
                                targetWorkDayDate = PersianCalendarHelper.getTodayPersianDate()
                                showWorkDayDialog = true
                            },
                            onOpenPaymentRegister = {
                                targetPaymentDate = PersianCalendarHelper.getTodayPersianDate()
                                showPaymentDialog = true
                            },
                            onOpenStats = { viewModel.calculateStatistics() },
                            onNavigateToHistory = { currentTab = MainDestination.HISTORY }
                        )
                    }
                    MainDestination.CALCULATIONS -> {
                        CalculationsScreen(
                            viewModel = viewModel,
                            onCalculateStats = { viewModel.calculateStatistics() }
                        )
                    }
                    MainDestination.HISTORY -> {
                        HistoryScreen(
                            viewModel = viewModel,
                            onOpenRecovery = { currentSubScreen = SubScreen.RECOVERY },
                            onEditDate = { canonicalDate ->
                                val parsed = PersianCalendarHelper.parseCanonicalDate(canonicalDate)
                                if (parsed != null) {
                                    targetWorkDayDate = parsed
                                }
                                showWorkDayDialog = true
                            }
                        )
                    }
                }
            }
        }
    }
}
