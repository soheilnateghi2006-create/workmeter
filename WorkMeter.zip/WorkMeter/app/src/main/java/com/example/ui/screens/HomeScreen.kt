package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.EditCalendar
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.MoreTime
import androidx.compose.material.icons.filled.Paid
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedButton
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.LiquidSummaryCard
import com.example.ui.viewmodel.OvertimeViewModel
import com.example.util.PersianCalendarHelper

@Composable
fun HomeScreen(
    viewModel: OvertimeViewModel,
    onOpenWorkDayRegister: () -> Unit,
    onOpenPaymentRegister: () -> Unit,
    onOpenStats: () -> Unit,
    onNavigateToHistory: () -> Unit
) {
    val workDays by viewModel.workDays.collectAsStateWithLifecycle()
    val overtimes by viewModel.overtimes.collectAsStateWithLifecycle()
    val payments by viewModel.payments.collectAsStateWithLifecycle()

    val totalOvertimeHours = remember(overtimes) { overtimes.sumOf { it.overtimeHours } }
    val totalWorkDays = remember(workDays) { workDays.sumOf { it.workDayAmount } }
    val totalPaymentAmount = remember(payments) { payments.sumOf { it.amountToman } }

    val todayPersian = remember { PersianCalendarHelper.getTodayPersianDate() }
    val todayCanonical = remember { todayPersian.toStandardString() }
    val todayWorkDay = remember(workDays, todayCanonical) { workDays.find { it.date == todayCanonical } }
    val todayOvertime = remember(overtimes, todayCanonical) { overtimes.find { it.date == todayCanonical } }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 10.dp)
    ) {
        // Today Banner
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
            ),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Default.CalendarToday,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "امروز: ${todayPersian.toLongFormat()}",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Text(
                            text = if (todayWorkDay != null || (todayOvertime != null && todayOvertime.overtimeHours > 0))
                                "ثبت شده: ${if (todayWorkDay != null) PersianCalendarHelper.formatWorkDays(todayWorkDay.workDayAmount) else ""} ${if (todayOvertime != null && todayOvertime.overtimeHours > 0) "+ " + PersianCalendarHelper.formatHours(todayOvertime.overtimeHours) else ""}"
                            else
                                "برای امروز هنوز موردی ثبت نشده است.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.85f)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Three Animated Liquid Summary Cards at Top:
        // 1. روز های کامل (TOP Priority)
        // 2. مجموع اضافه کاری (MIDDLE)
        // 3. مبالغ دریافتی (BOTTOM)
        Text(
            text = "خلاصه وضعیت کارکرد",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )

        Spacer(modifier = Modifier.height(10.dp))

        // 1. روز های کامل (TOP)
        LiquidSummaryCard(
            title = "روز های کامل",
            valueText = PersianCalendarHelper.formatWorkDays(totalWorkDays),
            unitText = "",
            icon = Icons.Default.DateRange,
            fillFraction = (totalWorkDays / 30.0).toFloat().coerceIn(0f, 1f),
            waveColor = MaterialTheme.colorScheme.primary,
            modifier = Modifier.fillMaxWidth(),
            testTag = "summary_card_work_days"
        )

        Spacer(modifier = Modifier.height(10.dp))

        // 2. مجموع اضافه کاری (MIDDLE)
        LiquidSummaryCard(
            title = "مجموع اضافه کاری",
            valueText = PersianCalendarHelper.formatHours(totalOvertimeHours),
            unitText = "",
            icon = Icons.Default.MoreTime,
            fillFraction = (totalOvertimeHours / 50.0).toFloat().coerceIn(0f, 1f),
            waveColor = MaterialTheme.colorScheme.tertiary,
            modifier = Modifier.fillMaxWidth(),
            testTag = "summary_card_overtime"
        )

        Spacer(modifier = Modifier.height(10.dp))

        // 3. مبالغ دریافتی (BOTTOM)
        LiquidSummaryCard(
            title = "مبالغ دریافتی",
            valueText = PersianCalendarHelper.formatAmountToman(totalPaymentAmount),
            unitText = "",
            icon = Icons.Default.Payments,
            fillFraction = (totalPaymentAmount / 50_000_000.0).toFloat().coerceIn(0f, 1f),
            waveColor = MaterialTheme.colorScheme.secondary,
            modifier = Modifier.fillMaxWidth(),
            testTag = "summary_card_payments"
        )

        Spacer(modifier = Modifier.height(24.dp))

        // MAIN SCREEN ACTION BUTTONS:
        // “ویرایش یا ثبت روز کاری”
        // “ثبت دریافتی”
        // Large and easy to use
        Text(
            text = "عملیات اصلی",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Large Action Button 1: ویرایش یا ثبت روز کاری
        Button(
            onClick = onOpenWorkDayRegister,
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.primary
            ),
            modifier = Modifier
                .fillMaxWidth()
                .height(60.dp)
                .testTag("main_register_work_day_btn")
        ) {
            Icon(
                Icons.Default.EditCalendar,
                contentDescription = null,
                modifier = Modifier.size(26.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Text(
                text = "ویرایش یا ثبت روز کاری",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                fontSize = 17.sp
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Large Action Button 2: ثبت دریافتی
        Button(
            onClick = onOpenPaymentRegister,
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.secondary
            ),
            modifier = Modifier
                .fillMaxWidth()
                .height(60.dp)
                .testTag("main_register_payment_btn")
        ) {
            Icon(
                Icons.Default.Paid,
                contentDescription = null,
                modifier = Modifier.size(26.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Text(
                text = "ثبت دریافتی",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                fontSize = 17.sp
            )
        }

        Spacer(modifier = Modifier.height(18.dp))

        // Quick Calculation / Stats Banner
        FilledTonalButton(
            onClick = onOpenStats,
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
                .testTag("home_quick_stats_btn")
        ) {
            Icon(Icons.Default.Assessment, contentDescription = null, modifier = Modifier.size(22.dp))
            Spacer(modifier = Modifier.width(10.dp))
            Text(
                text = "محاسبه آمار کل و ماهانه",
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.SemiBold
            )
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}
