package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.FilterAlt
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.MoreTime
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ElevatedFilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.CenteredSmoothDialog
import com.example.ui.components.FinancialBalanceSection
import com.example.ui.components.MonthlyChartsSection
import com.example.ui.components.PersianDatePickerDialog
import com.example.ui.viewmodel.DateFilterType
import com.example.ui.viewmodel.OvertimeViewModel
import com.example.util.PersianCalendarHelper

@Composable
fun CalculationsScreen(
    viewModel: OvertimeViewModel,
    onCalculateStats: () -> Unit
) {
    val isCalculating by viewModel.isCalculatingStats.collectAsStateWithLifecycle()
    val statsResult by viewModel.statisticsResult.collectAsStateWithLifecycle()
    val selectedFilterType by viewModel.selectedFilterType.collectAsStateWithLifecycle()
    val customStartDate by viewModel.customStartDate.collectAsStateWithLifecycle()
    val customEndDate by viewModel.customEndDate.collectAsStateWithLifecycle()

    var showCustomRangeDialog by remember { mutableStateOf(false) }
    var tempStartDate by remember { mutableStateOf(customStartDate ?: PersianCalendarHelper.getTodayPersianDate()) }
    var tempEndDate by remember { mutableStateOf(customEndDate ?: PersianCalendarHelper.getTodayPersianDate()) }
    var pickingForStart by remember { mutableStateOf<Boolean?>(null) }

    if (showCustomRangeDialog) {
        CenteredSmoothDialog(
            onDismissRequest = { showCustomRangeDialog = false },
            icon = {
                Icon(Icons.Default.DateRange, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(32.dp))
            },
            title = {
                Text("تعیین بازه دلخواه", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            },
            content = {
                Column {
                    Text("بازه زمانی مورد نظر برای محاسبه آمار را مشخص کنید:", style = MaterialTheme.typography.bodyMedium)
                    Spacer(modifier = Modifier.height(14.dp))

                    OutlinedButton(
                        onClick = { pickingForStart = true },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("از تاریخ: ${tempStartDate.toLongFormat()}")
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedButton(
                        onClick = { pickingForStart = false },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("تا تاریخ: ${tempEndDate.toLongFormat()}")
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    viewModel.setDateFilter(DateFilterType.CUSTOM, tempStartDate, tempEndDate)
                    showCustomRangeDialog = false
                }) {
                    Text("اعمال بازه")
                }
            },
            dismissButton = {
                TextButton(onClick = { showCustomRangeDialog = false }) {
                    Text("انصراف")
                }
            }
        )
    }

    if (pickingForStart != null) {
        val forStart = pickingForStart == true
        PersianDatePickerDialog(
            initialDate = if (forStart) tempStartDate else tempEndDate,
            onDateSelected = { pDate, _ ->
                if (forStart) tempStartDate = pDate else tempEndDate = pDate
                pickingForStart = null
            },
            onDismissRequest = { pickingForStart = null }
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 14.dp)
    ) {
        // Info Header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f))
                .padding(18.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    Icons.Default.Calculate,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(32.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = "موتور محاسبات آماری",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "استخراج آمار واقعی مستقیماً از اطلاعات ذخیره شده در پایگاه داده",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.85f)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Date Filter Selection
        Text(
            text = "بازه زمانی محاسبه:",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )
        Spacer(modifier = Modifier.height(6.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            DateFilterType.values().forEach { filterType ->
                ElevatedFilterChip(
                    selected = selectedFilterType == filterType,
                    onClick = {
                        if (filterType == DateFilterType.CUSTOM) {
                            showCustomRangeDialog = true
                        } else {
                            viewModel.setDateFilter(filterType)
                        }
                    },
                    label = { Text(filterType.title, fontWeight = if (selectedFilterType == filterType) FontWeight.Bold else FontWeight.Normal) },
                    colors = FilterChipDefaults.elevatedFilterChipColors()
                )
            }
        }

        val filterLabel = viewModel.getActiveFilterLabel()
        if (filterLabel != null) {
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f))
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.FilterAlt, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "بازه انتخابی: $filterLabel",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        fontWeight = FontWeight.SemiBold
                    )
                }
                TextButton(onClick = { viewModel.clearFilter() }) {
                    Text("حذف فیلتر", style = MaterialTheme.typography.labelSmall)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // THE PRIMARY "محاسبه آمار" BUTTON
        Button(
            onClick = { viewModel.calculateStatistics() },
            enabled = !isCalculating,
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.primary
            ),
            modifier = Modifier
                .fillMaxWidth()
                .height(64.dp)
                .testTag("calculate_statistics_button")
        ) {
            if (isCalculating) {
                CircularProgressIndicator(
                    color = MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier.size(24.dp),
                    strokeWidth = 2.5.dp
                )
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = "در حال محاسبه از پایگاه داده...",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            } else {
                Icon(
                    Icons.Default.Assessment,
                    contentDescription = null,
                    modifier = Modifier.size(28.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = if (filterLabel != null) "محاسبه آمار بازه انتخابی" else "محاسبه آمار",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    fontSize = 19.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Card displaying last calculated result if available on this screen
        if (statsResult != null) {
            Text(
                text = "آخرین نتیجه محاسبه شده:",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(8.dp))

            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    if (!statsResult!!.dateRangeLabel.isNullOrBlank()) {
                        Text(
                            text = "بازه: ${statsResult!!.dateRangeLabel}",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold
                        )
                        HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
                    }

                    // 1. مجموع روزهای کامل
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("مجموع روزهای کامل:", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(
                            text = PersianCalendarHelper.formatWorkDays(statsResult!!.totalWorkDays),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // 2. مجموع اضافه کاری
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("مجموع اضافه کاری:", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(
                            text = PersianCalendarHelper.formatHours(statsResult!!.totalOvertimeHours),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.tertiary
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // 3. مجموع مبالغ دریافتی
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("مجموع مبالغ دریافتی:", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(
                            text = PersianCalendarHelper.formatAmountToman(statsResult!!.totalPaymentAmount),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.secondary
                        )
                    }

                    if (statsResult!!.monthlyPayments.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "مبالغ دریافتی ماهانه:",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        statsResult!!.monthlyPayments.forEach { m ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 2.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(m.monthKey, style = MaterialTheme.typography.bodySmall)
                                Text(
                                    PersianCalendarHelper.formatAmountToman(m.totalAmountToman),
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.secondary
                                )
                            }
                        }
                    }
                }
            }

            if (statsResult!!.financialSummary != null) {
                Spacer(modifier = Modifier.height(16.dp))
                FinancialBalanceSection(summary = statsResult!!.financialSummary!!)
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Monthly Charts Section
            MonthlyChartsSection(
                monthlyPayments = statsResult!!.monthlyPayments,
                monthlyOvertimes = statsResult!!.monthlyOvertimes
            )

            Spacer(modifier = Modifier.height(20.dp))
        }

        // Rules Reminder Card
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Default.Lightbulb,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.tertiary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "مبنای محاسبات آماری",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "• هر ۱۰ ساعت کارکرد عادی معادل یک روز کاری\n• هر ۸ ساعت اضافه کار معادل یک روز کاری\n• بدون تخمین، میانگین کاذب یا داده ساختگی؛ تمام مبالغ و ساعات مستقیماً از داده‌های شما جمع زده می‌شوند.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 20.sp
                )
            }
        }
    }
}
