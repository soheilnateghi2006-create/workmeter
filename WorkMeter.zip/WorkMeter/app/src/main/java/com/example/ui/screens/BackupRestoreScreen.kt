package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.RestoreSummary
import com.example.ui.components.CenteredSmoothDialog
import com.example.ui.viewmodel.OvertimeViewModel
import com.example.util.PersianCalendarHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BackupRestoreScreen(
    viewModel: OvertimeViewModel,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var isProcessing by remember { mutableStateOf(false) }
    var pendingRestoreJson by remember { mutableStateOf<String?>(null) }
    var restorePreviewSummary by remember { mutableStateOf<String?>(null) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var successMessage by remember { mutableStateOf<String?>(null) }

    // Launcher for saving backup JSON to device storage
    val createDocumentLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri: Uri? ->
        if (uri != null) {
            coroutineScope.launch {
                isProcessing = true
                try {
                    val json = viewModel.getBackupJson()
                    withContext(Dispatchers.IO) {
                        context.contentResolver.openOutputStream(uri)?.use { outputStream ->
                            outputStream.write(json.toByteArray(Charsets.UTF_8))
                        }
                    }
                    successMessage = "فایل پشتیبان با موفقیت در حافظه دستگاه ذخیره شد."
                } catch (e: Exception) {
                    errorMessage = "خطا در ذخیره فایل پشتیبان: ${e.message}"
                } finally {
                    isProcessing = false
                }
            }
        }
    }

    // Launcher for selecting a backup JSON file to restore
    val openDocumentLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            coroutineScope.launch {
                isProcessing = true
                try {
                    val content = withContext(Dispatchers.IO) {
                        context.contentResolver.openInputStream(uri)?.use { inputStream ->
                            BufferedReader(InputStreamReader(inputStream, Charsets.UTF_8)).readText()
                        }
                    }
                    if (content.isNullOrBlank()) {
                        errorMessage = "فایل پشتیبان معتبر نیست."
                        return@launch
                    }

                    // Validate JSON and version
                    val root = JSONObject(content)
                    val version = root.optInt("version", -1)
                    if (version < 1) {
                        errorMessage = "فایل پشتیبان معتبر نیست."
                        return@launch
                    }

                    val wdCount = root.optJSONArray("workDays")?.length() ?: 0
                    val otCount = root.optJSONArray("overtimes")?.length() ?: 0
                    val pmtCount = root.optJSONArray("payments")?.length() ?: 0
                    val expDate = root.optString("exportedDate", "نامشخص")

                    pendingRestoreJson = content
                    restorePreviewSummary = "تاریخ پشتیبان: $expDate\nتعداد روز کاری: ${PersianCalendarHelper.toPersianDigits(wdCount)}\nتعداد اضافه کاری: ${PersianCalendarHelper.toPersianDigits(otCount)}\nتعداد دریافتی: ${PersianCalendarHelper.toPersianDigits(pmtCount)}"
                } catch (e: Exception) {
                    errorMessage = "فایل پشتیبان معتبر نیست."
                } finally {
                    isProcessing = false
                }
            }
        }
    }

    // Confirmation Dialog before Restoring
    if (pendingRestoreJson != null) {
        CenteredSmoothDialog(
            onDismissRequest = {
                pendingRestoreJson = null
                restorePreviewSummary = null
            },
            icon = {
                Icon(
                    Icons.Default.CloudDownload,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(36.dp)
                )
            },
            title = {
                Text(
                    text = "تأیید بازیابی پشتیبان",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
            },
            content = {
                Column {
                    Text(
                        text = "آیا می‌خواهید اطلاعات پشتیبان بازیابی شود؟",
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = restorePreviewSummary ?: "",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "اطلاعات قبلی شما حفظ شده و اطلاعات جدید بدون ایجاد رکورد تکراری با آن ادغام می‌شوند.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val json = pendingRestoreJson
                        pendingRestoreJson = null
                        restorePreviewSummary = null
                        if (json != null) {
                            viewModel.restoreBackup(
                                jsonString = json,
                                onSuccess = { summary ->
                                    val baseMsg = "بازیابی با موفقیت انجام شد:\n${PersianCalendarHelper.toPersianDigits(summary.workDaysCount)} روز کاری، ${PersianCalendarHelper.toPersianDigits(summary.overtimesCount)} اضافه کاری و ${PersianCalendarHelper.toPersianDigits(summary.paymentsCount)} دریافتی ثبت شد."
                                    successMessage = if (summary.skippedTotalCount > 0) {
                                        "$baseMsg\n\nتعداد ${PersianCalendarHelper.toPersianDigits(summary.skippedTotalCount)} رکورد به دلیل ثبت قبلی رد شدند."
                                    } else {
                                        baseMsg
                                    }
                                },
                                onError = { msg ->
                                    errorMessage = msg
                                }
                            )
                        }
                    }
                ) {
                    Text("بله، بازیابی شود")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = {
                    pendingRestoreJson = null
                    restorePreviewSummary = null
                }) {
                    Text("انصراف")
                }
            }
        )
    }

    // Error Dialog
    if (errorMessage != null) {
        CenteredSmoothDialog(
            onDismissRequest = { errorMessage = null },
            icon = {
                Icon(Icons.Default.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(32.dp))
            },
            title = { Text("خطا", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) },
            content = { Text(errorMessage ?: "") },
            confirmButton = {
                Button(onClick = { errorMessage = null }) { Text("متوجه شدم") }
            }
        )
    }

    // Success Dialog
    if (successMessage != null) {
        CenteredSmoothDialog(
            onDismissRequest = { successMessage = null },
            icon = {
                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(32.dp))
            },
            title = { Text("عملیات موفق", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) },
            content = { Text(successMessage ?: "") },
            confirmButton = {
                Button(onClick = { successMessage = null }) { Text("تأیید") }
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "پشتیبان‌گیری و بازیابی",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "بازگشت")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 12.dp)
        ) {
            // Section 1: پشتیبان‌گیری (Export)
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.CloudUpload,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = "پشتیبان‌گیری از داده‌ها",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "تمامی سوابق روزهای کاری، اضافه کاری، مبالغ دریافتی و سطل زباله در یک فایل استاندارد JSON ذخیره می‌شوند.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        lineHeight = 22.sp
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = {
                                val today = PersianCalendarHelper.getTodayPersianDate()
                                val defaultName = "EzfeKariMan_Backup_${today.year}_${today.month}_${today.day}.json"
                                createDocumentLauncher.launch(defaultName)
                            },
                            enabled = !isProcessing,
                            modifier = Modifier.weight(1f).testTag("export_backup_button")
                        ) {
                            Icon(Icons.Default.Backup, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("ذخیره فایل پشتیبان")
                        }

                        OutlinedButton(
                            onClick = {
                                coroutineScope.launch {
                                    isProcessing = true
                                    try {
                                        val json = viewModel.getBackupJson()
                                        val sendIntent = Intent(Intent.ACTION_SEND).apply {
                                            type = "application/json"
                                            putExtra(Intent.EXTRA_SUBJECT, "فایل پشتیبان اضافه کاری من")
                                            putExtra(Intent.EXTRA_TEXT, json)
                                        }
                                        val shareIntent = Intent.createChooser(sendIntent, "اشتراک‌گذاری فایل پشتیبان")
                                        context.startActivity(shareIntent)
                                    } catch (e: Exception) {
                                        errorMessage = "خطا در اشتراک‌گذاری: ${e.message}"
                                    } finally {
                                        isProcessing = false
                                    }
                                }
                            },
                            enabled = !isProcessing,
                            modifier = Modifier.testTag("share_backup_button")
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("ارسال")
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Section 2: بازیابی پشتیبان (Restore)
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.Restore,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = "بازیابی پشتیبان",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "می‌توانید فایل پشتیبان قبلی خود را از حافظه دستگاه انتخاب کنید. داده‌ها به صورت کاملاً ایمن با سوابق فعلی ادغام خواهند شد و هیچ سابقه‌ای حذف نمی‌شود.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        lineHeight = 22.sp
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = {
                            openDocumentLauncher.launch(arrayOf("application/json", "text/*", "*/*"))
                        },
                        enabled = !isProcessing,
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                        modifier = Modifier.fillMaxWidth().testTag("restore_backup_button")
                    ) {
                        if (isProcessing) {
                            CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onSecondary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("در حال پردازش...")
                        } else {
                            Icon(Icons.Default.CloudDownload, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("انتخاب و بازیابی فایل پشتیبان")
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Info Card: نکات امنیتی داده‌ها
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.Top) {
                    Icon(
                        Icons.Default.Info,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "فایل‌های پشتیبان با استاندارد متنی JSON ساخته می‌شوند تا بتوانید آن‌ها را به راحتی بین دستگاه‌های مختلف جابجا کرده یا در فضای ابری دلخواه خود نگهداری کنید.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        lineHeight = 20.sp
                    )
                }
            }
        }
    }
}
