package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.EditCalendar
import androidx.compose.material.icons.filled.MoreTime
import androidx.compose.material.icons.filled.Paid
import androidx.compose.material.icons.filled.Today
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.viewmodel.OvertimeViewModel
import com.example.util.PersianCalendarHelper

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WorkCalendarScreen(
    viewModel: OvertimeViewModel,
    onNavigateBack: () -> Unit,
    onRegisterWorkDayForDate: (PersianCalendarHelper.PersianDate) -> Unit,
    onRegisterPaymentForDate: (PersianCalendarHelper.PersianDate) -> Unit
) {
    val workDays by viewModel.workDays.collectAsStateWithLifecycle()
    val overtimes by viewModel.overtimes.collectAsStateWithLifecycle()
    val payments by viewModel.payments.collectAsStateWithLifecycle()

    val todayPersian = remember { PersianCalendarHelper.getTodayPersianDate() }

    var currentYear by remember { mutableIntStateOf(todayPersian.year) }
    var currentMonth by remember { mutableIntStateOf(todayPersian.month) }
    var selectedDate by remember { mutableStateOf(todayPersian) }

    val daysInMonth = PersianCalendarHelper.getDaysInPersianMonth(currentYear, currentMonth)
    // 0 = شنبه, ..., 6 = جمعه
    val firstDayDow = PersianCalendarHelper.getPersianDayOfWeek(currentYear, currentMonth, 1)

    // Maps for fast lookup
    val workDayMap = remember(workDays) { workDays.associateBy { it.date } }
    val overtimeMap = remember(overtimes) { overtimes.associateBy { it.date } }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "تقویم کاری",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "بازگشت")
                    }
                },
                actions = {
                    FilledTonalButton(
                        onClick = {
                            currentYear = todayPersian.year
                            currentMonth = todayPersian.month
                            selectedDate = todayPersian
                        },
                        modifier = Modifier.padding(end = 8.dp)
                    ) {
                        Icon(Icons.Default.Today, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("امروز", style = MaterialTheme.typography.labelMedium)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            // Month Navigation Card
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    // Header with < Month Name >
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = {
                            if (currentMonth == 12) {
                                currentMonth = 1
                                currentYear++
                            } else {
                                currentMonth++
                            }
                        }) {
                            Icon(Icons.Default.ChevronRight, contentDescription = "ماه بعد")
                        }

                        Text(
                            text = "${PersianCalendarHelper.getPersianMonthName(currentMonth)} ${PersianCalendarHelper.toPersianDigits(currentYear)}",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )

                        IconButton(onClick = {
                            if (currentMonth == 1) {
                                currentMonth = 12
                                currentYear--
                            } else {
                                currentMonth--
                            }
                        }) {
                            Icon(Icons.Default.ChevronLeft, contentDescription = "ماه قبل")
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Weekday Labels
                    val weekDays = listOf("ش", "ی", "د", "س", "چ", "پ", "ج")
                    Row(modifier = Modifier.fillMaxWidth()) {
                        weekDays.forEach { wDay ->
                            Text(
                                text = wDay,
                                modifier = Modifier.weight(1f),
                                textAlign = TextAlign.Center,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = if (wDay == "ج") MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                    Spacer(modifier = Modifier.height(8.dp))

                    // Calendar Grid (7 columns)
                    val totalCells = firstDayDow + daysInMonth
                    val rows = (totalCells + 6) / 7

                    for (row in 0 until rows) {
                        Row(modifier = Modifier.fillMaxWidth()) {
                            for (col in 0 until 7) {
                                val cellIndex = row * 7 + col
                                val dayNumber = cellIndex - firstDayDow + 1

                                if (dayNumber in 1..daysInMonth) {
                                    val cellDate = PersianCalendarHelper.PersianDate(currentYear, currentMonth, dayNumber)
                                    val cellCanonical = cellDate.toStandardString()
                                    val isToday = cellDate.year == todayPersian.year && cellDate.month == todayPersian.month && cellDate.day == todayPersian.day
                                    val isSelected = cellDate.year == selectedDate.year && cellDate.month == selectedDate.month && cellDate.day == selectedDate.day

                                    val hasWorkDay = workDayMap[cellCanonical]?.let { it.workDayAmount > 0 } ?: false
                                    val hasOvertime = overtimeMap[cellCanonical]?.let { it.overtimeHours > 0 } ?: false
                                    val hasPayment = payments.any {
                                        it.persianDate == cellDate.toLongFormat() ||
                                                it.persianDate.contains(cellCanonical) ||
                                                PersianCalendarHelper.extractCanonicalDate(it.persianDate) == cellCanonical
                                    }

                                    CalendarDayCell(
                                        dayNumber = dayNumber,
                                        isToday = isToday,
                                        isSelected = isSelected,
                                        isFriday = col == 6,
                                        hasWorkDay = hasWorkDay,
                                        hasOvertime = hasOvertime,
                                        hasPayment = hasPayment,
                                        modifier = Modifier
                                            .weight(1f)
                                            .aspectRatio(1f)
                                            .padding(2.dp)
                                            .clickable { selectedDate = cellDate }
                                    )
                                } else {
                                    Spacer(modifier = Modifier.weight(1f).aspectRatio(1f))
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Legend Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        LegendItem(color = MaterialTheme.colorScheme.primary, text = "روز کاری")
                        Spacer(modifier = Modifier.width(14.dp))
                        LegendItem(color = MaterialTheme.colorScheme.tertiary, text = "اضافه کاری")
                        Spacer(modifier = Modifier.width(14.dp))
                        LegendItem(color = MaterialTheme.colorScheme.secondary, text = "دریافتی")
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Day Details Card
            val selectedCanonical = selectedDate.toStandardString()
            val selectedWorkDay = workDayMap[selectedCanonical]
            val selectedOvertime = overtimeMap[selectedCanonical]
            val selectedPayments = payments.filter {
                it.persianDate == selectedDate.toLongFormat() ||
                        it.persianDate.contains(selectedCanonical) ||
                        PersianCalendarHelper.extractCanonicalDate(it.persianDate) == selectedCanonical
            }
            val hasDataForDay = (selectedWorkDay != null && selectedWorkDay.workDayAmount > 0) ||
                    (selectedOvertime != null && selectedOvertime.overtimeHours > 0) ||
                    selectedPayments.isNotEmpty()

            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    // Title with selected date
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "جزئیات: ${selectedDate.toLongFormat()}",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            val (gy, gm, gd) = PersianCalendarHelper.persianToGregorian(selectedDate.year, selectedDate.month, selectedDate.day)
                            Text(
                                text = "معادل میلادی: $gy/${gm.toString().padStart(2, '0')}/${gd.toString().padStart(2, '0')}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.outline
                            )
                        }

                        Icon(
                            Icons.Default.DateRange,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(28.dp)
                        )
                    }

                    HorizontalDivider(
                        modifier = Modifier.padding(vertical = 12.dp),
                        color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
                    )

                    if (!hasDataForDay) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 16.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "برای این روز اطلاعاتی ثبت نشده است.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    } else {
                        // Work Day
                        if (selectedWorkDay != null && selectedWorkDay.workDayAmount > 0) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("روز کاری:", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(
                                    PersianCalendarHelper.formatWorkDays(selectedWorkDay.workDayAmount),
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }

                        // Overtime
                        if (selectedOvertime != null && selectedOvertime.overtimeHours > 0) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("اضافه کاری:", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(
                                    PersianCalendarHelper.formatHours(selectedOvertime.overtimeHours),
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.tertiary
                                )
                            }
                        }

                        // Payments
                        if (selectedPayments.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "دریافتی‌های این روز:",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.secondary
                            )
                            selectedPayments.forEach { pmt ->
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("ساعت ${PersianCalendarHelper.toPersianDigits(pmt.time)}", style = MaterialTheme.typography.bodySmall)
                                    Text(
                                        PersianCalendarHelper.formatAmountToman(pmt.amountToman),
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.secondary
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Action buttons to add / edit for this selected date
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = { onRegisterWorkDayForDate(selectedDate) },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.EditCalendar, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(if (selectedWorkDay != null || selectedOvertime != null) "ویرایش کارکرد" else "ثبت کارکرد")
                        }

                        OutlinedButton(
                            onClick = { onRegisterPaymentForDate(selectedDate) },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Paid, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("ثبت دریافتی")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CalendarDayCell(
    dayNumber: Int,
    isToday: Boolean,
    isSelected: Boolean,
    isFriday: Boolean,
    hasWorkDay: Boolean,
    hasOvertime: Boolean,
    hasPayment: Boolean,
    modifier: Modifier = Modifier
) {
    val bgColor = when {
        isSelected -> MaterialTheme.colorScheme.primaryContainer
        else -> Color.Transparent
    }

    val textColor = when {
        isSelected -> MaterialTheme.colorScheme.onPrimaryContainer
        isFriday -> MaterialTheme.colorScheme.error
        else -> MaterialTheme.colorScheme.onSurface
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(bgColor)
            .then(
                if (isToday) Modifier.border(1.5.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(10.dp))
                else Modifier
            ),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = PersianCalendarHelper.toPersianDigits(dayNumber),
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = if (isToday || isSelected) FontWeight.Bold else FontWeight.Normal,
                color = textColor,
                fontSize = 13.sp
            )

            // Indicators row
            Row(
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(top = 2.dp)
            ) {
                if (hasWorkDay) {
                    Box(
                        modifier = Modifier
                            .size(5.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primary)
                    )
                }
                if (hasOvertime) {
                    Spacer(modifier = Modifier.width(2.dp))
                    Box(
                        modifier = Modifier
                            .size(5.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.tertiary)
                    )
                }
                if (hasPayment) {
                    Spacer(modifier = Modifier.width(2.dp))
                    Box(
                        modifier = Modifier
                            .size(5.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.secondary)
                    )
                }
            }
        }
    }
}

@Composable
private fun LegendItem(color: Color, text: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(7.dp)
                .clip(CircleShape)
                .background(color)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(text = text, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
