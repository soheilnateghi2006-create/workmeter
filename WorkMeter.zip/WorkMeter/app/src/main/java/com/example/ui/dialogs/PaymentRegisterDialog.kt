package com.example.ui.dialogs

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Paid
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.CenteredSmoothDialog
import com.example.ui.components.PersianDatePickerDialog
import com.example.ui.viewmodel.OvertimeViewModel
import com.example.util.PersianCalendarHelper

@Composable
fun PaymentRegisterDialog(
    viewModel: OvertimeViewModel,
    initialDate: PersianCalendarHelper.PersianDate = PersianCalendarHelper.getTodayPersianDate(),
    initialGregorianDate: String = PersianCalendarHelper.getTodayGregorianDate(),
    onDismissRequest: () -> Unit
) {
    var rawAmountInput by remember { mutableStateOf("") }
    var currentPersianDate by remember { mutableStateOf(initialDate) }
    var currentGregorianDate by remember { mutableStateOf(initialGregorianDate) }
    val currentTime = remember { PersianCalendarHelper.getCurrentTime() }
    var showDatePicker by remember { mutableStateOf(false) }

    // Clean English digits from raw input
    val numericAmount by remember(rawAmountInput) {
        derivedStateOf {
            val englishDigits = PersianCalendarHelper.toEnglishDigits(rawAmountInput)
                .filter { it.isDigit() }
            englishDigits.toLongOrNull() ?: 0L
        }
    }

    // Dynamic Persian words live update
    val wordsText by remember(numericAmount) {
        derivedStateOf {
            if (numericAmount > 0) {
                PersianCalendarHelper.amountToPersianWordsWithToman(numericAmount)
            } else {
                "مبلغ را به تومان وارد کنید"
            }
        }
    }

    if (showDatePicker) {
        PersianDatePickerDialog(
            initialDate = currentPersianDate,
            onDateSelected = { pDate, gDate ->
                currentPersianDate = pDate
                currentGregorianDate = gDate
                showDatePicker = false
            },
            onDismissRequest = { showDatePicker = false }
        )
    }

    CenteredSmoothDialog(
        onDismissRequest = onDismissRequest,
        modifier = Modifier.testTag("payment_dialog"),
        icon = {
            Icon(
                Icons.Default.Paid,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.secondary,
                modifier = Modifier.size(32.dp)
            )
        },
        title = {
            Text(
                text = "ثبت دریافتی",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
        },
        content = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                // 1. Amount Text Field (مبلغ دریافتی)
                OutlinedTextField(
                    value = rawAmountInput,
                    onValueChange = { input ->
                        val digits = PersianCalendarHelper.toEnglishDigits(input).filter { it.isDigit() }
                        // Allow up to 18 digits safely (up to 999 quadrillion Toman)
                        if (digits.length <= 18) {
                            rawAmountInput = digits
                        }
                    },
                    label = { Text("مبلغ دریافتی (تومان)") },
                    placeholder = { Text("مثلاً ۵۰۰۰۰۰۰ یا ۱۰۰۰۰۰۰۰۰۰۰۰") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("payment_amount_input"),
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                // 2. Live Formatted Amount and Words Display (مبلغ به حروف فارسی)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(
                            if (numericAmount > 0) MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.45f)
                            else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
                        )
                        .padding(12.dp)
                ) {
                    Column {
                        // Formatted Toman with dynamic font size for large amounts
                        Text(
                            text = if (numericAmount > 0)
                                PersianCalendarHelper.formatAmountToman(numericAmount)
                            else
                                "۰ تومان",
                            fontSize = when {
                                rawAmountInput.length > 13 -> 15.sp
                                rawAmountInput.length > 9 -> 18.sp
                                else -> 20.sp
                            },
                            fontWeight = FontWeight.Bold,
                            color = if (numericAmount > 0) MaterialTheme.colorScheme.onSecondaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        // Persian Words
                        Text(
                            text = wordsText,
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (numericAmount > 0) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurfaceVariant,
                            fontWeight = if (numericAmount > 0) FontWeight.SemiBold else FontWeight.Normal
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // 3. Date & Time Box (تاریخ و ساعت)
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = currentPersianDate.toLongFormat(),
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    Icons.Default.AccessTime,
                                    contentDescription = null,
                                    modifier = Modifier.size(14.dp),
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "ساعت ${PersianCalendarHelper.toPersianDigits(currentTime)}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        OutlinedButton(
                            onClick = { showDatePicker = true },
                            modifier = Modifier.testTag("payment_change_date_button")
                        ) {
                            Icon(Icons.Default.CalendarMonth, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("تغییر تاریخ")
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (numericAmount > 0) {
                        viewModel.savePayment(
                            amountToman = numericAmount,
                            canonicalDate = currentPersianDate.toCanonicalDate(),
                            persianDate = currentPersianDate.toLongFormat(),
                            persianMonthKey = currentPersianDate.toMonthYearKey(),
                            gregorianDate = currentGregorianDate,
                            amountInWords = wordsText,
                            onSuccess = onDismissRequest
                        )
                    }
                },
                enabled = numericAmount > 0,
                modifier = Modifier.testTag("save_payment_button")
            ) {
                Text("ذخیره دریافتی")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismissRequest) {
                Text("انصراف")
            }
        }
    )
}
