package com.example.util

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.SharedPreferences
import android.hardware.biometrics.BiometricManager
import android.os.Build
import android.os.SystemClock
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec
import kotlin.math.abs

/**
 * Extension to safely resolve Activity from any wrapped Context.
 */
fun Context.findActivity(): Activity? {
    var ctx = this
    while (ctx is ContextWrapper) {
        if (ctx is Activity) return ctx
        ctx = ctx.baseContext
    }
    return null
}

/**
 * Manages secure App Lock (PIN and Biometric).
 *
 * - The PIN is stored as a salted PBKDF2 hash. Old installs that still have the legacy
 *   salted SHA-256 hash keep working and are silently upgraded after the next correct PIN.
 * - Brute-force protection: after every 5 consecutive wrong PINs the PIN keypad is locked
 *   (30 s, 1 min, 5 min, 15 min, then 15 min again). The counter survives app restarts and
 *   a reboot or clock change simply restarts the running lock instead of skipping it.
 */
class AppLockManager(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences("workmeter_lock_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_LOCK_ENABLED = "lock_enabled"
        private const val KEY_BIOMETRIC_ENABLED = "biometric_enabled"
        private const val KEY_PIN_HASH = "pin_hash"
        private const val KEY_PIN_SALT = "pin_salt"
        private const val KEY_PIN_ALGO = "pin_algo"
        private const val KEY_PIN_ITER = "pin_iter"

        private const val KEY_FAILED_COUNT = "failed_count"
        private const val KEY_LOCK_DURATION = "lock_duration_ms"
        private const val KEY_LOCK_TARGET_ELAPSED = "lock_target_elapsed"
        private const val KEY_BOOT_REF = "lock_boot_ref"

        private const val ALGO_SHA256 = "PBKDF2WithHmacSHA256"
        private const val ALGO_SHA1 = "PBKDF2WithHmacSHA1" // only for API 24-25
        private const val ITERATIONS = 120_000
        private const val ATTEMPTS_PER_LOCK = 5
        private val LOCK_STEPS_MS = longArrayOf(30_000L, 60_000L, 300_000L, 900_000L)
    }

    val isLockEnabled: Boolean
        get() = prefs.getBoolean(KEY_LOCK_ENABLED, false)

    val isBiometricEnabled: Boolean
        get() = prefs.getBoolean(KEY_BIOMETRIC_ENABLED, false)

    fun hasPin(): Boolean {
        return prefs.getString(KEY_PIN_HASH, null) != null
    }

    /**
     * Checks if biometric hardware is supported and available on device.
     * Safely handles all Android versions and exceptions.
     */
    fun isBiometricHardwareAvailable(context: Context): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                val biometricManager = context.getSystemService(BiometricManager::class.java) ?: return false
                val authenticators = BiometricManager.Authenticators.BIOMETRIC_WEAK or BiometricManager.Authenticators.BIOMETRIC_STRONG
                biometricManager.canAuthenticate(authenticators) == BiometricManager.BIOMETRIC_SUCCESS
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val biometricManager = context.getSystemService(BiometricManager::class.java) ?: return false
                @Suppress("DEPRECATION")
                biometricManager.canAuthenticate() == BiometricManager.BIOMETRIC_SUCCESS
            } else {
                false
            }
        } catch (e: Throwable) {
            false
        }
    }

    /**
     * Sets a new 4-digit PIN (PBKDF2 with a unique random salt) and enables the lock.
     */
    fun setPin(pin: String): Boolean {
        if (pin.length != 4) return false
        if (!storePin(pin)) return false
        prefs.edit().putBoolean(KEY_LOCK_ENABLED, true).apply()
        clearFailedAttempts()
        return true
    }

    /**
     * Validates the entered PIN. Returns false (without counting an attempt) while the
     * keypad is locked. Wrong PINs are counted and eventually lock the keypad.
     */
    fun verifyPin(pin: String): Boolean {
        if (pin.length != 4) return false
        if (lockRemainingMillis() > 0L) return false

        val storedHash = prefs.getString(KEY_PIN_HASH, null) ?: return false
        val storedSalt = prefs.getString(KEY_PIN_SALT, null) ?: return false
        val algo = prefs.getString(KEY_PIN_ALGO, null)

        val matches = try {
            if (algo == null) {
                // Legacy salted SHA-256 hash from older versions
                constantTimeEquals(legacyHash(pin, storedSalt), storedHash)
            } else {
                val iterations = prefs.getInt(KEY_PIN_ITER, ITERATIONS)
                constantTimeEquals(pbkdf2(pin, storedSalt, algo, iterations), storedHash)
            }
        } catch (e: Exception) {
            false
        }

        if (matches) {
            if (algo == null) {
                storePin(pin) // silent upgrade to PBKDF2
            }
            clearFailedAttempts()
        } else {
            registerFailedAttempt()
        }
        return matches
    }

    /** Milliseconds the PIN keypad stays locked (0 when entry is allowed). */
    fun lockRemainingMillis(): Long {
        val duration = prefs.getLong(KEY_LOCK_DURATION, 0L)
        if (duration <= 0L) return 0L

        val nowElapsed = SystemClock.elapsedRealtime()
        val nowWall = System.currentTimeMillis()
        val bootRef = prefs.getLong(KEY_BOOT_REF, 0L)
        val sameBoot = abs((nowWall - nowElapsed) - bootRef) < 60_000L

        if (!sameBoot) {
            // Reboot or clock change: restart the lock so it can never be skipped this way.
            prefs.edit()
                .putLong(KEY_LOCK_TARGET_ELAPSED, nowElapsed + duration)
                .putLong(KEY_BOOT_REF, nowWall - nowElapsed)
                .commit()
            return duration
        }

        val remaining = prefs.getLong(KEY_LOCK_TARGET_ELAPSED, 0L) - nowElapsed
        if (remaining <= 0L) {
            prefs.edit().putLong(KEY_LOCK_DURATION, 0L).commit()
            return 0L
        }
        return remaining.coerceAtMost(duration)
    }

    /** Resets the wrong-PIN counter and any running lock (call after a successful unlock). */
    fun clearFailedAttempts() {
        prefs.edit()
            .remove(KEY_FAILED_COUNT)
            .remove(KEY_LOCK_DURATION)
            .remove(KEY_LOCK_TARGET_ELAPSED)
            .remove(KEY_BOOT_REF)
            .commit()
    }

    fun setLockEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_LOCK_ENABLED, enabled).apply()
    }

    fun setBiometricEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_BIOMETRIC_ENABLED, enabled).apply()
    }

    /**
     * Safe reset flow: removes PIN and disables lock.
     */
    fun resetLock() {
        prefs.edit()
            .remove(KEY_PIN_HASH)
            .remove(KEY_PIN_SALT)
            .remove(KEY_PIN_ALGO)
            .remove(KEY_PIN_ITER)
            .putBoolean(KEY_LOCK_ENABLED, false)
            .putBoolean(KEY_BIOMETRIC_ENABLED, false)
            .commit()
        clearFailedAttempts()
    }

    // ---------------------------------------------------------------- internals

    private fun registerFailedAttempt() {
        val count = prefs.getInt(KEY_FAILED_COUNT, 0) + 1
        val editor = prefs.edit().putInt(KEY_FAILED_COUNT, count)
        if (count % ATTEMPTS_PER_LOCK == 0) {
            val step = (count / ATTEMPTS_PER_LOCK - 1).coerceAtMost(LOCK_STEPS_MS.size - 1)
            val duration = LOCK_STEPS_MS[step]
            val nowElapsed = SystemClock.elapsedRealtime()
            editor
                .putLong(KEY_LOCK_DURATION, duration)
                .putLong(KEY_LOCK_TARGET_ELAPSED, nowElapsed + duration)
                .putLong(KEY_BOOT_REF, System.currentTimeMillis() - nowElapsed)
        }
        editor.commit()
    }

    private fun storePin(pin: String): Boolean {
        return try {
            val saltBytes = ByteArray(16)
            SecureRandom().nextBytes(saltBytes)
            val salt = saltBytes.joinToString("") { "%02x".format(it) }
            val algo = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) ALGO_SHA256 else ALGO_SHA1
            val hash = pbkdf2(pin, salt, algo, ITERATIONS)
            prefs.edit()
                .putString(KEY_PIN_SALT, salt)
                .putString(KEY_PIN_HASH, hash)
                .putString(KEY_PIN_ALGO, algo)
                .putInt(KEY_PIN_ITER, ITERATIONS)
                .commit()
        } catch (e: Exception) {
            false
        }
    }

    private fun pbkdf2(pin: String, salt: String, algo: String, iterations: Int): String {
        val spec = PBEKeySpec(pin.toCharArray(), salt.toByteArray(Charsets.UTF_8), iterations, 256)
        try {
            val bytes = SecretKeyFactory.getInstance(algo).generateSecret(spec).encoded
            return bytes.joinToString("") { "%02x".format(it) }
        } finally {
            spec.clearPassword()
        }
    }

    private fun legacyHash(pin: String, salt: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val input = "$salt:$pin"
        val hashBytes = digest.digest(input.toByteArray(Charsets.UTF_8))
        return hashBytes.joinToString("") { "%02x".format(it) }
    }

    private fun constantTimeEquals(a: String, b: String): Boolean {
        return MessageDigest.isEqual(a.toByteArray(Charsets.UTF_8), b.toByteArray(Charsets.UTF_8))
    }
}
