package com.example.util

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.SharedPreferences
import android.hardware.biometrics.BiometricManager
import android.os.Build
import java.security.MessageDigest
import java.security.SecureRandom

/**
 * Extension to safely resolve Activity from any wrapped Context.
 */
fun Context.findActivity(): Activity? {
    var ctx = this
    while (ctx is ContextWrapper) {
        if (ctx is Activity) return ctx
        ctx = ctx.baseContext
    }
    return null
}

/**
 * Manages secure App Lock (PIN and Biometric).
 * PIN is securely stored using a salted SHA-256 hash.
 */
class AppLockManager(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences("workmeter_lock_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_LOCK_ENABLED = "lock_enabled"
        private const val KEY_BIOMETRIC_ENABLED = "biometric_enabled"
        private const val KEY_PIN_HASH = "pin_hash"
        private const val KEY_PIN_SALT = "pin_salt"
    }

    val isLockEnabled: Boolean
        get() = prefs.getBoolean(KEY_LOCK_ENABLED, false)

    val isBiometricEnabled: Boolean
        get() = prefs.getBoolean(KEY_BIOMETRIC_ENABLED, false)

    fun hasPin(): Boolean {
        return prefs.getString(KEY_PIN_HASH, null) != null
    }

    /**
     * Checks if biometric hardware is supported and available on device.
     * Safely handles all Android versions and exceptions.
     */
    fun isBiometricHardwareAvailable(context: Context): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                val biometricManager = context.getSystemService(BiometricManager::class.java) ?: return false
                val authenticators = BiometricManager.Authenticators.BIOMETRIC_WEAK or BiometricManager.Authenticators.BIOMETRIC_STRONG
                biometricManager.canAuthenticate(authenticators) == BiometricManager.BIOMETRIC_SUCCESS
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val biometricManager = context.getSystemService(BiometricManager::class.java) ?: return false
                @Suppress("DEPRECATION")
                biometricManager.canAuthenticate() == BiometricManager.BIOMETRIC_SUCCESS
            } else {
                false
            }
        } catch (e: Throwable) {
            false
        }
    }

    /**
     * Sets a new 4-digit PIN using SHA-256 with a unique random salt.
     */
    fun setPin(pin: String): Boolean {
        if (pin.length != 4) return false

        val saltBytes = ByteArray(16)
        SecureRandom().nextBytes(saltBytes)
        val salt = saltBytes.joinToString("") { "%02x".format(it) }

        val hash = hashPin(pin, salt)

        prefs.edit()
            .putString(KEY_PIN_SALT, salt)
            .putString(KEY_PIN_HASH, hash)
            .putBoolean(KEY_LOCK_ENABLED, true)
            .apply()

        return true
    }

    /**
     * Validates the entered PIN against the stored salted hash.
     */
    fun verifyPin(pin: String): Boolean {
        val storedHash = prefs.getString(KEY_PIN_HASH, null) ?: return false
        val storedSalt = prefs.getString(KEY_PIN_SALT, null) ?: return false

        val calculatedHash = hashPin(pin, storedSalt)
        return calculatedHash == storedHash
    }

    fun setLockEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_LOCK_ENABLED, enabled).apply()
    }

    fun setBiometricEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_BIOMETRIC_ENABLED, enabled).apply()
    }

    /**
     * Safe reset flow: removes PIN and disables lock.
     */
    fun resetLock() {
        prefs.edit()
            .remove(KEY_PIN_HASH)
            .remove(KEY_PIN_SALT)
            .putBoolean(KEY_LOCK_ENABLED, false)
            .putBoolean(KEY_BIOMETRIC_ENABLED, false)
            .apply()
    }

    private fun hashPin(pin: String, salt: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val input = "$salt:$pin"
        val hashBytes = digest.digest(input.toByteArray(Charsets.UTF_8))
        return hashBytes.joinToString("") { "%02x".format(it) }
    }
}
