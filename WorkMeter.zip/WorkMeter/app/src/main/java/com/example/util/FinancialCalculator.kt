package com.example.util

import com.example.data.model.Overtime
import com.example.data.model.Payment
import com.example.data.model.RateSetting
import com.example.data.model.WorkDay
import java.math.BigDecimal
import java.math.RoundingMode

data class MonthlyFinancialBalance(
    val monthKey: String, // e.g. "مهر ۱۴۰۵"
    val yearMonthCanonical: String, // e.g. "1405/07"
    val entitledAmount: Long, // مبلغ استحقاقی (گرد شده به تومان)
    val paymentAmount: Long, // مجموع دریافتی‌ها
    val balance: Long, // دریافتی - استحقاقی (مثبت = پیش‌دریافت، منفی = طلب)
    val cumulativeBalance: Long, // مانده تجمعی تا این ماه
    val hasMissingRate: Boolean = false
)

data class FinancialBalanceSummary(
    val monthlyBalances: List<MonthlyFinancialBalance> = emptyList(),
    val totalEntitledAmount: Long = 0L,
    val totalPaymentAmount: Long = 0L,
    val totalBalance: Long = 0L,
    val hasAnyMissingRate: Boolean = false
)

object FinancialCalculator {

    fun calculateFinancialBalances(
        workDays: List<WorkDay>,
        overtimes: List<Overtime>,
        payments: List<Payment>,
        rates: List<RateSetting>
    ): FinancialBalanceSummary {
        val workDayMap = workDays.associateBy { it.date }
        val overtimeMap = overtimes.associateBy { it.date }

        val activeDates = (workDays.map { it.date } + overtimes.map { it.date })
            .filter { it.isNotBlank() }
            .distinct()

        // Group registered days by canonical year/month (e.g. "1405/07")
        val daysByMonth = LinkedHashMap<String, MutableList<String>>()
        val monthDisplayNames = HashMap<String, String>()

        for (d in activeDates) {
            val wd = workDayMap[d]
            val ot = overtimeMap[d]
            val wdAmount = wd?.workDayAmount ?: 0.0
            val otHours = ot?.overtimeHours ?: 0.0
            if (wdAmount > 0.0 || otHours > 0.0) {
                val parsed = PersianCalendarHelper.parseCanonicalDate(d)
                val ymKey = if (parsed != null) {
                    "${parsed.year}/${parsed.month.toString().padStart(2, '0')}"
                } else {
                    d.take(7)
                }
                daysByMonth.getOrPut(ymKey) { mutableListOf() }.add(d)
                if (parsed != null && !monthDisplayNames.containsKey(ymKey)) {
                    monthDisplayNames[ymKey] = parsed.toMonthYearKey()
                }
            }
        }

        // Group payments by canonical year/month
        val paymentsByMonth = LinkedHashMap<String, MutableList<Payment>>()
        for (p in payments) {
            val cDate = p.canonicalDate.ifBlank {
                PersianCalendarHelper.extractCanonicalDate(p.persianDate)
            }
            val parsed = PersianCalendarHelper.parseCanonicalDate(cDate)
            val ymKey = if (parsed != null) {
                "${parsed.year}/${parsed.month.toString().padStart(2, '0')}"
            } else if (cDate.length >= 7) {
                cDate.take(7)
            } else {
                p.persianMonthKey.ifBlank { "نامشخص" }
            }

            paymentsByMonth.getOrPut(ymKey) { mutableListOf() }.add(p)
            if (parsed != null && !monthDisplayNames.containsKey(ymKey)) {
                monthDisplayNames[ymKey] = parsed.toMonthYearKey()
            } else if (!monthDisplayNames.containsKey(ymKey) && p.persianMonthKey.isNotBlank()) {
                monthDisplayNames[ymKey] = p.persianMonthKey
            }
        }

        // All distinct months in chronological order
        val allMonthKeys = (daysByMonth.keys + paymentsByMonth.keys)
            .distinct()
            .sorted()

        var runningCumulativeBalance = 0L
        var totalEntitledSum = 0L
        var totalPaymentSum = 0L
        var globalHasMissingRate = false

        val monthlyResultList = mutableListOf<MonthlyFinancialBalance>()

        for (ymKey in allMonthKeys) {
            val datesInMonth = daysByMonth[ymKey] ?: emptyList()
            var monthEntitledBigDecimal = BigDecimal.ZERO
            var monthHasMissingRate = false

            for (date in datesInMonth) {
                val wd = workDayMap[date]
                val ot = overtimeMap[date]
                val wdAmount = wd?.workDayAmount ?: 0.0
                val otHours = ot?.overtimeHours ?: 0.0

                if (wdAmount <= 0.0 && otHours <= 0.0) continue

                // Find latest rate where effectiveFrom <= date
                val applicableRate = rates
                    .filter { it.effectiveFrom <= date }
                    .maxWithOrNull(compareBy({ it.effectiveFrom }, { it.id }))

                if (applicableRate == null) {
                    monthHasMissingRate = true
                    globalHasMissingRate = true
                    // Amount is 0 for this day
                } else {
                    val dailyWage = BigDecimal.valueOf(applicableRate.dailyWage)
                    val dailyHours = BigDecimal.valueOf(applicableRate.dailyHours)
                    // Hourly wage = dailyWage / dailyHours (high precision)
                    val hourlyWage = if (applicableRate.dailyHours > 0.0) {
                        dailyWage.divide(dailyHours, 12, RoundingMode.HALF_UP)
                    } else {
                        BigDecimal.ZERO
                    }

                    // Work day amount = workDayAmount * dailyWage
                    val dayWage = BigDecimal.valueOf(wdAmount).multiply(dailyWage)

                    // Overtime amount = overtimeHours * hourlyWage * overtimeMultiplier
                    val multiplier = BigDecimal.valueOf(applicableRate.overtimeMultiplier)
                    val otWage = BigDecimal.valueOf(otHours)
                        .multiply(hourlyWage)
                        .multiply(multiplier)

                    val dayTotal = dayWage.add(otWage)
                    monthEntitledBigDecimal = monthEntitledBigDecimal.add(dayTotal)
                }
            }

            // Monthly entitled is rounded to Toman with HALF_UP
            val monthEntitledLong = monthEntitledBigDecimal
                .setScale(0, RoundingMode.HALF_UP)
                .toLong()

            // Sum payments for this month
            val monthPayments = paymentsByMonth[ymKey] ?: emptyList()
            var monthPaymentLong = 0L
            for (p in monthPayments) {
                monthPaymentLong = try {
                    Math.addExact(monthPaymentLong, p.amountToman)
                } catch (_: ArithmeticException) {
                    Long.MAX_VALUE
                }
            }

            // Balance = Payment - Entitled
            val monthBalance = monthPaymentLong - monthEntitledLong
            runningCumulativeBalance += monthBalance

            totalEntitledSum += monthEntitledLong
            totalPaymentSum += monthPaymentLong

            val displayName = monthDisplayNames[ymKey] ?: ymKey

            monthlyResultList.add(
                MonthlyFinancialBalance(
                    monthKey = displayName,
                    yearMonthCanonical = ymKey,
                    entitledAmount = monthEntitledLong,
                    paymentAmount = monthPaymentLong,
                    balance = monthBalance,
                    cumulativeBalance = runningCumulativeBalance,
                    hasMissingRate = monthHasMissingRate
                )
            )
        }

        val totalBalance = totalPaymentSum - totalEntitledSum

        return FinancialBalanceSummary(
            monthlyBalances = monthlyResultList,
            totalEntitledAmount = totalEntitledSum,
            totalPaymentAmount = totalPaymentSum,
            totalBalance = totalBalance,
            hasAnyMissingRate = globalHasMissingRate
        )
    }
}
