package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.PI
import kotlin.math.sin

/**
 * Animated liquid summary card.
 * Features a calm, subtle, minimal water wave at the bottom portion of the card.
 * The liquid fill level corresponds smoothly to the value.
 * Text and labels remain clear, legible, and prominent above the liquid.
 */
@Composable
fun LiquidSummaryCard(
    title: String,
    valueText: String,
    unitText: String,
    icon: ImageVector,
    fillFraction: Float, // 0.0f to 1.0f
    waveColor: Color,
    modifier: Modifier = Modifier,
    testTag: String = "summary_card"
) {
    // Subtle, calm wave phase animation
    val infiniteTransition = rememberInfiniteTransition(label = "liquid_wave")
    val wavePhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = (2 * PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 3500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "wave_phase"
    )

    // Clamped liquid level: min 0.12f (empty/low) to max 0.65f so text is always above/clear
    val effectiveLevel = 0.12f + (fillFraction.coerceIn(0f, 1f) * 0.50f)

    Card(
        modifier = modifier
            .testTag(testTag)
            .height(138.dp),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .clip(RoundedCornerShape(18.dp))
        ) {
            // Calm Water / Liquid Wave Canvas at bottom
            Canvas(modifier = Modifier.fillMaxSize()) {
                val width = size.width
                val height = size.height

                // Water line y position (height * (1 - effectiveLevel))
                val waterY = height * (1f - effectiveLevel)
                val waveAmplitude = 5.dp.toPx() // Small, calm amplitude
                val waveLength = width * 1.1f

                val wavePath = Path().apply {
                    moveTo(0f, height)
                    lineTo(0f, waterY)

                    // Draw sinusoidal calm surface
                    val step = 15f
                    var x = 0f
                    while (x <= width) {
                        val y = waterY + (sin((x / waveLength) * 2 * PI + wavePhase).toFloat() * waveAmplitude)
                        lineTo(x, y)
                        x += step
                    }
                    lineTo(width, waterY + (sin((width / waveLength) * 2 * PI + wavePhase).toFloat() * waveAmplitude))
                    lineTo(width, height)
                    close()
                }

                // Fill with subtle, calm translucent liquid gradient
                val liquidGradient = Brush.verticalGradient(
                    colors = listOf(
                        waveColor.copy(alpha = 0.28f),
                        waveColor.copy(alpha = 0.45f)
                    ),
                    startY = waterY,
                    endY = height
                )
                drawPath(path = wavePath, brush = liquidGradient)

                // Secondary soft crest line for depth
                val crestPath = Path().apply {
                    moveTo(0f, waterY)
                    var x = 0f
                    val step = 15f
                    while (x <= width) {
                        val y = waterY + (sin((x / waveLength) * 2 * PI + wavePhase + 1.2f).toFloat() * (waveAmplitude * 0.65f))
                        lineTo(x, y)
                        x += step
                    }
                }
                drawPath(
                    path = crestPath,
                    color = waveColor.copy(alpha = 0.35f),
                    style = androidx.compose.ui.graphics.drawscope.Stroke(width = 2.dp.toPx())
                )
            }

            // Foreground Content (Title, Icon, Bold Value, Unit)
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 14.dp, vertical = 12.dp)
            ) {
                // Header: Title and Icon
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = waveColor,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = title,
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1
                    )
                }

                Spacer(modifier = Modifier.weight(1f))

                // Value and Unit
                Row(
                    verticalAlignment = Alignment.Bottom,
                    modifier = Modifier.padding(bottom = 2.dp)
                ) {
                    Text(
                        text = valueText,
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontSize = if (valueText.length > 8) 20.sp else 24.sp,
                            fontWeight = FontWeight.Bold
                        ),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    if (unitText.isNotBlank()) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = unitText,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(bottom = 3.dp)
                        )
                    }
                }
            }
        }
    }
}
