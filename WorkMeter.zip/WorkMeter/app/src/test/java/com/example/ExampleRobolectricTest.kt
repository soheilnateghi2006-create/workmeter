package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.util.AppLockManager
import java.security.MessageDigest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("اضافه کاری من", appName)
    }

    @Test
    fun `app lock default state is disabled and has no pin`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val lockManager = AppLockManager(context)
        lockManager.resetLock()

        assertFalse(lockManager.isLockEnabled)
        assertFalse(lockManager.hasPin())
    }

    @Test
    fun `app lock set pin requires exactly 4 digits`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val lockManager = AppLockManager(context)
        lockManager.resetLock()

        // Invalid lengths
        assertFalse(lockManager.setPin("123"))
        assertFalse(lockManager.setPin("12345"))
        assertFalse(lockManager.setPin(""))

        // Valid length
        assertTrue(lockManager.setPin("1234"))
        assertTrue(lockManager.hasPin())
        assertTrue(lockManager.isLockEnabled)
    }

    @Test
    fun `app lock pin verification correct and incorrect`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val lockManager = AppLockManager(context)
        lockManager.resetLock()
        lockManager.setPin("5678")

        // Correct PIN
        assertTrue(lockManager.verifyPin("5678"))

        // Incorrect PINs
        assertFalse(lockManager.verifyPin("0000"))
        assertFalse(lockManager.verifyPin("5679"))
        assertFalse(lockManager.verifyPin(""))
    }

    @Test
    fun `app lock state persists after reopening multiple times`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val lockManager1 = AppLockManager(context)
        lockManager1.resetLock()
        lockManager1.setPin("9999")
        assertTrue(lockManager1.isLockEnabled)

        // Simulate closing and reopening app 1
        val lockManager2 = AppLockManager(context)
        assertTrue(lockManager2.isLockEnabled)
        assertTrue(lockManager2.verifyPin("9999"))

        // Simulate closing and reopening app 2
        val lockManager3 = AppLockManager(context)
        assertTrue(lockManager3.isLockEnabled)
        assertTrue(lockManager3.verifyPin("9999"))
        assertFalse(lockManager3.verifyPin("1111"))
    }

    @Test
    fun `app lock reset properly removes pin and disables lock`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val lockManager = AppLockManager(context)
        lockManager.setPin("4321")
        assertTrue(lockManager.isLockEnabled)

        lockManager.resetLock()
        assertFalse(lockManager.isLockEnabled)
        assertFalse(lockManager.hasPin())
        assertFalse(lockManager.verifyPin("4321"))
    }

    @Test
    fun `biometric availability check does not throw or crash on unsupported devices`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val lockManager = AppLockManager(context)

        // Must safely return a boolean without throwing exceptions
        val available = lockManager.isBiometricHardwareAvailable(context)
        // Verify it evaluates safely
        assertTrue(available || !available)
    }

    @Test
    fun `biometric toggle persists across app instances`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val lockManager1 = AppLockManager(context)
        lockManager1.setPin("1234")
        lockManager1.setBiometricEnabled(true)
        assertTrue(lockManager1.isBiometricEnabled)

        // Reopen app instance
        val lockManager2 = AppLockManager(context)
        assertTrue(lockManager2.isBiometricEnabled)

        lockManager2.setBiometricEnabled(false)
        assertFalse(lockManager2.isBiometricEnabled)

        val lockManager3 = AppLockManager(context)
        assertFalse(lockManager3.isBiometricEnabled)
    }

    @Test
    fun `multiple reopenings with wrong and right pin combinations never crash`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val lockManager = AppLockManager(context)
        lockManager.setPin("7890")

        for (i in 1..20) {
            val reopenedManager = AppLockManager(context)
            assertTrue(reopenedManager.isLockEnabled)
            assertFalse(reopenedManager.verifyPin("0000"))
            assertFalse(reopenedManager.verifyPin("7891"))
            assertTrue(reopenedManager.verifyPin("7890"))
        }
    }

    @Test
    fun `five wrong pins lock the keypad even for the correct pin`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val lockManager = AppLockManager(context)
        lockManager.resetLock()
        lockManager.setPin("1234")

        repeat(5) { assertFalse(lockManager.verifyPin("0000")) }
        assertTrue(lockManager.lockRemainingMillis() > 0L)
        // Locked: even the correct PIN is refused until the lock ends
        assertFalse(lockManager.verifyPin("1234"))

        // The lock survives re-opening the app
        assertTrue(AppLockManager(context).lockRemainingMillis() > 0L)

        lockManager.clearFailedAttempts()
        assertEquals(0L, lockManager.lockRemainingMillis())
        assertTrue(lockManager.verifyPin("1234"))
    }

    @Test
    fun `correct pin resets the failed attempt counter`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val lockManager = AppLockManager(context)
        lockManager.resetLock()
        lockManager.setPin("2468")

        repeat(4) { assertFalse(lockManager.verifyPin("1111")) }
        assertTrue(lockManager.verifyPin("2468"))
        repeat(4) { assertFalse(lockManager.verifyPin("1111")) }
        assertEquals(0L, lockManager.lockRemainingMillis())
    }

    @Test
    fun `legacy sha256 pin keeps working and is upgraded`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val lockManager = AppLockManager(context)
        lockManager.resetLock()

        val salt = "00ff00ff00ff00ff00ff00ff00ff00ff"
        val legacyHash = MessageDigest.getInstance("SHA-256")
            .digest("$salt:1357".toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
        val prefs = context.getSharedPreferences("workmeter_lock_prefs", Context.MODE_PRIVATE)
        prefs.edit()
            .putString("pin_salt", salt)
            .putString("pin_hash", legacyHash)
            .putBoolean("lock_enabled", true)
            .commit()

        assertTrue(lockManager.verifyPin("1357"))
        // After the first successful login the hash is stored with PBKDF2
        assertTrue(prefs.getString("pin_algo", null) != null)
        assertTrue(lockManager.verifyPin("1357"))
        assertFalse(lockManager.verifyPin("1358"))
    }
}
