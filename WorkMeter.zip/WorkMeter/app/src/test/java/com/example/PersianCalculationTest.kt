package com.example

import com.example.util.PersianCalendarHelper
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PersianCalculationTest {

    @Test
    fun testPersianDigitsConversion() {
        assertEquals("۱۲۳۴۵۶۷۸۹۰", PersianCalendarHelper.toPersianDigits("1234567890"))
        assertEquals("1234567890", PersianCalendarHelper.toEnglishDigits("۱۲۳۴۵۶۷۸۹۰"))
    }

    @Test
    fun testAmountToPersianWords() {
        assertEquals("پنج میلیون تومان", PersianCalendarHelper.amountToPersianWordsWithToman(5_000_000L))
        assertEquals("پنج میلیون و پانصد هزار تومان", PersianCalendarHelper.amountToPersianWordsWithToman(5_500_000L))
        assertEquals("بیست میلیون تومان", PersianCalendarHelper.amountToPersianWordsWithToman(20_000_000L))
        assertEquals("یکصد میلیون تومان", PersianCalendarHelper.amountToPersianWordsWithToman(100_000_000L))
        assertEquals("یک میلیارد تومان", PersianCalendarHelper.amountToPersianWordsWithToman(1_000_000_000L))
        assertEquals("ده میلیارد تومان", PersianCalendarHelper.amountToPersianWordsWithToman(10_000_000_000L))
        assertEquals("یکصد میلیارد تومان", PersianCalendarHelper.amountToPersianWordsWithToman(100_000_000_000L))
        assertEquals("یک تریلیون تومان", PersianCalendarHelper.amountToPersianWordsWithToman(1_000_000_000_000L))
        assertEquals("ده تریلیون تومان", PersianCalendarHelper.amountToPersianWordsWithToman(10_000_000_000_000L))
        assertEquals("صفر تومان", PersianCalendarHelper.amountToPersianWordsWithToman(0L))
    }

    @Test
    fun testLargeAmountFormatting() {
        val f1 = PersianCalendarHelper.formatAmountToman(100_000_000_000L)
        assertTrue(f1.contains("۱۰۰٬۰۰۰٬۰۰۰٬۰۰۰") && f1.contains("تومان"))

        val f2 = PersianCalendarHelper.formatAmountToman(1_000_000_000_000L)
        assertTrue(f2.contains("۱٬۰۰۰٬۰۰۰٬۰۰۰٬۰۰۰") && f2.contains("تومان"))
    }

    @Test
    fun testAmountFormatting() {
        val formatted = PersianCalendarHelper.formatAmountToman(5_000_000L)
        assertTrue(formatted.contains("۵٬۰۰۰٬۰۰۰") && formatted.contains("تومان"))
    }

    @Test
    fun testWorkDayAndOvertimeFormatting() {
        assertEquals("۱ روز", PersianCalendarHelper.formatWorkDays(1.0))
        assertEquals("۰.۵ روز", PersianCalendarHelper.formatWorkDays(0.5))
        assertEquals("۳ ساعت", PersianCalendarHelper.formatHours(3.0))
        assertEquals("۱۰ ساعت", PersianCalendarHelper.formatHours(10.0))
    }

    @Test
    fun testJalaliConversion() {
        val gregorianDate = PersianCalendarHelper.persianToGregorian(1405, 7, 10)
        val pDate = PersianCalendarHelper.gregorianToPersian(gregorianDate.first, gregorianDate.second, gregorianDate.third)
        assertEquals(1405, pDate.year)
        assertEquals(7, pDate.month)
        assertEquals(10, pDate.day)
        assertEquals("مهر", pDate.monthName)
    }

    @Test
    fun testDaysInMonthAndDayOfWeek() {
        assertEquals(31, PersianCalendarHelper.getDaysInPersianMonth(1405, 1))
        assertEquals(31, PersianCalendarHelper.getDaysInPersianMonth(1405, 6))
        assertEquals(30, PersianCalendarHelper.getDaysInPersianMonth(1405, 7))
        assertEquals(30, PersianCalendarHelper.getDaysInPersianMonth(1405, 11))

        val dow = PersianCalendarHelper.getPersianDayOfWeek(1405, 7, 1)
        assertTrue(dow in 0..6)
    }

    @Test
    fun testCanonicalDateParsing() {
        val parsed = PersianCalendarHelper.parseCanonicalDate("1405/07/10")
        assertTrue(parsed != null)
        assertEquals(1405, parsed?.year)
        assertEquals(7, parsed?.month)
        assertEquals(10, parsed?.day)

        val canonical = PersianCalendarHelper.extractCanonicalDate("۱۰ مهر ۱۴۰۵")
        assertEquals("1405/07/10", canonical)
    }

    @Test
    fun testPersianLeapYearsRequirement() {
        // Leap years requirement: 1399, 1403, 1408, 1412 are leap
        assertTrue(PersianCalendarHelper.isPersianLeapYear(1399))
        assertTrue(PersianCalendarHelper.isPersianLeapYear(1403))
        assertTrue(PersianCalendarHelper.isPersianLeapYear(1408))
        assertTrue(PersianCalendarHelper.isPersianLeapYear(1412))

        // Non-leap years: 1400, 1401, 1402, 1404, 1405
        assertFalse(PersianCalendarHelper.isPersianLeapYear(1400))
        assertFalse(PersianCalendarHelper.isPersianLeapYear(1401))
        assertFalse(PersianCalendarHelper.isPersianLeapYear(1402))
        assertFalse(PersianCalendarHelper.isPersianLeapYear(1404))
        assertFalse(PersianCalendarHelper.isPersianLeapYear(1405))

        // Days in Esfand: 30 in leap year, 29 in non-leap year
        assertEquals(30, PersianCalendarHelper.getDaysInPersianMonth(1403, 12))
        assertEquals(29, PersianCalendarHelper.getDaysInPersianMonth(1404, 12))
    }

    @Test
    fun testRoundTripConversionFrom1380To1450() {
        // Round trip test: for every day from 1380/01/01 to 1450/12/29
        for (year in 1380..1450) {
            for (month in 1..12) {
                val daysInMonth = PersianCalendarHelper.getDaysInPersianMonth(year, month)
                for (day in 1..daysInMonth) {
                    val (gY, gM, gD) = PersianCalendarHelper.persianToGregorian(year, month, day)
                    val p = PersianCalendarHelper.gregorianToPersian(gY, gM, gD)
                    assertEquals("Mismatch at $year/$month/$day (year)", year, p.year)
                    assertEquals("Mismatch at $year/$month/$day (month)", month, p.month)
                    assertEquals("Mismatch at $year/$month/$day (day)", day, p.day)
                }
            }
        }
    }

    @Test
    fun testWeekFilterAcrossMonthBoundary() {
        // Date near month boundary: 1403/02/31 (31 Ordibehesht 1403, which falls on Monday)
        val testDate = PersianCalendarHelper.PersianDate(1403, 2, 31)
        val (sat, fri) = PersianCalendarHelper.getWeekRangeForDate(testDate)

        // Saturday is in month 2 (Ordibehesht) and Friday is in month 3 (Khordad)
        assertEquals("Week start month should be 2 (Ordibehesht)", 2, sat.month)
        assertEquals("Week end month should be 3 (Khordad)", 3, fri.month)
        assertEquals(sat.year, fri.year)
    }

    @Test
    fun testWeekFilterAcrossYearBoundary() {
        // Date near year boundary: 1403/12/29 (last day of 1403)
        val testDate = PersianCalendarHelper.PersianDate(1403, 12, 29)
        val (sat, fri) = PersianCalendarHelper.getWeekRangeForDate(testDate)

        // The week starts on Saturday in year 1403 and ends on Friday in year 1404, crossing the year boundary
        assertEquals("Week start year should be 1403", 1403, sat.year)
        assertEquals("Week start month should be 12 (Esfand)", 12, sat.month)
        assertEquals("Week end year should be 1404", 1404, fri.year)
        assertEquals("Week end month should be 1 (Farvardin)", 1, fri.month)
    }
}
